/**
 * Created by TILE on 15/01/05.
 */
"use strict"; // Default style code of JS.



ToanThanToc.OnlineDetailResultWin = function(_game){};
ToanThanToc.OnlineDetailResultWin.prototype={


    /* ---------------- VARIABLE ---------------------- */
    itemGroup : null,
    xPoint : 0,
    yPoint : 0,
    txtSecondResult : null,
    styleTextSecond : {font: "60px segoe ui", fill: "#fff"},
    list : undefined,
    bg:null,
    back:null,
    out:null,
    bg_second:null,
    topFirstIcon : null,
    topFirstName : null,
    getBingo : null,
    starPerMember: null,
    chargeCreateRoom : null,
    remain : null,
    fontStyle : {font: "bold 50px segoe ui", fill: "#FFF",strokeThickness:0},
    fontStyle1 : {font: "bold 50px segoe ui", fill: "#FFF",strokeThickness:0},
    fontStyle2 : {font: "bold 50px segoe ui", fill: "#FFF",strokeThickness:0},

    /**
     * Data test default.
     * @type {{id: number, stt: number, avatar: string, name: string, level: string, score: number}[]}
     */
    array: {
        "name":"2","scoreUpdatedAt":"2015-01-14T02:26:48.863Z","score":12,
        "players":[{"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn","nickname":"nahi1@nahi.vn",
            "avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":2,"score":12}]
    },

    /* ---------------- VARIABLE END ---------------------- */


    /**
    * Load image.
    */
    preload : function(){
        if( ToanThanToc.game.cache.checkImageKey('result_backgroundWin')){
            return;
        }
        ToanThanToc.game.load.spritesheet('result_backgroundWin',
            'assets/online/result/backgroundWin.png',800, 1232);
    },

    /**
    * Create UI.
    * @author TILE.
    */
//    createDetailResult : function(data){
//        var game=ToanThanToc.OnlineDetailResultWin.prototype;
//
//        //itemGroup = ToanThanToc.game.add.group();
//        game.bg = ToanThanToc.game.add.image(0,0,'result_background');
//        game.back = ToanThanToc.game.add.image(100,120,'result_back');
//        game.back.inputEnabled = true;
//        game.back.events.onInputDown.add(game.backClick);
//        game.out = ToanThanToc.game.add.image(590,120,'result_out');
//        game.out.inputEnabled = true;
//        game.out.events.onInputDown.add(this.closeClick);
////        bg_second = ToanThanToc.game.add.image(150,855,'result_secondResult');
//
//        game.createList(150,350,480,490,'result_background');
//
//
//    },


    /**
     * Detail result winner.
     */
    create : function(){
        var game=ToanThanToc.OnlineDetailResultWin.prototype;
        game.bg = ToanThanToc.game.add.image(0,0,'result_backgroundWin');


        game.topFirstName = ToanThanToc.game.add.text(400,940,this.array.players[0].fullname,{fill:"#ffffff",font:'bold 40px Segoe UI',stroke:'#3a230a',strokeThickness:0,align:'center'});
        game.topFirstName.anchor.set(0.5,0);
        game.getBingo = ToanThanToc.game.add.text(546,1022,this.starPerMember,{fill:"#ffffff",font:'bold 40px Segoe UI',stroke:'#3a230a',strokeThickness:0,align:'center'});
//        getBingo.fontWeight = 'bold';
//        getBingo.fontSize = 35;
        game.getBingo.anchor.set(1,0);

        var starchargeCreateRoom = Math.floor((this.starPerMember*PERCENTSTART)/100);

        game.chargeCreateRoom = ToanThanToc.game.add.text(546,1073,starchargeCreateRoom,{fill:"#ffffff",font:'bold 40px Segoe UI',stroke:'#3a230a',strokeThickness:0,align:'center'});
//        chargeCreateRoom.fontWeight = 'bold';
//        chargeCreateRoom.fontSize = 35;
        game.chargeCreateRoom.anchor.set(1,0);

        var starRemain = this.starPerMember - starchargeCreateRoom;

        game.remain = ToanThanToc.game.add.text(546,1122,starRemain,{fill:"#ffffff",font:'bold 40px Segoe UI',stroke:'#3a230a',strokeThickness:0,align:'center'});
//        remain.fontWeight = 'bold';
//        remain.fontSize = 35;
        game.remain.anchor.set(1,0);


        game.createList(150,200,480,530,'result_backgroundWin');
        game.topFirstIcon.bringToTop();

    },


    /**
     * Create list
     */
    createList : function(x,y,w,h,key){
        var game=ToanThanToc.OnlineDetailResultWin.prototype;


        var arrayFreeRoom = {};
        for(var i = 0; i < game.array.players.length;++i){

            var arrayTemp = 0;
            var temp = i+1;
            game.topFirstIcon = ToanThanToc.game.add.image(355,855,(game.array.players[0] .avatar_url == '') ? 'avatar_default' : game.array.players[0].id);
            game.topFirstIcon.width=84;
            game.topFirstIcon.height=84;
            arrayTemp = [

                { // Level.
                    xBuffer: 130,
                    yBuffer: 60,
                    name: 'Lv.'+game.array.players[i].level,
                    anchor: 0,
                    shadow: '0|0|0|0',
                    property: {font: "bold 35px Segoe UI", fill: "#fff", align: "left"},
                    type: 'text', isShow: 1
                },
                { // Text Name
                    xBuffer: 130,
                    yBuffer: 5,
                    name: game.array.players[i].nickname,
                    anchor: 0,
                    shadow: '0|0|0|0',
                    property: {font: "bold 35px Segoe UI", fill: "#fff", align: "left"},
                    type: 'textmem', isShow: 1
                },
                { // avatar image
                    xBuffer: 0,
                    yBuffer: -3,
                    name: (game.array.players[i] .avatar_url == '') ? 'avatar_default' : game.array.players[i].id,
                    width:111,
                    height:111,
                    property: {},
                    type: 'avatar', isShow: 1
                },
                { // score image
                    xBuffer: 395,
                    yBuffer: 5,
                    name: 'Score',
                    property: {},
                    type: 'image', isShow: 1
                },
                { // score image
                    xBuffer: -50,
                    yBuffer: 120,
                    name: 'list_line',
                    property: {},
                    type: 'image', isShow: 1
                },
                { // Diem
                    xBuffer: 495,
                    yBuffer: 75,
                    name: (game.array.players[i].score=='0')?'0':game.array.players[i].score,
                    strokeThickness: 5,
                    fontSize: 20,
                    fontWeight: 'bold',
                    anchor: 0.5,
                    shadow: '0|0|0|0',
                    property: {font: "bold 40px Segoe UI", fill: "#fff", align: "center"},
                    type: 'text', isShow: 1
                }
            ];
            if(i == 2){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -77,
                        yBuffer: -7,
                        name: '3medals',
                        type: 'avatar',
                        width:74,
                        height:74,
                        isShow: 1
                    }
                );
            }else if(i == 1){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -77,
                        yBuffer: -7,
                        name: '2medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }else if(i == 0){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -77,
                        yBuffer: 0,
                        name: '1medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }else{
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -75,
                        yBuffer: 10,
                        name: temp + 'medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }

            if(arrayTemp){
                arrayFreeRoom[Object.keys(arrayFreeRoom).length] = arrayTemp;
            }
        }

        /* Create List */
        game.list = new ListScroll(arrayFreeRoom,x, y, w, h,140,
            'winnerScreen',ToanThanToc.OnlineDetailResultWin,null,key);

        game.list.makeList();
        game.back = ToanThanToc.game.add.button(21,21,'result_back',this.backClick,{},0,0,1,0);
        game.out = ToanThanToc.game.add.button(693,21,'result_out',this.clickExit,{},0,0,1,0);
        game.out.inputEnabled = true;
        game.out.events.onInputDown.add(game.closeClick);
//        ToanThanToc.OnlineMathResult.prototype.list = new ListScroll(arrayFreeRoom,16, 218, 480, 390,117,'detailResult',
//            ToanThanToc.OnlineMathResult.prototype,ToanThanToc.OnlineMathResult.prototype.arrayButton,'result_bgMathResult',
//            ToanThanToc.game);
//        ToanThanToc.OnlineMathResult.prototype.list.makeList();
//        game.list.setOnTop([game.bg_second,game.back,this.out]);

//        txtSecondResult = ToanThanToc.game.add.text(bg_second.x+(bg_second.width/2)-30,
//            bg_second.y+(bg_second.height/2)-25, '10s',styleTextSecond);
//        txtSecondResult.fontWeight = 'bold';
//        txtSecondResult.fontSize = 60;
//        txtSecondResult.strokeThickness = 2;
    },






    /**
    * Destroy object
    */
    destroy: function(){
        destroyArray([ToanThanToc.OnlineDetailResultWin.prototype.bg,
            ToanThanToc.OnlineDetailResultWin.prototype.itemGroup,
            ToanThanToc.OnlineDetailResultWin.prototype.txtSecondResult,
            ToanThanToc.OnlineDetailResultWin.prototype.xPoint,
            ToanThanToc.OnlineDetailResultWin.prototype.yPoint,
            ToanThanToc.OnlineDetailResultWin.prototype,
            ToanThanToc.OnlineDetailResultWin.prototype.styleTextSecond,
            ToanThanToc.OnlineDetailResultWin.prototype.bg_second,
            ToanThanToc.OnlineDetailResultWin.prototype.back,
            ToanThanToc.OnlineDetailResultWin.prototype.out]);
    },

    clickExit : function(){
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("OnlineRoomWaiting");
        ToanThanToc.nameSpace = 'waitingRoom';

    },

    update : function(){
        if( ToanThanToc.OnlineDetailResultWin.prototype.list != null){
            ToanThanToc.OnlineDetailResultWin.prototype.list.update();
        }
    },

    /**
     * Back click.
     */
    backClick : function(){
        ToanThanToc.nameSpaceBefore = "OnlineDetailResultWin";
        shareFunction.actionPlayAudio('touch');
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("OnlineMathResult");
    },


    /**
     * Close click
     */
    closeClick : function(){
        shareFunction.actionPlayAudio('touch');
    },
    sortData : function(data){

        /* Sort */
        var k = 0;
        for(k;k<data.length;++k){
            var l = 0;
            for(l;l<data.length-1;++l){
                if( data[l].score < data[l+1].score){
                    // permutations
                    var variableTemp = data[l+1];
                    data[l+1] = data[l];
                    data[l] = variableTemp;
                }
            }

        }

        return data;
    }

}; // End function.








