    /**
    * Created by ngoin on 22/01/15.
    */

    /* HO SY DAI
    *  daish@nahi.vn
    *  Create: 05/12/2014
    *  Project: Game Center
    *  Menu.js
    * */
    "use strict";

    ToanThanToc.MenuOnline =function (game) {
    };
    ToanThanToc.MenuOnline.prototype = {
    //------------------------------------
    btn_back: null,
    groupMenu: null,
    is_Btn: '',
    btn_playnow: null,
    btn_select_room: null,
    btn_create_room: null,
    bg_menu: null,


    create: function () {

        ToanThanToc.MenuOnline.prototype.groupMenu = ToanThanToc.game.add.group();
        ToanThanToc.MenuOnline.prototype.bg_menu = ToanThanToc.game.add.image(0, 0, 'onlineBgMenu');
        ToanThanToc.MenuOnline.prototype.bg_menu = ToanThanToc.game.add.image(15, 15, 'logoNAHI');
        ToanThanToc.MenuOnline.prototype.bg_menu = ToanThanToc.game.add.image(710, 15, 'logo-vnn');
      //  ToanThanToc.MenuOnline.prototype.groupMenu.add(ToanThanToc.MenuOnline.prototype.bg_menu);

        ToanThanToc.MenuOnline.prototype.btn_playnow = ToanThanToc.game.add.button(134, 258, 'onlineBtnPlayNow',
        ToanThanToc.MenuOnline.prototype.actionOnClickPlay, ToanThanToc.game, 0, 0, 1);
        // groupMenu.add(btn_playnow);

        ToanThanToc.MenuOnline.prototype.btn_select_room = ToanThanToc.game.add.button(134, 491, 'onlineBtnSelectRoom',
        ToanThanToc.MenuOnline.prototype.actionOnClickSelect, ToanThanToc.game, 0, 0, 1);

        //groupMenu.add(btn_select_room);

        ToanThanToc.MenuOnline.prototype.btn_create_room = ToanThanToc.game.add.button(134, 725, 'onlineBtnCreateRoom',
        this.actionOnClickCreate, ToanThanToc.game, 0, 0, 1);

        ToanThanToc.MenuOnline.prototype.btn_back = ToanThanToc.game.add.button(340, 1040, 'onlineBtnBack',
        ToanThanToc.MenuOnline.prototype.actionOnClickBack, ToanThanToc.game, 0, 0, 1);
        ToanThanToc.MenuOnline.prototype.btn_back.events.onInputDown.add(function () {
            shareFunction.actionPlayAudio('touch');
        },this);



        /* Get profile */
        Socket.getProfile();
    },
    update: function () {
        //if (ToanThanToc.nameSpace == 'createRoom') {
        ////ToanThanToc.STATES.createRoom.update();
        //} else if (ToanThanToc.nameSpace == 'chooseRoom') {
        ////ToanThanToc.STATES.select.updateSelect();
        //} else if (ToanThanToc.nameSpace == 'play') {
        ////ToanThanToc.STATES.play.update();
        //} else if (ToanThanToc.nameSpace == 'waitingRoom') {
        ////ToanThanToc.STATES.detail.update();
        //} else if (ToanThanToc.nameSpace == 'detailResult') {
        ////ToanThanToc.STATES.detailResult.update();
        //} else if (ToanThanToc.nameSpace == 'mathResult') {
        ////ToanThanToc.STATES.mathResult.updateMathResult();
        //} else if (ToanThanToc.nameSpace == 'userView') {
        ////ToanThanToc.STATES.userView.update();
        //} else if (ToanThanToc.nameSpace == 'roomPlaying') {
        ////ToanThanToc.STATES.roomPlaying.update();
        //}else if(ToanThanToc.nameSpace = 'winnerScreen'){
        //
        //}else if(ToanThanToc.nameSpace = 'loserScreen'){
        //
        //}
    },

    preload:function(){

        if( ToanThanToc.game.cache.checkImageKey('onlineBtnPlayNow') &&
            ToanThanToc.game.cache.checkImageKey('onlineBtnSelectRoom') &&
            ToanThanToc.game.cache.checkImageKey('onlineBtnCreateRoom')){
            return;
        }
        this.game.load.spritesheet('onlineBtnPlayNow','assets/online/menu/play-now.png',533,168);
        this.game.load.spritesheet('onlineBtnSelectRoom','assets/online/menu/select-room.png',533,171);
        this.game.load.spritesheet('onlineBtnCreateRoom','assets/online/menu/create-room.png',533,172);

    },
    actionOnClickPlay: function () {
        //visible(arrAllObjectLoading, true);
        shareFunction.actionPlayAudio('touch');
        ToanThanToc.nameSpace = 'play';
        Socket.execute(function(socket){
            socket.post(domainAPI + urlAutoJoinRoom,{token:xAuthToken}, function(data){

                var p = new Popup();
                p.setMain(ToanThanToc.game,'Disconnect','','popup','popupClose',[{x:-150,y:20}],null,[]);
                p.setText([{x:0,y:-120}],['Mất kết nối'],[{fill:'#ffffff',font:'30px Segoe UI',align:'center'}]);
                p.createPopup(350,350);
                p.openWindow();
            });
        });
    },

    actionOnClickSelect :function () {
        //console.log('Button select click')
        shareFunction.actionPlayAudio('touch');
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("OnlineRoomChoose");
        ToanThanToc.nameSpace = 'chooseRoom';
    },
    actionOnClickCreate :function () {
        shareFunction.actionPlayAudio('touch');
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("OnlineCreateRoom");
//        ToanThanToc.game.state.start("OnlineUserView");
        ToanThanToc.nameSpace = 'createRoom';
    },
    actionOnClickBack :function () {
        SetCssBody('url(assets/solo/background/background.png) no-repeat center center fixed');
        //console.log('back');
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("Menu");
    },

    /**
    * Destroy screen.
    */
    destroy :function () {
        ToanThanToc.MenuOnline.prototype.btn_back = null;
        ToanThanToc.MenuOnline.prototype.groupMenu = null;
        ToanThanToc.MenuOnline.prototype.is_Btn = '';
        ToanThanToc.MenuOnline.prototype.btn_playnow = null;
        ToanThanToc.MenuOnline.prototype.btn_select_room = null;
        ToanThanToc.MenuOnline.prototype.btn_create_room = null;
        ToanThanToc.MenuOnline.prototype.bg_menu = null;
    }

    };

