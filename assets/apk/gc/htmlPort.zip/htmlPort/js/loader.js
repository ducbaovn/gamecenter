/* TRAN PHAN THANH
 *  Thanhpt@nahi.vn
 *  Create: 07/11/2014
 *  Project: Game Center
 *  loader.js
 * */
//-------------------------------------
"use strict";

ToanThanToc.Loader = function (game) {
    this.ready = false;
};

ToanThanToc.Loader.prototype = {


    preload: function () {
        ToanThanToc.game.input.maxPointers = 0;
        log('file loading');
        ToanThanToc.Loader.prototype.bck = this.game.add.sprite(this.world.centerX, this.world.centerY + 400, 'preloaderBackground');
        ToanThanToc.Loader.prototype.preloadBar = this.game.add.sprite(this.world.centerX - ToanThanToc.Loader.prototype.bck.width * 0.5, this.world.centerY + 400 -100, 'preloaderBar');

        ToanThanToc.Loader.prototype.bck.anchor.setTo(0.5, 1);
        this.load.setPreloadSprite(ToanThanToc.Loader.prototype.preloadBar);

        /* load audio */
        this.load.audio(ToanThanToc.music_lose,       this.BuildAudioArray( 'assets/solo/music/' + ToanThanToc.music_lose));
        this.load.audio(ToanThanToc.music_music,   this.BuildAudioArray('assets/solo/music/' + ToanThanToc.music_music));
        this.load.audio(ToanThanToc.music_popupMainAction,     this.BuildAudioArray( 'assets/solo/music/' + ToanThanToc.music_popupMainAction));
        this.load.audio(ToanThanToc.music_popupQuit,    this.BuildAudioArray( 'assets/solo/music/' + ToanThanToc.music_popupQuit));
        this.load.audio(ToanThanToc.music_touch,     this.BuildAudioArray('assets/solo/music/' + ToanThanToc.music_touch));
        this.load.audio(ToanThanToc.music_win,       this.BuildAudioArray( 'assets/solo/music/' + ToanThanToc.music_win));
        this.load.audio(ToanThanToc.music_wrong,    this.BuildAudioArray('assets/solo/music/' + ToanThanToc.music_wrong));

        /* load image page menu */
        this.load.spritesheet('btnSingle', 'assets/solo/menu/btn-single.png', 490,128);
        this.load.spritesheet('btnMulti', 'assets/solo/menu/btn-multi.png', 490,128);
        this.load.spritesheet('btnOnline', 'assets/solo/menu/btn-online.png', 490,128);

        this.load.spritesheet('btnSound', 'assets/solo/menu/btn-sound.png', 105,105);
        this.load.spritesheet('btnTutorial', 'assets/solo/menu/btn-tutorial.png', 232,106);
        this.load.spritesheet('btnItemBag', 'assets/solo/menu/btn-item-bag.png', 106,105);

        this.load.image('bgPopup', 'assets/solo/menu/popup/bg-setting-sound.png');
        this.load.spritesheet('btnOff', 'assets/solo/menu/popup/btn-exit.png',81,84);
        this.load.spritesheet('btnXacNhan', 'assets/solo/menu/popup/settings-popup-btn.png',195,64);
        this.load.spritesheet('CheckNhacNen', 'assets/solo/menu/popup/ckb-option.png',79,84);
        this.load.spritesheet('CheckHieuUng', 'assets/solo/menu/popup/ckb-option.png',79,84);


        /* animation animal */
        this.load.spritesheet('anmiSloloLionRight', 'assets/solo/play/lion-right.png',158,158);
        this.load.spritesheet('anmiSloloLionWrong', 'assets/solo/play/lion-wrong.png',158,158);

        this.load.spritesheet('anmiSloloMonkeyRight', 'assets/solo/play/monkey-right.png',158,158);
        this.load.spritesheet('anmiSloloMonkeyWrong', 'assets/solo/play/monkey-wrong.png',158,158);

        this.load.spritesheet('anmiSloloGiraffeRight', 'assets/solo/play/giraffe-right.png',158,158);
        this.load.spritesheet('anmiSloloGiraffeWrong', 'assets/solo/play/giraffe-wrong.png',158,158);

        this.load.spritesheet('anmiSloloOwlRight', 'assets/solo/play/owl-right.png',158,158);
        this.load.spritesheet('anmiSloloOwlWrong', 'assets/solo/play/owl-wrong.png',158,158);

        this.load.spritesheet('anmiSloloRabbitRight', 'assets/solo/play/rabbit-right.png',158,158);
        this.load.spritesheet('anmiSloloRabbitWrong', 'assets/solo/play/rabbit-wrong.png',158,158);
        //////////////////////////////////////////////////////////////////////////////////
        this.load.spritesheet('anmiSloloLionWin', 'assets/solo/end-game/animation/lion-win.png',158,158);
        this.load.spritesheet('anmiSloloLionLose', 'assets/solo/end-game/animation/lion-lose.png',158,158);

        this.load.spritesheet('anmiSloloMonkeyWin', 'assets/solo/end-game/animation/monkey-win.png',158,158);
        this.load.spritesheet('anmiSloloMonkeyLose', 'assets/solo/end-game/animation/monkey-lose.png',158,158);

        this.load.spritesheet('anmiSloloGiraffeWin', 'assets/solo/end-game/animation/giraffe-win.png',158,158);
        this.load.spritesheet('anmiSloloGiraffeLose', 'assets/solo/end-game/animation/giraffe-lose.png',158,158);

        this.load.spritesheet('anmiSloloOwlWin', 'assets/solo/end-game/animation/owl-win.png',158,158);
        this.load.spritesheet('anmiSloloOwlLose', 'assets/solo/end-game/animation/owl-lose.png',158,158);

        this.load.spritesheet('anmiSloloRabbitWin', 'assets/solo/end-game/animation/rabbit-win.png',158,158);
        this.load.spritesheet('anmiSloloRabbitLose', 'assets/solo/end-game/animation/rabbit-lose.png',158,158);
        //////////////////////////////////////////////////////////////////////////////////
        this.load.spritesheet('imgLoserSL', 'assets/solo/end-game/img-loser.png',363,205);
        this.load.spritesheet('imgWinnerSL', 'assets/solo/end-game/img-winner.png',471,456);
        //this.load.spritesheet('hoaRoiSL', 'assets/solo/end-game/tie/tie-text.png',726,410);
        this.load.spritesheet('hoaRoiSL', 'assets/solo/end-game/tie/tie-text.png',726,410);
        this.load.spritesheet('bgTimeSL', 'assets/solo/end-game/bg-time.png',320,109);

        this.load.spritesheet('topOptionT1', 'assets/solo/play/top-option1.png',198,97);
        this.load.spritesheet('topOptionT2', 'assets/solo/play/top-option1.png',198,97);
        this.load.spritesheet('topOptionT3', 'assets/solo/play/top-option1.png',198,97);

        this.load.spritesheet('topOptionB1', 'assets/solo/play/top-option1.png',198,97);
        this.load.spritesheet('topOptionB2', 'assets/solo/play/top-option1.png',198,97);
        this.load.spritesheet('topOptionB3', 'assets/solo/play/top-option1.png',198,97);

        this.load.spritesheet('topQuestionSL1', 'assets/solo/play/top-question1.png',616,170);

        /* count Down */
        this.load.spritesheet('countDown', 'assets/solo/play/count-down/count-down.png', 370,345);
        this.load.spritesheet('bgcountdown','assets/online/backgrounds/bgcountdown.png');

        /* button Setting */
        this.load.spritesheet('baseSoloPlay', 'assets/solo/play/count-down/base.png', 394,394);
        this.load.spritesheet('btnSettingSoloPlay', 'assets/solo/play/count-down/btn-setting.png', 128,129);
        this.load.spritesheet('btnSettingTuyChonSP', 'assets/solo/play/count-down/tuy-chon.png',185,267);
        this.load.spritesheet('btnSettingTiepTucSP', 'assets/solo/play/count-down/tiep-tuc.png',184,268);
        this.load.spritesheet('btnSettingKhoiDongSP', 'assets/solo/play/count-down/khoi-dong.png',305,184);
        this.load.spritesheet('btnSoundSP', 'assets/solo/play/count-down/btn-sound.png',184,188);

        /*   Phan MenuSolo    */
        this.load.spritesheet('btnMenuSoloPlay', 'assets/solo/menu/menu-solo/btn-play.png', 243,119);
        this.load.spritesheet('btnMenuSoloDivision', 'assets/solo/menu/menu-solo/method-division.png', 135,157);
        this.load.spritesheet('btnMenuSoloMinus', 'assets/solo/menu/menu-solo/method-minus.png',135,157);
        this.load.spritesheet('btnMenuSoloMulti', 'assets/solo/menu/menu-solo/method-multi.png',135,157);
        this.load.spritesheet('btnMenuSoloPlus', 'assets/solo/menu/menu-solo/method-plus.png',135,164);
        this.load.spritesheet('btnMenuSoloEasy', 'assets/solo/menu/menu-solo/mode-easy.png',458,125);
        this.load.spritesheet('btnMenuSoloMedium', 'assets/solo/menu/menu-solo/mode-medium.png',456,127);
        this.load.spritesheet('btnMenuSoloHard', 'assets/solo/menu/menu-solo/mode-hard.png',459,121);

        this.load.spritesheet('btnListMsl', 'assets/solo/menu/menu-solo/btn-list.png',249,108);
        this.load.spritesheet('bgListBox', 'assets/solo/menu/menu-solo/list-box.png',232,199);
        this.load.spritesheet('bgSelectItemMSL', 'assets/solo/menu/menu-solo/list-item.png', 232, 54);
        this.load.spritesheet('logoVnm', 'assets/solo/menu/menu-solo/logo-vnm.png',75,81);
        this.load.spritesheet('logoNAHI', 'assets/solo/menu/menu-solo/logo-NAHI.png',75,81);
		this.load.spritesheet('btnBackTT', 'assets/solo/menu/menu-solo/btn-back.png',113,119);

        /*   Phan Solo play    */
        this.load.spritesheet('bgSLPopupSound', 'assets/solo/play/popup/bg-popup-sound.png', 631,445);
        this.load.spritesheet('btnOkPlaySL', 'assets/solo/play/popup/btn-ok-play.png', 209,90);
       /* this.load.image('backgroundScorce', 'assets/solo/play/background-scorce.png');*/
      /*  this.load.image('backgroundScorceMax', 'assets/solo/play/score.png');*/

        this.load.spritesheet('btnSettingESoloPlay', 'assets/solo/end-game/btn-setting.png', 123,123);
        this.load.spritesheet('bgEndPopupSL', 'assets/solo/end-game/popup/bg-end-popup.png',382,380);
        this.load.spritesheet('endQuitSL', 'assets/solo/end-game/popup/end-quit.png',355,181);
        this.load.spritesheet('endReplaySL', 'assets/solo/end-game/popup/end-replay.png',356,182);
        this.load.spritesheet('bgPopupOk', 'assets/solo/background/popup-bg.png',800,1232);

        this.load.spritesheet('multiBoardFull', 'assets/solo/play/multi-board-full.png',800,299);


		
		 /* hoa nhau */
        this.load.spritesheet('anmiSloloGiraffeTie', 'assets/solo/end-game/tie/giraffe-tie.png',100,131);
        this.load.spritesheet('anmiSloloLionTie', 'assets/solo/end-game/tie/lion-tie.png',128.75,157);
        this.load.spritesheet('anmiSloloMonkeyTie', 'assets/solo/end-game/tie/monkey-tie.png',158.75,158);
        this.load.spritesheet('anmiSloloOwlTie', 'assets/solo/end-game/tie/owl-tie.png',183.5,137);
        this.load.spritesheet('anmiSloloRabbitTie', 'assets/solo/end-game/tie/rabbit-tie.png',121.5,135);
		
        /* add font */
        ToanThanToc.game.load.bitmapFont('num', 'assets/solo/bitmap-font/solo/numSeoUIBold.png', 'assets/solo/bitmap-font/solo/numSeoUIBold.xml');
        ToanThanToc.game.load.bitmapFont('numOption', 'assets/solo/bitmap-font/solo/numOption.png', 'assets/solo/bitmap-font/solo/numOption.xml');
       /* ToanThanToc.game.load.bitmapFont('numBeautiful', 'assets/solo/bitmap-font/solo/num-beautiful.png', 'assets/solo/bitmap-font/solo/num-beautiful.xml');*/
       /* ToanThanToc.game.load.bitmapFont('numOk', 'assets/single/bitmapfont/numboard.png', 'assets/single/bitmapfont/numboard.xml');*/
       /* ToanThanToc.game.load.bitmapFont('numberBrown', 'assets/solo/bitmap-font/solo/numberBrown.png', 'assets/solo/bitmap-font/solo/numberBrown.xml');*/
        ToanThanToc.game.load.bitmapFont('numBlue', 'assets/single/bitmapfont/numBlue.png', 'assets/single/bitmapfont/numBlue.xml');
        ToanThanToc.game.load.bitmapFont('numGreen', 'assets/single/bitmapfont/numGreen.png', 'assets/single/bitmapfont/numGreen.xml');
        ToanThanToc.game.load.bitmapFont('numRed', 'assets/single/bitmapfont/numRed.png', 'assets/single/bitmapfont/numRed.xml');
        ToanThanToc.game.load.bitmapFont('numBoard', 'assets/single/bitmapfont/numOk.png', 'assets/single/bitmapfont/numOk.xml');

        /*        so theo font designer
        ToanThanToc.game.load.bitmapFont('test', 'assets/solo/bitmap-font/solo/desyrel.png', 'assets/solo/bitmap-font/solo/desyrel.xml');*/

        /*   Phan MenuSingle   */
        this.load.spritesheet('btnHighScoreSG', 'assets/single/menu/high-score.png', 245,150);

        this.load.spritesheet('aEinsteinSGP', 'assets/single/popup/a-einstein.png', 60,60);
        this.load.spritesheet('aExpSGP', 'assets/single/popup/a-exp.png', 60,60);
            /* popup die energy */
        this.load.spritesheet('bgPPEnergy', 'assets/single/die-energy/bg.png', 631,445);
        this.load.spritesheet('thoatEnergy', 'assets/single/die-energy/thoat.png', 146,62);
        this.load.spritesheet('vatPhamEnergy', 'assets/single/die-energy/vatpham.png', 148,62);


        /** ----------------------------------- Load image Online mode -----------------------------*/
        this.load.spritesheet('onlineBtnBack','assets/online/menu/back.png',121,131);
        this.load.spritesheet('onlineBgMenu','assets/online/menu/background.png');

        this.game.load.spritesheet('popupOK','assets/online/popup/ok.png');
        this.game.load.spritesheet('popupCancel','assets/online/popup/cancel.png');
        this.game.load.spritesheet('popupClose','assets/online/popup/close.png');
        this.game.load.spritesheet('popup','assets/online/popup/popup.png');
        this.game.load.spritesheet('bgNull','assets/online/popup/bgNull.png');

        this.game.load.spritesheet('bg_play', 'assets/online/plays/bg.png',800,1232);
        this.game.load.spritesheet('list_line', 'assets/online/plays/list_line.png',618,8);
        this.game.load.spritesheet('top_of_list', 'assets/online/plays/top_of_list.png',620,71);
        this.game.load.spritesheet('onlineBottomOfList', 'assets/online/plays/bottom_of_list.png');
        this.game.load.spritesheet('isnull', 'assets/online/plays/empty.png');
        this.game.load.spritesheet('btn_eye', 'assets/online/plays/eye.png', 62, 48);
        this.game.load.spritesheet('btn_status', 'assets/online/plays/img_status.png', 103, 84);
        this.game.load.spritesheet('onlineLibSlide', 'assets/online/plays/slide.png');
        this.game.load.spritesheet('avatar_default', 'assets/online/plays/avatar_default.png');

        /* Operator */
        ToanThanToc.game.load.spritesheet('btn_addition', 'assets/online/selects/addition.png',33, 35);
        ToanThanToc.game.load.spritesheet('btn_subtraction', 'assets/online/selects/subtract.png', 33, 35);
        ToanThanToc.game.load.spritesheet('btn_multiplication', 'assets/online/selects/multiplication.png', 33, 35);
        ToanThanToc.game.load.spritesheet('btn_division', 'assets/online/selects/division.png', 33, 35);

        //iconTeam
        ToanThanToc.game.load.spritesheet('1', 'assets/online/plays/team_1.png');
        ToanThanToc.game.load.spritesheet('2', 'assets/online/plays/team_2.png');
        ToanThanToc.game.load.spritesheet('3', 'assets/online/plays/team_3.png');
        ToanThanToc.game.load.spritesheet('4', 'assets/online/plays/team_4.png');
        ToanThanToc.game.load.spritesheet('5', 'assets/online/plays/team_5.png');
        ToanThanToc.game.load.spritesheet('6', 'assets/online/plays/team_6.png');
        ToanThanToc.game.load.spritesheet('7', 'assets/online/plays/team_7.png');
        ToanThanToc.game.load.spritesheet('8', 'assets/online/plays/team_8.png');
        ToanThanToc.game.load.spritesheet('9', 'assets/online/plays/team_9.png');

        // medal
        ToanThanToc.game.load.spritesheet('1medals', 'assets/online/room-play/1medals.png');
        ToanThanToc.game.load.spritesheet('2medals', 'assets/online/room-play/2medals.png');
        ToanThanToc.game.load.spritesheet('3medals', 'assets/online/room-play/3medals.png');
        ToanThanToc.game.load.spritesheet('4medals', 'assets/online/room-play/4medals.png');
        ToanThanToc.game.load.spritesheet('5medals', 'assets/online/room-play/5medals.png');
        ToanThanToc.game.load.spritesheet('6medals', 'assets/online/room-play/6medals.png');
        ToanThanToc.game.load.spritesheet('7medals', 'assets/online/room-play/7medals.png');
        ToanThanToc.game.load.spritesheet('8medals', 'assets/online/room-play/8medals.png');
        ToanThanToc.game.load.spritesheet('9medals', 'assets/online/room-play/9medals.png');
        ToanThanToc.game.load.spritesheet('10medals', 'assets/online/room-play/10medals.png');



        ToanThanToc.game.load.spritesheet('item_room1', 'assets/online/selects/room1.png');
        ToanThanToc.game.load.spritesheet('btn_exit', 'assets/online/share/exit.png', 479, 98);
        ToanThanToc.game.load.spritesheet('item_room2', 'assets/online/selects/room2.png');

        ToanThanToc.game.load.spritesheet('logoNAHI', 'assets/online/backgrounds/logo-NAHI.png');
        ToanThanToc.game.load.spritesheet('logo-vnn', 'assets/online/backgrounds/logo-vnm.png');

//        ToanThanToc.game.load.spritesheet('bgnull', 'assets/online/backgrounds/bgNull.png');




        /** Load image keyboard lib */
        this.game.load.spritesheet("kb_background",'assets/online/keyboard/background.png');
        this.game.load.spritesheet('kb_button','assets/online/keyboard/button.png',80,119); // Load Button.
        this.game.load.spritesheet('kb_capLock','assets/online/keyboard/buttonCaplock.png',81,119); // Load Button.
        this.game.load.spritesheet('kb_ok','assets/online/keyboard/buttonOk.png',113,118); // Load Button.
        this.game.load.spritesheet('kb_spaceBar','assets/online/keyboard/buttonSpaceBar.png',113,118); // Load Button.
        this.game.load.spritesheet('kb_edit','assets/online/keyboard/editText.png');
        this.game.load.bitmapFont('keyboard', 'assets/online/bitmap-font/keyboard.png','assets/online/bitmap-font/keyboard.xml');

        /** Load image keyboard lib end */

    },

    create: function () {
        ToanThanToc.Loader.prototype.SetCss();
    },
    SetCss:function(){
        $('#gameMath').css({
            'display': 'block',
            'position': 'absolute',
            'width':ToanThanToc.innerWidth,
            'height':ToanThanToc.innerHeight,
            'z-index': '1010'
        });
        setTimeout(function(){
            if( ToanThanToc.innerWidth>800)
                ToanThanToc.widthPerFect = (ToanThanToc.innerWidth - parseInt($("#gameMath canvas").css("width").replace('px','')))/2;
            else
                ToanThanToc.widthPerFect=0;

            ToanThanToc.heighPerFect = ToanThanToc.innerHeight - parseInt($("#gameMath canvas").css("height").replace('px','')) ;
            ToanThanToc.heighPerFect = ToanThanToc.heighPerFect>0?ToanThanToc.heighPerFect:-ToanThanToc.heighPerFect;
            log('  ToanThanToc.heighPerFect = '+  ToanThanToc.heighPerFect );

            if(ToanThanToc.innerHeight==1232&&ToanThanToc.innerWidth==800) ToanThanToc.heighPerFect=0;

        },50);
    },
    update: function () {
        if(this.CheckDecoded() && this.ready == false)
        {
            ToanThanToc.waiting.close();
            ToanThanToc.Loader.prototype.preloadBar.cropEnabled = false;
            ToanThanToc.Loader.prototype.bck.destroy();
            ToanThanToc.Loader.prototype.preloadBar.destroy();
            log('play video');
            this.ready = true;
            ToanThanToc.game.state.start('FlashIntro');
        }
    },
    CheckCanPlayAudio : function(name) {
        var ret = false;
        var options = this.GetAudioArray();
        for(var item in options)
        {
            if(ToanThanToc.game.device.canPlayAudio(options[item]))
            {
                ret = true;
                break;
            }
        }
        return ret;
    },
    GetAudioArray : function(name) {
        //var options = ['ogg', 'mp3', 'wav'];
        //var options = ['wav'];
        var options = ['mp3'];
        return options;
    },
    BuildAudioArray : function(name) {
        var ret = [];
        var options = this.GetAudioArray();

        for(var opt in options)
        {
            ret[ret.length] = name + '.' + options[opt];
        }
        return ret;
    },
    CheckDecoded : function()
    {
        var ret = true;
        ret &= this.cache.isSoundDecoded(ToanThanToc.music_lose);
        ret &= this.cache.isSoundDecoded(ToanThanToc.music_music);
        ret &= this.cache.isSoundDecoded(ToanThanToc.music_popupMainAction);
        ret &= this.cache.isSoundDecoded(ToanThanToc.music_popupQuit);
        ret &= this.cache.isSoundDecoded(ToanThanToc.music_touch);
        ret &= this.cache.isSoundDecoded(ToanThanToc.music_win);
        ret &= this.cache.isSoundDecoded(ToanThanToc.music_wrong);

        if(ret == false && !this.CheckCanPlayAudio())
            ret = true;

        return ret;
    }
};



