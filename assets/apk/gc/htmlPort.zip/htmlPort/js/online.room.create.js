/**
 * Created by TILE on 12/8/14.
 */

/*  */
"use strict";

/* Create constructor of screen CreateRoom. */
ToanThanToc.CreateRoom = function (game) {};
ToanThanToc.CreateRoom.prototype={


    /* Position  */
     x : 365,
     y : 260,
    /* Group mode game play. */
     arrayMode : [
        {id: 0, isView: true, name: 'onlineEasy', x: 365, y: (260 + 170)},
        {id: 1, isView: false, name: 'onlineMedium', x: (365 + 125), y: (260 + 170)},
        {id: 2, isView: false, name: 'onlineHigh', x: (365 + 250), y: (260 + 170)}],
     arrayModeVariable : [],// Save variable.
    /* Group operation. */
     arrayOperation : [
        {id: 0, isView: true, name: 'onlineAddition', x: 365, y: (260 + 282)},
        {id: 1, isView: false, name: 'onlineSubtraction', x: (365 + 90), y: (260 + 282)},
        {id: 2, isView: false, name: 'onlineDivision', x: (365 + 180), y: (260 + 282)},
        {id: 3, isView: false, name: 'onlineMultiplication', x: (365 + 270), y: (260 + 282)}
    ],
     arrayOperationVariable : [],
    /* Group check box */
     arrayCheckBox : [
        {id: 0, isView: false, name: 'onlineCheckboxPass'},
        {id: 1, isView: false, name: 'onlineCheckbox'}
    ],

    /* Variable checkBox. */
     cbPassword:null,
     cbFree:null,
     password : null,
     roomName:null,
     textmk:null,
     txtPassword:null,
     txtStar:null,
     inputPassword:null,
     passwordText : null,
     txtNameRoom:null,
     inputStar:null,
     btnOkay:null,
     txtMinLevel:null,
     minimumLevel:null,


// Slider.
     sliderTime:undefined,
     sliderNumbersTeam:undefined,
     sliderPeopleInTeam:undefined,
     numberTeamItemY : 835,
     teamPeopleItemY : 918,
     arrayContent : [2, 3, 5, 7, 9],
     arrayContentTeamPeople : [1, 2, 3, 5],
     groups:null,
     background:null,
     keyboard : null,
     checkInput : -1,
     back:null,
     info:null,

    preload : function () {

        if( ToanThanToc.game.cache.checkImageKey('onlineBgCreateRoom') &&
            ToanThanToc.game.cache.checkImageKey('onlineTextName') &&
            ToanThanToc.game.cache.checkImageKey('onlineCheckboxPass') &&
            ToanThanToc.game.cache.checkImageKey('onlineEasy') &&
            ToanThanToc.game.cache.checkImageKey('onlineMedium') &&
            ToanThanToc.game.cache.checkImageKey('onlineHigh') &&
            ToanThanToc.game.cache.checkImageKey('onlineAddition') &&
            ToanThanToc.game.cache.checkImageKey('onlineMultiplication') &&
            ToanThanToc.game.cache.checkImageKey('onlineDivision') &&
            ToanThanToc.game.cache.checkImageKey('onlineSubtraction') &&
            ToanThanToc.game.cache.checkImageKey('onlineOkay') &&
            ToanThanToc.game.cache.checkImageKey('onlineLeft')){
            return;
        }



        /* Load image for screen create room of the game. */
        ToanThanToc.game.load.image('onlineBgCreateRoom', 'assets/online/creates/create_room_bg.png');
        ToanThanToc.game.load.spritesheet('onlineTextName', 'assets/online/creates/create_room_input_name_dim.png',354,72);
        ToanThanToc.game.load.spritesheet('onlineCheckboxPass', 'assets/online/creates/create_room_checkbox.png', 63, 58);
        ToanThanToc.game.load.spritesheet('onlineCheckbox', 'assets/online/creates/checkbox.png', 83, 77);
        ToanThanToc.game.load.spritesheet('onlineEasy', 'assets/online/creates/create_room_easy.png', 103, 96);
        ToanThanToc.game.load.spritesheet('onlineMedium', 'assets/online/creates/create_room_medium.png', 103, 96);
        ToanThanToc.game.load.spritesheet('onlineHigh', 'assets/online/creates/create_room_high.png', 103, 96);
        ToanThanToc.game.load.spritesheet('onlineAddition', 'assets/online/creates/create_room_addition.png', 86, 80);
        ToanThanToc.game.load.spritesheet('onlineMultiplication', 'assets/online/creates/create_room_multiplication.png', 86, 80);
        ToanThanToc.game.load.spritesheet('onlineDivision', 'assets/online/creates/create_room_division.png', 86, 80);
        ToanThanToc.game.load.spritesheet('onlineSubtraction', 'assets/online/creates/create_room_subtraction.png', 86, 80);
        ToanThanToc.game.load.image('onlineStar', 'assets/online/creates/create_room_input_star.png');
        ToanThanToc.game.load.spritesheet('onlineOkay', 'assets/online/creates/create_room_ok.png', 479, 98);
        ToanThanToc.game.load.spritesheet('onlineLeft', 'assets/online/creates/left.png',46,60);
        ToanThanToc.game.load.spritesheet('onlineRight', 'assets/online/creates/right.png',46,60);
        ToanThanToc.game.load.spritesheet('onlineTextmk', 'assets/online/creates/textMK.png',156,48);
        ToanThanToc.game.load.spritesheet('onlineBtnBackCreateRoom', 'assets/online/creates/btn_back.png',105,115);
        ToanThanToc.game.load.spritesheet('onlineBtnInfo', 'assets/online/creates/btn_info.png',105,115);

        ToanThanToc.CreateRoom.prototype.keyboard = new KeyboardLib(ToanThanToc.game);
        ToanThanToc.CreateRoom.prototype.keyboard.loadContent();

    },

    /* Method load.  */
    create : function() {

         var game=ToanThanToc.CreateRoom.prototype;
        game.groups = ToanThanToc.game.add.group();

        game.background = ToanThanToc.game.add.image(0, 0, 'onlineBgCreateRoom');
        game.groups.add(this.background);
        game.btnOkay = ToanThanToc.game.add.button(169, 1088, 'onlineOkay', this.actionCreateClick, {}, 0, 0, 1, 0);
        game.btnOkay.inputEnabled = true;
        game.groups.add(game.btnOkay);
        game.roomName = ToanThanToc.game.add.sprite(365, 260, 'onlineTextName');
        game.roomName.inputEnabled = true;
        game.roomName.events.onInputDown.add(this.addRoomNamePress);
        game.groups.add(game.roomName);
        game.cbPassword = ToanThanToc.game.add.button(91, 353, game.arrayCheckBox[0].name,
            this.actionCheckBoxClick, {id: 0}, 0, 0, 0, 0);
        game.groups.add(game.cbPassword);
        game.inputPassword = ToanThanToc.game.add.sprite(365 , 260 + 85, 'onlineTextName');
        game.inputPassword.frame=1;
        game.groups.add(game.inputPassword);
        game.inputPassword.inputEnabled = false;
        game.textmk=ToanThanToc.game.add.sprite(184, 358, 'onlineTextmk');
        game.textmk.frame=1;
        game.groups.add(game.textmk);
        game.back = ToanThanToc.game.add.button(14, 15, 'onlineBtnBackCreateRoom',
        this.actionOnClickBack, this, 0,0,1);
        game.groups.add(game.back);
        //game.info = ToanThanToc.game.add.sprite(687,15, 'onlineBtnInfo');
        //game.groups.add(game.info);
        game.info = ToanThanToc.game.add.button(687, 15, 'onlineBtnInfo',
        this.actionOnclickInfo, this, 0,0,1);
        game.groups.add(game.info);
        // Scroll time.
        game.sliderTime = new LibHorizontalScroll();
        game.sliderTime.create(ToanThanToc.game,game);
        // Scroll team number.
        game.sliderNumbersTeam = new LibHorizontalScroll();
        game.sliderNumbersTeam.firstLoad(game.numberTeamItemY, game.arrayContent);
        game.sliderNumbersTeam.create(ToanThanToc.game,game);
        //Scroll team people
        game.sliderPeopleInTeam = new LibHorizontalScroll();
        game.sliderPeopleInTeam.firstLoad(game.teamPeopleItemY, game.arrayContentTeamPeople);
        game.sliderPeopleInTeam.create(ToanThanToc.game,game);







        /* Add mode */
        for (var mode in ToanThanToc.CreateRoom.prototype.arrayMode) {
            var modes;
            if (mode == 0) {
                modes = ToanThanToc.game.add.button(ToanThanToc.CreateRoom.prototype.arrayMode[mode].x, ToanThanToc.CreateRoom.prototype.arrayMode[mode].y, ToanThanToc.CreateRoom.prototype.arrayMode[mode].name,
                    ToanThanToc.CreateRoom.prototype.actionModeClick, {id: mode}, 1, 1, 1, 1);
            } else {
                modes = ToanThanToc.game.add.button(ToanThanToc.CreateRoom.prototype.arrayMode[mode].x, ToanThanToc.CreateRoom.prototype.arrayMode[mode].y, ToanThanToc.CreateRoom.prototype.arrayMode[mode].name,
                    ToanThanToc.CreateRoom.prototype.actionModeClick, {id: mode}, 0, 0, 1);
            }
            ToanThanToc.CreateRoom.prototype.groups.add(modes);
            ToanThanToc.CreateRoom.prototype.arrayModeVariable[mode] = modes;
        }


        /* Add operation. */
        for (var n in ToanThanToc.CreateRoom.prototype.arrayOperation) {
            var btnOperation;
            if (n == 0) {
                btnOperation = ToanThanToc.game.add.button(ToanThanToc.CreateRoom.prototype.arrayOperation[n].x, ToanThanToc.CreateRoom.prototype.arrayOperation[n].y,ToanThanToc.CreateRoom.prototype.arrayOperation[n].name,
                    ToanThanToc.CreateRoom.prototype.actionOperationClick, {id: ToanThanToc.CreateRoom.prototype.arrayOperation[n].id}, 1, 1, 1, 1);
            } else {
                btnOperation = ToanThanToc.game.add.button(ToanThanToc.CreateRoom.prototype.arrayOperation[n].x, ToanThanToc.CreateRoom.prototype.arrayOperation[n].y, ToanThanToc.CreateRoom.prototype.arrayOperation[n].name,
                    ToanThanToc.CreateRoom.prototype.actionOperationClick, {id: ToanThanToc.CreateRoom.prototype.arrayOperation[n].id}, 0, 0, 0);
            }
            ToanThanToc.CreateRoom.prototype.groups.add(btnOperation);
            ToanThanToc.CreateRoom.prototype.arrayOperationVariable[n] = btnOperation;
        }

        game.minimumLevel = ToanThanToc.game.add.sprite(365, 636, 'onlineTextName');
        game.groups.add(game.minimumLevel);
        game.inputStar = ToanThanToc.game.add.image(75, 982, 'onlineStar');
        game.inputStar.inputEnabled = true;
        game.inputStar.events.onInputDown.add(this.addStarText);
        game.groups.add(game.inputStar);

        game.cbFree = ToanThanToc.game.add.button(516, 979, game.arrayCheckBox[1].name,
            this.actionCheckBoxClick, {id: 1}, 0, 0, 1, 0);
        game.groups.add(game.cbFree);



        game.txtNameRoom = ToanThanToc.game.add.text(game.roomName.x + (game.roomName.width / 2),
                game.roomName.y + (game.roomName.height / 2)-3, '',{fill:'#ffffff',font:'bold 35px Segoe UI'});
        game.txtNameRoom.anchor.set(0.5, 0.5);
        game.groups.add(game.txtNameRoom);


        game.txtPassword = ToanThanToc.game.add.text(game.inputPassword.x + (game.inputPassword.width / 2),
                game.inputPassword.y + (game.inputPassword.height / 2)-5, '',{fill:'#ffffff',font:'bold 40px Segoe UI'});
        game.txtPassword.anchor.set(0.6, 0.3);
        game.groups.add(this.txtPassword);
        game.txtStar = ToanThanToc.game.add.text(game.inputStar.x + (game.inputStar.width / 2)+5,
                game.inputStar.y + (game.inputStar.height / 2)-8, '',{fill:'#ffffff',font:'bold 35px Segoe UI'});
        game.txtStar.anchor.set(0.5, 0.3);
        game.groups.add(game.txtStar);

        game.txtMinLevel = ToanThanToc.game.add.text(game.minimumLevel.x + (game.minimumLevel.width / 2),
                game.minimumLevel.y + (game.minimumLevel.height / 2)-8, '',{fill:'#ffffff',font:'bold 35px Segoe UI'});
        game.txtMinLevel.anchor.set(0.6, 0.3);
        game.groups.add(this.txtMinLevel);
        game.minimumLevel.inputEnabled = true;
        game.minimumLevel.events.onInputDown.add(this.addLevelPress);

        // Truyen ham call back vao de khi nhan OK thi goi tra lai
        var keyboardCallback = function (str) {

            ToanThanToc.CreateRoom.prototype.btnOkay.visible = true;
            ToanThanToc.CreateRoom.prototype.inputStar.visible = true;

            switch (ToanThanToc.CreateRoom.prototype.checkInput) {
                case 0:
                    ToanThanToc.CreateRoom.prototype.txtPassword.text = '';
                    ToanThanToc.CreateRoom.prototype.passwordText = str;
                    for (var i = 0; i < str.length; ++i) {
                        ToanThanToc.CreateRoom.prototype.txtPassword.text += '*';
                    }
                    break;
                case 1:
                    ToanThanToc.CreateRoom.prototype.txtStar.text = str;
                    break;
                case 2:
                    ToanThanToc.CreateRoom.prototype.txtMinLevel.text = str;
                    break;
                case 3:
                    ToanThanToc.CreateRoom.prototype.txtNameRoom.text = str;
                    ToanThanToc.CreateRoom.prototype.txtNameRoom.fontSize=(ToanThanToc.CreateRoom.prototype.txtNameRoom.width >330)?28:(ToanThanToc.CreateRoom.prototype.txtNameRoom.width>280)?35:40;

                
                    break;
                default :
                    break;
            }
        };

        ToanThanToc.CreateRoom.prototype.keyboard.create(keyboardCallback);


    },


    /** Get text from keyboard for password. */
    //ToanThanToc.CreateRoom.prototype.addPasswordPress = function(char) {
    //
    //};

    /* */
    addPasswordText : function() {
        //log(passwordText.charCodeAt(0));
        ToanThanToc.CreateRoom.prototype.checkInput = 0;
        ToanThanToc.CreateRoom.prototype.keyboard.addCheck(false, 5);
        if (!ToanThanToc.CreateRoom.prototype.arrayCheckBox[0].isView) {
            ToanThanToc.CreateRoom.prototype.arrayCheckBox[0].isView = true;
            ToanThanToc.CreateRoom.prototype.cbPassword.setFrames(1, 1, 0, 1);
        }
        // Add keyboard.
        ToanThanToc.CreateRoom.prototype.addKeyboard();
        ToanThanToc.game.inputEnabled = true;
    },

    /** event when click n_ */
    addStarText : function() {
        ToanThanToc.CreateRoom.prototype.checkInput = 1;
        ToanThanToc.CreateRoom.prototype.keyboard.addCheck(true, 5);
        // Add keyboard.
        ToanThanToc.CreateRoom.prototype.addKeyboard();
        ToanThanToc.game.inputEnabled = true;
    },



    /**
     * Press room name.
     */
    addRoomNamePress : function() {
        ToanThanToc.CreateRoom.prototype.addKeyboard();
        ToanThanToc.CreateRoom.prototype.checkInput = 3;
        ToanThanToc.CreateRoom.prototype.keyboard.addCheck(false, 14);
    },

    /**
     * Add level press.
     */
     addLevelPress : function() {
        // Add keyboard.
        ToanThanToc.CreateRoom.prototype.addKeyboard();
        ToanThanToc.CreateRoom.prototype.checkInput = 2;
        ToanThanToc.CreateRoom.prototype.keyboard.addCheck(true, 2);
        ToanThanToc.game.inputEnabled = true;
    },



    /* Method update */
    update : function () {


    },

    /* Method check box click. */
    actionCheckBoxClick : function () {
        shareFunction.actionPlayAudio('touch');
        if (ToanThanToc.CreateRoom.prototype.arrayCheckBox[this.id].isView) {
            ToanThanToc.CreateRoom.prototype.arrayCheckBox[this.id].isView = false;
            if (this.id == 1) {
                ToanThanToc.CreateRoom.prototype.cbFree.setFrames(0, 0, 1, 0);
                ToanThanToc.CreateRoom.prototype.sliderPeopleInTeam.checkFreeRoom = undefined;
            } else {
                ToanThanToc.CreateRoom.prototype.cbPassword.setFrames(0, 0, 1, 0);

            }
        } else {
            ToanThanToc.CreateRoom.prototype.arrayCheckBox[this.id].isView = true;
            if (this.id == 1) {
                ToanThanToc.CreateRoom.prototype.cbFree.setFrames(1, 1, 0, 1);
                ToanThanToc.CreateRoom.prototype.sliderPeopleInTeam.checkFreeRoom = 1;
                ToanThanToc.CreateRoom.prototype.sliderPeopleInTeam.setIndexItem();
            } else {
                ToanThanToc.CreateRoom.prototype.cbPassword.setFrames(1, 1, 0, 1);
            }
        }
        if(ToanThanToc.CreateRoom.prototype.cbPassword.frame==0)
        {
            ToanThanToc.CreateRoom.prototype.txtPassword.text='';
            ToanThanToc.CreateRoom.prototype.textmk.frame=1;
            ToanThanToc.CreateRoom.prototype.inputPassword.frame=1;
            ToanThanToc.CreateRoom.prototype.inputPassword.inputEnabled=false;
        }
        else if(ToanThanToc.CreateRoom.prototype.cbPassword.frame==1)
        {
            ToanThanToc.CreateRoom.prototype.textmk.frame=0;
            ToanThanToc.CreateRoom.prototype.inputPassword.frame=0;
            ToanThanToc.CreateRoom.prototype.inputPassword.inputEnabled=true;
            ToanThanToc.CreateRoom.prototype.inputPassword.events.onInputDown.add(ToanThanToc.CreateRoom.prototype.addPasswordText);
        }

    },

    /* Method mode click. */
    actionModeClick : function () {
        shareFunction.actionPlayAudio('touch');
    if (ToanThanToc.CreateRoom.prototype.arrayMode[this.id].isView) {
        // Do nothing.
    } else {
        /* Set ToanThanToc.CreateRoom.prototype.id is view. */
        ToanThanToc.CreateRoom.prototype.arrayModeVariable[this.id].setFrames(1, 1, 1, 1);
        ToanThanToc.CreateRoom.prototype.arrayMode[this.id].isView = true;
        /* disable for all another one. */
        for (var i = 0; i < ToanThanToc.CreateRoom.prototype.arrayMode.length; i++) {
            if (i != this.id) {
                ToanThanToc.CreateRoom.prototype.arrayModeVariable[i].setFrames(0, 0, 1);
                ToanThanToc.CreateRoom.prototype.arrayMode[i].isView = false;
            }
        }
    }

},


    /**
     * Get mode.
     * @returns {string}
     */
    getMode : function() {
        var mode = '';
        var n = 0;
        for (n; n < ToanThanToc.CreateRoom.prototype.arrayMode.length; ++n) {
            if (ToanThanToc.CreateRoom.prototype.arrayMode[n].isView) {
                mode = ToanThanToc.CreateRoom.prototype.checkResult(n);
            }
        }


        return mode;
    },


    /**
     * Check result.
     * @param index
     * @returns {string}
     */
    checkResult : function(index) {
        if (index == 0) {
            return 'EASY';
        } else if (index == 1) {
            return 'MEDIUM';
        } else {
            return 'HARD';
        }
    },

    actionOnClickBack :function () {
        shareFunction.actionPlayAudio('touch');
        ToanThanToc.nameSpace = 'back';
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("MenuOnline");
    },
    /* Method operation click */
    actionOperationClick : function () {
        shareFunction.actionPlayAudio('touch');
        var flag = false;
        if (ToanThanToc.CreateRoom.prototype.arrayOperation[this.id].isView) {
            for (var i = 0; i < ToanThanToc.CreateRoom.prototype.arrayOperation.length; i++) {
                if (i != this.id) {
                    if (ToanThanToc.CreateRoom.prototype.arrayOperation[i].isView) {
                        flag = true;
                        break;
                    }
                }
            }
            if (flag) {
                ToanThanToc.CreateRoom.prototype.arrayOperationVariable[this.id].setFrames(0, 0, 1, 0);
                ToanThanToc.CreateRoom.prototype.arrayOperation[this.id].isView = false;
            }
        } else {
            ToanThanToc.CreateRoom.prototype.arrayOperationVariable[this.id].setFrames(1, 1, 0, 1);
            ToanThanToc.CreateRoom.prototype.arrayOperation[this.id].isView = true;
        }
    },

    /**
     * Get Operator.
     * @returns {string}
     */
    getOperator : function() {
        var operator = '';
        var n = 0;
        for (n; n < ToanThanToc.CreateRoom.prototype.arrayOperation.length; ++n) {
            if (ToanThanToc.CreateRoom.prototype.arrayOperation[n].isView) {
                operator += '1';
            } else {
                operator += '0';
            }
        }

        return operator;
    },


    /* Method create room click. */
    actionCreateClick : function() {
        ToanThanToc.CreateRoom.prototype.createRoomCallback;
        shareFunction.actionPlayAudio('touch');
        var name = ToanThanToc.CreateRoom.prototype.txtNameRoom.text;
        var mode = ToanThanToc.CreateRoom.prototype.getMode();
        var operator = ToanThanToc.CreateRoom.prototype.getOperator();
        var minLevel = 1; // Default
        var timeLimit = ToanThanToc.CreateRoom.prototype.sliderTime.getDataOfItem();
        var teamLimit = ToanThanToc.CreateRoom.prototype.sliderNumbersTeam.getDataOfItem();
        var memberPerTeam = ToanThanToc.CreateRoom.prototype.sliderPeopleInTeam.getDataOfItem();
        var starPerMember = 10;
        var hasPassword = false;
        var free = false;



        try {
            starPerMember = parseInt(ToanThanToc.CreateRoom.prototype.txtStar.text);
            minLevel = parseInt(ToanThanToc.CreateRoom.prototype.txtMinLevel.text);
        } catch (exception) {
            console.log(exception);
        }

        if (ToanThanToc.CreateRoom.prototype.arrayCheckBox[1].isView) {
            free = true;
            memberPerTeam = 1;
        }
        if (ToanThanToc.CreateRoom.prototype.arrayCheckBox[0].isView) {
            ToanThanToc.CreateRoom.prototype.password = ToanThanToc.CreateRoom.prototype.passwordText.trim();
            hasPassword = true;
        }

        var data = {
            token: xAuthToken, name: name, password: ToanThanToc.CreateRoom.prototype.password, mode: mode,
            operator: operator, minLevel: minLevel, timeLimit: timeLimit,
            teamLimit: teamLimit, memberPerTeam: memberPerTeam,
            starPerMember: starPerMember, free: free, hasPassword: hasPassword
        };

        var p = new Popup();
        if(name.length < 3){
            p.setMain(ToanThanToc.game,'','','popup','popupClose',[{x:-150,y:20}],null,[]);
            p.setText([{x:0,y:-100}],['Tên phòng phải có 3 ký tự trở lên.'],[{fill:'#ffffff',font:'35px Segoe UI',align:'center'}]);
            p.createPopup(350,350);
            p.openWindow();
        }else if(isNaN(starPerMember) || (starPerMember < 10)){
            p.setMain(ToanThanToc.game,'','','popup','popupClose',[{x:-150,y:20}],null,[]);
            p.setText([{x:0,y:-100}],['Số tiền đặt cược ít nhất là 10.'],[{fill:'#ffffff',font:'35px Segoe UI',align:'center'}]);
            p.createPopup(350,350);
            p.openWindow();
        }else if(isNaN(minLevel) || (minLevel < 1)){
            p.setMain(ToanThanToc.game,'','','popup','popupClose',[{x:-150,y:20}],null,[]);
            p.setText([{x:0,y:-100}],['Cấp tối thiểu vào phòng phải lớn hơn 0.'],[{fill:'#ffffff',font:'35px Segoe UI',align:'center'}]);
            p.createPopup(350,350);
            p.openWindow();
        }
        else{
            Socket.execute(function (socket) {
                socket.post(domainAPI + urlCreateRoom, data, ToanThanToc.CreateRoom.prototype.createRoomCallback);
            });
        }


    },


    /**
     * Callback create room.
     * @param data
     */
    createRoomCallback : function(data) {
        if (data.stateCode == 200) {
            for(var i=0;i<((data.result).players).length;i++)
            {
                ToanThanToc.dataAvatar.push(
                    [(data.result).players[i].avatar_url,(data.result).players[i].id]

                );

            }
            for(var i=0;i<((data.result).viewers).length;i++)
            {

                ToanThanToc.dataAvatar.push(
                    [(data.result).viewers[i].avatar_url,(data.result).viewers[i].id]

                );

            }
            ToanThanToc.data = {id:data.result.id, password: ToanThanToc.CreateRoom.prototype.password};
            ToanThanToc.OnlineRoomWaiting.prototype.dataWaitingRoom = data.result;
            ToanThanToc.game.stage.destroy();
            ToanThanToc.nameSpace = 'waitingRoom'; // Set nameSpace.
            ToanThanToc.game.state.start("OnlineRoomWaiting");
        }else{
            var p = new Popup();
            p.setMain(ToanThanToc.game,'Error Create Room','','popup','popupClose',[{x:-150,y:20}],null,[]);
            p.setText([{x:0,y:-100}],[JSON.stringify(data.result)],[{fill:'#ffffff',font:'35px Segoe UI',align:'center'}]);
            p.createPopup(350,350);
            p.openWindow();
        }
    },

    /**
     * Action onclick Info
     */

    actionOnclickInfo: function () {
        shareFunction.actionPlayAudio('touch');
    },

    /**
     * slider onclick back
     * use in lib.list.scroll.js
     */

    sliderOnclickBack: function () {
        shareFunction.actionPlayAudio('touch');
    },

    /**
     * slider onclick next
     * use in lib.list.scroll.js
     */

    sliderOnclickNext: function () {
        shareFunction.actionPlayAudio('touch');
    },


    /**
     * Add keyboard.
     */
    addKeyboard : function() {
        if (ToanThanToc.CreateRoom.prototype.keyboard != null &&
            !ToanThanToc.CreateRoom.prototype.keyboard.groups.visible) {
            ToanThanToc.CreateRoom.prototype.keyboard.groups.visible = true;
            ToanThanToc.CreateRoom.prototype.btnOkay.visible = false;
            ToanThanToc.CreateRoom.prototype.inputStar.visible = false;
        }
    },


    /**
     * Destroy.
     */
    destroy : function() {
        ToanThanToc.CreateRoom.prototype.sliderTime.destroy();
        ToanThanToc.CreateRoom.prototype.groups.destroy();
        ToanThanToc.CreateRoom.prototype.sliderNumbersTeam.destroy();
        ToanThanToc.CreateRoom.prototype.sliderPeopleInTeam.destroy();
        ToanThanToc.CreateRoom.prototype.arrayCheckBox = null;
        ToanThanToc.CreateRoom.prototype.arrayMode = null;
        ToanThanToc.CreateRoom.prototype.arrayModeVariable = null;
        ToanThanToc.CreateRoom.prototype.arrayOperation = null;
        ToanThanToc.CreateRoom.prototype.arrayOperationVariable = null;
        ToanThanToc.CreateRoom.prototype.keyboard.destroy();
    }

};