/**
 *
 * @param stringInput
 * @param positionStartX
 * @param xRadius
 * @param yRadius
 * @param r
 * @param group
 */
function drawTextRoof2(stringInput, positionStartX, xRadius, yRadius, r, group) {
    if (stringInput.length > 0) {
        var temp = positionStartX;
        for (var index = 0; index < stringInput.length; index++) {
            temp += 20;
            var y = (yRadius - Math.sqrt(r * r - (temp - xRadius) * (temp - xRadius)));
            var angle = 2 * index + 1 - stringInput.length;
            var text = SmartPlus.game.add.text(temp, y, stringInput.substr(index, 1), {'font-family': "Arial Black", fill: "#fff"});
            text.setShadow(3, 3, 'rgba(0, 0, 0, 1)', 0);
            text.fontSize = 25;
            text.fontWeight = 'bold';
            text.stroke = '#553727';
            text.strokeThickness = 5;
            text.anchor.set(0.5);
            text.angle = angle;
            group.add(text);
        }
    }
}

/**
 *
 * @param array
 * @param type
 */
function visible(array, type){
    if(Object.keys(array).length > 0){
        for(var i = 0; i < Object.keys(array).length; i++){
            array[i].visible = type;
        }
    }
}

this.drawTextRoof = function(stringInput, positionStartX, xRadius, yRadius, r, arrayObject) {
    if (stringInput.length > 0) {
        var temp = positionStartX;
        for (var index = 0; index < stringInput.length; index++) {
            temp += 20;
            var y = (yRadius - Math.sqrt(r * r - (temp - xRadius) * (temp - xRadius)));
            var angle = 2 * index + 1 - stringInput.length;
            var text = SmartPlus.game.add.text(temp, y, stringInput.substr(index, 1), {'font-family': "Arial Black", fill: "#fff"});
            text.setShadow(3, 3, 'rgba(0, 0, 0, 1)', 0);
            text.fontSize = 25;
            text.fontWeight = 'bold';
            text.stroke = '#553727';
            text.strokeThickness = 5;
            text.anchor.set(0.5);
            text.angle = angle;
            arrayObject[Object.keys(arrayObject).length] = text;
        }
    }
};

function destroyArray(array){
    if(Object.keys(array).length > 0){
        for(var i = 0; i < Object.keys(array).length; i++){
            array[i].destroy();
        }
    }
}