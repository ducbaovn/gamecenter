/**
 * Created by TILE on 09/01/15.
 */
"use strict";

var tabFocus = 'player';

ToanThanToc.OnlinePlayingRoom = function(_game){

};


ToanThanToc.OnlinePlayingRoom.prototype = {

    /* ---------------------------- VARIABLE -------------------------------- */

    backgroundRoomPlaying: null,
    tabPlayer: null,
    tabFollow: null,
    checkTabs: false, // Nguoi choi.
    expImage: null,
    expText: null,
    timerImage: null,
    timerText: null,
    timerCount: 0,
    questionBoard: null,
    answerBoard1: null,
    answerBoard2: null,
    answerBoard3: null,
    textQuestion1: null,
    textQuestion2: null,
    textAnswer1: null,
    textAnswer2: null,
    textAnswer3: null,
    operator: null,
    textCountViewer: null,
    listPlayer: undefined,
    listFollow: undefined,
    listViewer: undefined,
    answerBoardX: 57,
    answerBoardY: 205,
    questionCount: 0,
    that: this,
    DEBUG: true,
    tweenQuestion: undefined,
    tweenExp: undefined,
    tweenTimer: undefined,
    result1: 0,
    countDown: undefined,
    countAnimate: undefined,
    timer: null,
    //dataTemp:[
    //{"owner":"54b614893933c30d78ce1555",
    //    "mathroom":"54c5f299c6629caabf81c7f4",
    //    "startTime":"2015-01-26T07:55:58.945Z",
    //    "endTime":"2015-01-26T07:55:58.945Z",
    //    "status":"FINISHED","name":"dduuyy",
    //    "memberPerTeam":1,"starPerMember":1,
    //    "nahiRoom":false,"playboards":[{"name":"2","scoreUpdatedAt":"2015-01-26T07:54:38.945Z",
    //    "score":0,"players":[{"id":"54bf1f3dc9bbf70088f86efc","fullname":"nn1@nahi.vn",
    //        "nickname":"nn1@nahi.vn","avatar_url":"","gender":"FEMALE","dob":null,"level":1,
    //        "team":2,"score":0}]},{"name":"1","scoreUpdatedAt":"2015-01-26T07:54:38.945Z",
    //    "score":0,"players":[{"id":"54b614893933c30d78ce1555","fullname":"nahi2@nahi.vn",
    //        "nickname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z",
    //        "level":1,"team":1,"score":0}]}],"winItems":[],"id":"54c5f2bec6629caabf81c7f6"}],
    /* ---------------------------- VARIABLE -------------------------------- */

    /**
     * Load image for Room playing.
     */
    preload: function(){

        if( ToanThanToc.game.cache.checkImageKey('bg_roomPlaying') &&
            ToanThanToc.game.cache.checkImageKey('exp') &&
            ToanThanToc.game.cache.checkImageKey('timer') &&
            ToanThanToc.game.cache.checkImageKey('1medals') &&
            ToanThanToc.game.cache.checkImageKey('10medals') &&
            ToanThanToc.game.cache.checkImageKey('tabs_follow') &&
            ToanThanToc.game.cache.checkImageKey('score_bg') &&
            ToanThanToc.game.cache.checkImageKey('numBoard1')){
            return;
        }
        /* Loading image. */
        ToanThanToc.game.load.spritesheet('bg_roomPlaying', 'assets/online/room-play/bg.png',800,1232);
        ToanThanToc.game.load.spritesheet('exp', 'assets/online/room-play/exp.png');
        ToanThanToc.game.load.spritesheet('timer', 'assets/online/room-play/timer.png');
        ToanThanToc.game.load.spritesheet('answerBoard', 'assets/online/room-play/answerBoard.png',175,109);
        ToanThanToc.game.load.spritesheet('woodBoardOnline', 'assets/online/room-play/woodBoard.png');
        ToanThanToc.game.load.spritesheet('tabs_follow', 'assets/online/room-play/tabs_follow.png',405,90);
        ToanThanToc.game.load.spritesheet('tabs_player', 'assets/online/room-play/tabs_player.png',405,90);
        ToanThanToc.game.load.spritesheet('score_bg', 'assets/online/share/score_bg.png');
        ToanThanToc.game.load.bitmapFont('numBoard1', 'assets/online/bitmap-font/numOk.png','assets/online/bitmap-font/numOk.xml');
    },

    /**
     * Create room playing
     */
    create: function(){

        /*hide button home chat*/
        $('#homeVirtual').hide();

        var that = ToanThanToc.OnlinePlayingRoom.prototype;
        /* ++++++++++++++++ LOAD IMAGE RESULT DETAIL +++++++++++++++ */


/* **************** BACKGROUND AND QUESTION BOARD ******************** */
        that.backgroundRoomPlaying = ToanThanToc.game.add.image(0,0,'bg_roomPlaying');

        /* Set user watch room */
        that.createListViewer(ToanThanToc.dataWatchRoom.viewers);

        that.questionBoard = ToanThanToc.game.add.image(60,655,'woodBoardOnline');

        that.answerBoard1 = ToanThanToc.game.add
            .button(that.answerBoardX,that.answerBoardY,'answerBoard',that.clickCallbackAnswerOne,0,0,0,0);
        that.answerBoard2 = ToanThanToc.game.add
            .button(that.answerBoardX+200,that.answerBoardY,'answerBoard',that.clickCallbackAnswerTwo,0,0,0,0);
        that.answerBoard3 = ToanThanToc.game.add
            .button(that.answerBoardX+400,that.answerBoardY,'answerBoard',that.clickCallbackAnswerThree,0,0,0,0);

        that.questionBoard.addChild(that.answerBoard1);
        that.questionBoard.addChild(that.answerBoard2);
        that.questionBoard.addChild(that.answerBoard3);

        that.textQuestion1 = ToanThanToc.game.add.bitmapText(that.questionBoard.width/2-40,
            that.questionBoard.height/2-30,'numBoard1',ToanThanToc.dataQuestionTemp.terms[0].aValue
            +'  '+ToanThanToc.dataQuestionTemp.terms[0].operator+'  '
            +ToanThanToc.dataQuestionTemp.terms[0].bValue,80);
        that.textQuestion1.x=that.questionBoard.width/2-40-that.textQuestion1.width/2;

            that.textAnswer1 = ToanThanToc.game.add
            .text((that.answerBoard1.width/2), (that.answerBoard1.height/2),'',
                {fill:'#ffffff',font:'bold 55px Segoe UI',align:'center'});
        that.textAnswer1.anchor.set(0.5);
        that.textAnswer2 = ToanThanToc.game.add
            .text((that.answerBoard2.width/2), (that.answerBoard2.height/2),'',
            {fill:'#ffffff',font:'bold 55px Segoe UI',align:'center'});
        that.textAnswer2.anchor.set(0.5);
        that.textAnswer3 = ToanThanToc.game.add
            .text((that.answerBoard3.width/2), (that.answerBoard3.height/2),'',
            {fill:'#ffffff',font:'bold 55px Segoe UI',align:'center'});
        that.textAnswer3.anchor.set(0.5);



        that.answerBoard1.addChild(that.textAnswer1);
        that.answerBoard2.addChild(that.textAnswer2);
        that.answerBoard3.addChild(that.textAnswer3);
        that.questionBoard.addChild(that.textQuestion1);

        that.questionBoard.visible = false;
/* **************** BACKGROUND AND QUESTION BOARD ******************** */

/* ------------------ TIMER AND EXPERIENCE ------------------------- */
        that.timerImage = ToanThanToc.game.add.image(-400,550,'timer');
        that.expImage = ToanThanToc.game.add.image(900,550,'exp');
        that.expText = ToanThanToc.game.add.text(40, 30,'0',{fill:'#ffffff'});
        that.timerText = ToanThanToc.game.add.text(100,30,'',{fill:'#ffffff'});

        that.timerImage.addChild(that.timerText);
        that.expImage.addChild(that.expText);
        that.timerImage.visible = false;
        that.expImage.visible = false;

/* ------------------ TIMER AND EXPERIENCE ------------------------- */


/** ---------------- SHOW LIST PLAYER AND LIST VIEWER ------------- */
        that.showListPlayer(ToanThanToc.dataQuestionTemp.playboards);
/** ---------------- SHOW LIST PLAYER AND LIST VIEWER ------------- */

        /* CountDown */
        that.countDown = ToanThanToc.game.add.sprite(220,610,'countDown');
        that.countAnimate = that.countDown.animations.add('walk');

        that.countAnimate.onStart.add(that.animationStart,ToanThanToc.game);
        that.countAnimate.onLoop.add(that.animationLoop,ToanThanToc.game);
        that.countAnimate.onComplete.add(that.animationStop,ToanThanToc.game);

        /* countdown */
        that.countAnimate.play(1,false);
        /* Add question. */
        that.showQuestion(ToanThanToc.dataQuestionTemp.terms);

        that.CreateNewTime();

    },



    /* ************************* Create ListView ************************** */

    /**
     * Create list Player.
     */

    createListAllPlayer: function(x,y,w,h,z,tag,array,key){

        var that = ToanThanToc.OnlinePlayingRoom.prototype;

        //console.log('create list player '+JSON.stringify(array));
        var arrayFreeRoom = {};
        for(var i = 0; i < array.length;++i){
            var arrayTemp = 0;var temp = i+1;
            var name=array[i].nickname;
            name=name.split('@');
            arrayTemp = [
                { // text Level.
                    xBuffer: 377,
                    yBuffer: 45,
                    name: array[i].level,
                    anchor: 0.5,
                    shadow: '0|0|0|0',
                    property: {font: "bold 30px Segoe UI", fill: "#fff", align: "center"},
                    type: 'text',
                    isShow: 1
                },
                { // score image
                    xBuffer: 528,
                    yBuffer: 7,
                    name: 'score_bg',
                    type: 'image',
                    isShow: 1
                },
                { // score image
                    xBuffer: 10,
                    yBuffer: 85,
                    name: 'list_line',
                    type: 'image',
                    isShow: 1
                },
                { // score text
                    xBuffer: 575,
                    yBuffer: 45,
                    name: (array[i].score=='0')?'0':array[i].score,
                    anchor: 0.5,
                    shadow: '0|0|0|0',
                    property: {font: "bold 30px Segoe UI", fill: "#fff", align: "center"},
                    type: 'text',
                    isShow: 1
                },
                { // Text Name
                    xBuffer: 280,
                    yBuffer: 45,
                    name: name[0],
                    anchor: 0.5,
                    shadow: '0|0|0|0',
                    property: {font: "bold 30px Segoe UI", fill: "#ffffff"},
                    type: 'text',
                    isShow: 1
                },
                { // avatar image
                    xBuffer: 107,
                    yBuffer: 10,
                    name: (array[i] .avatar_url == '') ? 'avatar_default' : array[i].id,
                    width:70,
                    height:70,
                    type: 'avatar', isShow: 1
                },
                { // Image team
                    xBuffer: 444,
                    yBuffer: 20,
                    name: array[i].team,
                    type: 'image',
                    isShow: 1
                },
                { // Image divider
                    xBuffer: 0,
                    yBuffer: 85,
                    name: '',
                    type: 'image',
                    isShow: 1
                }
            ];
            if(i == 2){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: 0,
                        yBuffer: 2,
                        width:85,
                        height:85,
                        name: '3medals',
                        type: 'avatar',
                        isShow: 1
                    }
                );
            }else if(i == 1){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: 0,
                        yBuffer: 2,
                        width:85,
                        height:85,
                        name: '2medals',
                        type: 'avatar',
                        isShow: 1
                    }
                );
            }else if(i == 0){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: 0,
                        yBuffer: 2,
                        width:85,
                        height:85,
                        name: '1medals',
                        type: 'avatar',
                        isShow: 1
                    }
                );
            }else{
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: 0,
                        yBuffer: 0,
                        width:85,
                        height:85,
                        name: temp + 'medals',
                        type: 'avatar',
                        isShow: 1
                    }
                );
            }

            if(arrayTemp){
                arrayFreeRoom[Object.keys(arrayFreeRoom).length] = arrayTemp;
            }

        }

        /* Create List */
        that.listPlayer = new ListScroll(arrayFreeRoom,x, y, w, h,z,tag, that,null,key);
        that.listPlayer.makeList();

        if(tabFocus=='player') {
            that.tabPlayer = ToanThanToc.game.add.button(48, 450, 'tabs_player', that.tabsPlayerCallback, 1, 1, 1, 1);
            that.tabFollow = ToanThanToc.game.add.button(375, 450, 'tabs_follow', that.tabsFollowCallback, 0, 0, 0, 0);
        }else if(tabFocus=='follow'){
            that.tabPlayer = ToanThanToc.game.add.button(48, 450, 'tabs_player', that.tabsPlayerCallback, 0, 0, 0, 0);
            that.tabFollow = ToanThanToc.game.add.button(375, 450, 'tabs_follow', that.tabsFollowCallback, 1, 1, 1, 1);
        }
    },


    /**
     * Create list viewer.
     */
    createListViewer: function(arrayOnline){

        var that = ToanThanToc.OnlinePlayingRoom.prototype;
        var arrayData = {};
        if(arrayOnline.length > 0){
            var text = '';
            var i = 0;
            for(i; i < arrayOnline.length; ++i){
                text += arrayOnline[i].nickname+", ";
                if(text.length > 30){
                    var arrayDataTemp = [
                        {
                            xBuffer: -10,
                            yBuffer: 20,
                            name: text,
                            property: {font: "bold 28px Segoe UI",fill: "#fff"},
                            anchor: 0,
                            shadow: '0|0|0|0',
                            type: 'text',
                            isShow: 1
                        }
                    ];

                    arrayData[Object.keys(arrayData).length] = arrayDataTemp;
                    text = "";
                }
            }
            if(text != "") {
                arrayData[Object.keys(arrayData).length] = [
                    {
                        xBuffer: -10,
                        yBuffer: 20,
                        name: text,
                        property: {font: "bold 28px Segoe UI",fill: "#fff", align: 'left'},
                        anchor: 0,
                        shadow: '0|0|0|0',
                        type: 'text', isShow: 1
                    }
                ];
            }
        }

        console.log(arrayData);
        //if(arrayData)
        that.listViewer = new ListScroll(arrayData,100,1000,680,135,40,
            'roomPlaying', that,null,'bg_roomPlaying');
        that.listViewer.makeList();
        that.textCountViewer = ToanThanToc.game.add.text(
            90,992,'Người xem ('+arrayOnline.length+"):",{fill:'#FFF',font:'bold 30px Segoe UI'});
        var grd = that.textCountViewer.context.createLinearGradient(0, 0, 0, that.textCountViewer.height);

        //  Add in 2 color stops
        grd.addColorStop(0, '#ffffff');
        grd.addColorStop(1, '#e4f040');

        //  And apply to the Text
        that.textCountViewer.fill = grd;
        ToanThanToc.OnlinePlayingRoom.prototype.textCountViewer.setShadow(0, 2, 'rgba(0,0,0,0.5)', 0);

    },

    /* *********************** End Create ListView ************************** */







    /* ------------------------ Listener Trigger ---------------------------- */

    /**
     * Listener newScore in trigger.
     * Update list player.
     * Update score.
     * @param data
     */
    roomPlayingUpdateNewScore: function(data){

        var that = ToanThanToc.OnlinePlayingRoom.prototype;

        //console.log('New score trigger '+JSON.stringify(data));
        // Update list Player

        if(tabFocus=='player') {
            console.log('update tab player');
            that.showListPlayer(data.playboards);
        }else if(tabFocus=='follow'){
            console.log('update tab follow');
            that.showListFollow(data.playboards);
        }
        // Update list follow
        // Update score
        that.checkMyScore(data.playboards,ToanThanToc.myId);
        dataNewScoreTemp = data;
    },

    /**
     * Listener close game.
     * Open screen matResult.
     * @param data
     */
    roomPlayingListenerCloseGame: function(data){

        ToanThanToc.OnlineMathResult.prototype.arrayDefault = data;
        ToanThanToc.OnlineMathResult.prototype.strStarPeople = data.starPerMember ? data.starPerMember : 0;
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("OnlineMathResult");
        ToanThanToc.nameSpace = 'mathResult'; // Set nameSpace for update view.
    },

    /**
     * Listener user watch room.
     * Update list viewer.
     * @param data
     */
    //listenerWatchRoom: function(data){
    //
    //    var that = ToanThanToc.OnlinePlayingRoom.prototype;
    //
    //    console.log('Watch room '+JSON.stringify(data));
    //
    //    if(that.listViewer){
    //        /* Destroy list. */
    //        that.listViewer.destroyList();
    //    }
    //    // Update list user viewer.
    //    that.createListViewer(data.viewers);
    //},



    /* ------------------------ End Listener Trigger ---------------------------- */





    /** ------------------------------------------------------------------------- */

    /**
     * Button tab callback.
     */
    tabsPlayerCallback: function(){
        shareFunction.actionPlayAudio('touch');
        tabFocus = 'player';
        var that = ToanThanToc.OnlinePlayingRoom.prototype;

        if(ToanThanToc.OnlinePlayingRoom.prototype.DEBUG){
        }
        that.showListPlayer(dataNewScoreTemp.playboards);
        that.tabPlayer.setFrames(1, 1, 1, 1);
        that.tabFollow.setFrames(0, 0, 0, 0);
    },

    /**
     * Button tab callback.
     */
    tabsFollowCallback: function(){
        shareFunction.actionPlayAudio('touch');
        tabFocus = 'follow';
        var that = ToanThanToc.OnlinePlayingRoom.prototype;
        if(ToanThanToc.OnlinePlayingRoom.prototype.DEBUG){
        }
        that.showListFollow(dataNewScoreTemp.playboards);
        that.tabFollow.setFrames(1, 1, 1, 1);
        that.tabPlayer.setFrames(0, 0, 0, 0);
    },

    /**
     * Complete countdown.
     */
    onComplete: function(){

    },


    /**
     * Answer one click callback.
     */
    clickCallbackAnswerOne: function(){
        ToanThanToc.OnlinePlayingRoom.prototype.checkAnswerTrue(0);
        ToanThanToc.OnlinePlayingRoom.prototype.startShowQuestion();
    },

    /**
     * Answer one click callback.
     */
    clickCallbackAnswerTwo: function(){
        ToanThanToc.OnlinePlayingRoom.prototype.checkAnswerTrue(1);
        ToanThanToc.OnlinePlayingRoom.prototype.startShowQuestion();
    },



    /**
     * Answer one click callback.
     */
    clickCallbackAnswerThree: function(){
        ToanThanToc.OnlinePlayingRoom.prototype.checkAnswerTrue(2);
        ToanThanToc.OnlinePlayingRoom.prototype.startShowQuestion();
    },


    /**
     * Finish create new a question.
     */
    completeShowQuestion: function(){
        if(!ToanThanToc.OnlinePlayingRoom.prototype.tweenQuestion.isRunning){
            ToanThanToc.OnlinePlayingRoom.prototype.questionBoard.x=1000;
            ToanThanToc.OnlinePlayingRoom.prototype.tweenQuestion =
                ToanThanToc.game.add.tween(ToanThanToc.OnlinePlayingRoom.prototype.questionBoard)
                    .to({x:62},250,Phaser.Easing.Cubic.Out,true);
            // Show question.
            ToanThanToc.OnlinePlayingRoom.prototype.showQuestion(ToanThanToc.dataQuestionTemp.terms);
        }

    },

    /**
     * Start show question.
     */
    startShowQuestion: function(){
        ToanThanToc.OnlinePlayingRoom.prototype.tweenQuestion =
            ToanThanToc.game.add.tween(ToanThanToc.OnlinePlayingRoom.prototype.questionBoard)
                .to({x:-900},250,Phaser.Easing.Cubic.Out,true).start();
        // tween.
        ToanThanToc.OnlinePlayingRoom.prototype.tweenQuestion.onComplete
            .add(ToanThanToc.OnlinePlayingRoom.prototype.completeShowQuestion,ToanThanToc.game);
    },


    /**
     * Complete tween experience.
     */
    completeTweenExp: function(){
    },

    /**
     * Complete tween timer.
     */
    completeTweenTimer: function(){
        ToanThanToc.OnlinePlayingRoom.prototype.ResumeTimer();
    },

    /**
     * Show question
     * @param array
     */
    showQuestion: function(array){

        var that = ToanThanToc.OnlinePlayingRoom.prototype;

        if(array && array[that.questionCount]){
            that.textQuestion1.setText(((array[that.questionCount].aValue)=='0'?'0':array[that.questionCount].aValue)+'  '+(array[that.questionCount].operator)+'  '+((array[that.questionCount].bValue)=='0'?'0':array[that.questionCount].bValue));
            that.textQuestion1.x = that.questionBoard.width/2-that.textQuestion1.width/2;


            /* Random show answer. */

            that.result1 = Math.floor((Math.random() * 3));
            var result2 = 2 - that.result1;
            var result3 = 0;
            switch(result2){
                case 0:
                    result3 = 1;
                    break;
                case 1:
                    result3 = 2;
                    result2 = 0;
                    break;
                case 2:
                    result3 = 1;
                    break;
            }


            if(that.result1 == 0){
                that.textAnswer1.setText(array[that.questionCount].result);
                that.textAnswer2.setText(array[that.questionCount].result_1);
                that.textAnswer3.setText(array[that.questionCount].result_2);
            }else if(that.result1 ==1){
                that.textAnswer2.setText(array[that.questionCount].result);
                that.textAnswer1.setText(array[that.questionCount].result_1);
                that.textAnswer3.setText(array[that.questionCount].result_2);
            }else{
                that.textAnswer3.setText(array[that.questionCount].result);
                that.textAnswer1.setText(array[that.questionCount].result_1);
                that.textAnswer2.setText(array[that.questionCount].result_2);
            }


            that.questionCount++;
            if(that.questionCount == array.length){
                that.questionCount = 0;
            }
        }else{
            if(ToanThanToc.OnlinePlayingRoom.prototype.DEBUG){
            }
        }
    },

    /**
     * When user answer true.
     */
    answerTrue: function(){
        /* Get new score. */
        Socket.execute(function(socket){
            socket.post(urlNewScore,{token:xAuthToken,matchid:ToanThanToc.dataQuestionTemp.id},function(data){

            });
        });
    },

    answerFalse: function(){
        /* Get new score. */
        Socket.execute(function(socket){
            socket.post(urlMissScore,{token:xAuthToken,matchid:ToanThanToc.dataQuestionTemp.id},function(data){

            });
        });
    },


    /**
     * Check answer.
     */
    checkAnswerTrue: function(i){
        if(i == ToanThanToc.OnlinePlayingRoom.prototype.result1){ // right
            shareFunction.actionPlayAudio('right');
            ToanThanToc.OnlinePlayingRoom.prototype.answerTrue();
        }else{ // wrong
            shareFunction.actionPlayAudio('wrong');
            ToanThanToc.OnlinePlayingRoom.prototype.answerFalse();
        }
    },

    /**
     * Show list player.
     * ToanThanToc.dataQuestionTemp.playboards
     */
    showListPlayer: function(array){
        ToanThanToc.OnlinePlayingRoom.prototype.sortData(array, true);
        // DestroyList.

    },

    /**
     * Show list Follow.
     * ToanThanToc.dataQuestionTemp.playboards
     */
    showListFollow: function(array){
        ToanThanToc.OnlinePlayingRoom.prototype.sortData(array, false);
    },


    /**
     * Sort list data.
     * @param data
     * @param input
     * @returns {Array}
     */
    sortData: function(data,input){

        var that = ToanThanToc.OnlinePlayingRoom.prototype;
        var dataTemp = [];
        var i = 0, n = 0;
        if(input){
            /* Get data. */
            for(i; i< data.length; ++i){
                var j = 0;
                for(j;j<data[i].players.length;++j){
                    dataTemp[n] = data[i].players[j];
                    n++;
                }
            }
        }else{
            /* Get data. */
            for(i; i< data.length; ++i){
                var j = 0;
                for(j;j<data[i].players.length;++j){
                    console.log(data[i].players);
                    if(ToanThanToc.OnlineRoomWaiting.prototype.arrayMyView != null){
                        if(data[i].players[j].id ==
                            ToanThanToc.OnlineRoomWaiting.prototype.arrayMyView[j]){
                            dataTemp[n] = data[i].players[j];
                            n++;
                        }
                    }
                }
            }
        }


        /* Sort */
        var k = 0;
        for(k;k<dataTemp.length;++k){
            var l = 0;
            for(l;l<dataTemp.length-1;++l){
                if( dataTemp[l].score < dataTemp[l+1].score){
                    // permutations
                    var variableTemp = dataTemp[l+1];
                    dataTemp[l+1] = dataTemp[l];
                    dataTemp[l] = variableTemp;
                }
            }

        }


        if(dataTemp.length > 0){
            if(that.listPlayer){
                /* Destroy list. */
                that.listPlayer.destroyList();
            }
            /* Create listView list player */
            that.createListAllPlayer(70,100,680,357,85,
                'roomPlaying',dataTemp,'bg_roomPlaying');
        }
        return dataTemp;
    },


    /**
     * Update my score.
     * @param data
     * @param myID
     */
    checkMyScore: function(data,myID){
        ToanThanToc.OnlinePlayingRoom.prototype.expText.text =
            ToanThanToc.OnlinePlayingRoom.prototype.getScore(data,myID);
    },

    /**
     * Get my score.
     * @param data
     * @param myID
     * @returns {*}
     */
    getScore: function(data,myID){
        var i = 0;
        for(i;i<data.length;++i){
            var j = 0;
            for(j;j<data[i].players.length;++j){
                if(data[i].players[j].id == myID){
                    return data[i].players[j].score;
                }
            }
        }
        return 0;
    },


/** ===================================COUNTDOWN========================================== */

    /**
     * Start countdown
     * @param sprite
     * @param animation
     */
    animationStart: function(sprite, animation){

    },

    /**
     * Loop animation.
     * @param sprite
     * @param animation
     */
    animationLoop: function(sprite, animation){

    },
    animationStop: function(){


        /* Destroy waiting room */
        ToanThanToc.OnlineRoomWaiting.prototype.destroy();

        var that = ToanThanToc.OnlinePlayingRoom.prototype;

        that.questionBoard.visible = true;
        that.timerImage.visible = true;
        that.expImage.visible = true;
        that.countDown.visible = false;
        that.questionBoard.x=900;
        that.tweenQuestion = ToanThanToc.game.add.tween(that.questionBoard).to({x:60},250,Phaser.Easing.Bounce.In,true);
        that.tweenExp = ToanThanToc.game.add.tween(that.expImage).to({x:500},250,Phaser.Easing.Bounce.In,true);
        that.tweenExp.onComplete.add(that.completeTweenExp,ToanThanToc.game);
        that.tweenTimer = ToanThanToc.game.add.tween(that.timerImage).to({x:70},250,Phaser.Easing.Bounce.In,true);
        that.tweenTimer.onComplete.add(that.completeTweenTimer,ToanThanToc.game);
    },

/** ===================================COUNTDOWN========================================== */


/** TIMER TIMER TIMER TIMER TIMER TIMER TIMER TIMER TIMER TIMER */

    CreateNewTime:function(){
        ToanThanToc.OnlinePlayingRoom.prototype.timmer = new Phaser.Time(ToanThanToc.game);
        ToanThanToc.OnlinePlayingRoom.prototype.ResetTimer();
    },

    PauseTimer:function(){
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events.pause();
    },

    ResetTimer : function(){
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events.pause();
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events.nextTick=0;
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events._pauseStarted=0;
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events._pauseTotal=0;
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events._started=0;
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events._now=0;
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events.timeCap=0;
    },

    ResumeTimer:function(){
        ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events.resume();
    },


    render:function() {
        /*  if(ToanThanToc.soloPlayTime!=0)*/
        {
            ToanThanToc.OnlinePlayingRoom.prototype.timerText.setText(
                ToanThanToc.OnlinePlayingRoom.prototype.ShowTime (parseFloat(ToanThanToc.OnlinePlayingRoom
                    .prototype.timmer.game.time.events.seconds).toFixed(3)));
        }
        /*  if(ToanThanToc.soloPlayTime!=0)
         if(parseInt(ToanThanToc.OnlinePlayingRoom.prototype.timmer.game.time.events.seconds)>=ToanThanToc.soloPlayTime)
         if(ToanThanToc.OnlinePlayingRoom.prototype.OffGameTime()==false)
         return false;*/
    },
    ShowTime:function(textTime){
        textTime = parseFloat(ToanThanToc.dataQuestionTemp.timeLimit-textTime).toFixed(3);
        ToanThanToc.OnlinePlayingRoom.prototype.secondsPlay =  (textTime >= 0) ? textTime : '0' ;
        var arrTime = ToanThanToc.OnlinePlayingRoom.prototype.secondsPlay.toString().split('.');
        var hour = (parseInt(arrTime[0]/3600)==0)?0:parseInt(arrTime[0]/3600);
        var mi =   (parseInt((arrTime[0]%3600)/60)==0)?0:parseInt((arrTime[0]%3600)/60);
        var sec =  (parseInt((arrTime[0]%3600)%60)==0)?0:parseInt((arrTime[0]%3600)%60);
        var miSec = (arrTime.length==2)? (arrTime[1].length>2)?arrTime[1]: arrTime[1] : 0 ;
        return (
        (((hour*60 + mi).toString().length==1)?'0'+(hour*60 + mi).toString():(hour*60 + mi).toString())
        +':'+((sec.toString().length==1)?'0'+sec.toString():sec.toString())
        +','+miSec.toString());
    },

/** TIMER TIMER TIMER TIMER TIMER TIMER TIMER TIMER TIMER TIMER */


/*^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^*/

    /**
     * Update view
     */
    update: function(){
        var that = ToanThanToc.OnlinePlayingRoom.prototype;
        if(that.listViewer){
            that.listViewer.update();
        }
        if(that.listPlayer){
            that.listPlayer.update();
        }

    },

/*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/

    /**
     * Destroy
     */
    destroy: function(){

        ToanThanToc.dataWatchRoom = null;
        ToanThanToc.dataQuestionTemp = null;

        if(ToanThanToc.OnlinePlayingRoom){
            ToanThanToc.OnlinePlayingRoom.prototype.ResetTimer();
            ToanThanToc.OnlinePlayingRoom.prototype.listFollow.destroyList();
            ToanThanToc.OnlinePlayingRoom.prototype.listPlayer.destroyList();
            ToanThanToc.OnlinePlayingRoom.prototype.listViewer.destroyList();
            ToanThanToc.OnlinePlayingRoom.prototype.backgroundRoomPlaying.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.checkTabs = null;
            ToanThanToc.OnlinePlayingRoom.prototype.expImage.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.expText.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.timerImage.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.timerText.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.questionBoard.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.answerBoard1.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.answerBoard2.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.answerBoard3.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.textQuestion1.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.textQuestion2.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.textAnswer1.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.textAnswer2.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.textAnswer3.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.operator.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.textCountViewer = null;
            ToanThanToc.OnlinePlayingRoom.prototype.answerBoardX = null;
            ToanThanToc.OnlinePlayingRoom.prototype.answerBoardY = null;
            ToanThanToc.OnlinePlayingRoom.prototype.questionCount = null;
            ToanThanToc.OnlinePlayingRoom.prototype.DEBUG = null;
            ToanThanToc.OnlinePlayingRoom.prototype.tweenQuestion.destroy();
            ToanThanToc.OnlinePlayingRoom.prototype.result1 = null;
        }
    }
};