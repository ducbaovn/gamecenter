/**
 * Created by thanhpt From NAHI on 1/30/2015.
 * @Author: tpt2213
 */

"use strict";
ToanThanToc.SingleCreateChallenges = function (_game) {

};
//that.prototype = Object.create(Phaser.State.prototype);
//constructor = that;
//-------------------------------------

ToanThanToc.SingleCreateChallenges.prototype = {
    countChall:0,
    timeChall:0,
    createStar:false,
    arrayChall:0,
    preload:function(){
        ToanThanToc.popupShow=0;
        ToanThanToc.SingleCreateChallenges.prototype.isNameClick=null;
        if( ToanThanToc.game.cache.checkImageKey('bgCtChallSG')&&
            ToanThanToc.game.cache.checkImageKey('btnConfirmChallengeSG')&&
            ToanThanToc.game.cache.checkImageKey('btfriendChallengeSG')&&
            ToanThanToc.game.cache.checkImageKey('infoChallengeSG')
            ) return false;
        log('-------------------Preload singleCreateChallenges-------------------------');
        this.load.spritesheet('bgCtChallSG', 'assets/single/background/bg-create-challenges.png', 800,1232);
        this.load.spritesheet('btnConfirmChallengeSG', 'assets/single/create-challenge/btn-confirm.png', 479,98);
        this.load.spritesheet('btfriendChallengeSG', 'assets/single/create-challenge/friend.png', 251,78);
        this.load.spritesheet('infoChallengeSG', 'assets/single/create-challenge/info.png', 113,119);
        this.load.spritesheet('bgListBox1', 'assets/solo/menu/menu-solo/list-box-1.png', 232,345);

        this.load.spritesheet('textNumChallengeSG', 'assets/single/create-challenge/text-num.png', 210,72);

        this.load.spritesheet('textEasyChallengeSG', 'assets/single/create-challenge/easy.png', 75,40);
        this.load.spritesheet('textMediumChallengeSG', 'assets/single/create-challenge/medium.png', 75,40);
        this.load.spritesheet('textHardChallengeSG', 'assets/single/create-challenge/hard.png', 172,46);

        this.load.spritesheet('btWorldChallengeSG', 'assets/single/create-challenge/world.png', 270,78);

        /* load for popup */
        this.load.spritesheet('btnConfirmPPC', 'assets/single/create-challenge/popup/btn-confirm.png', 306,73);

        this.load.spritesheet('btnMenu2PPC', 'assets/single/create-challenge/popup/btn-menu2.png', 137,74);
        this.load.spritesheet('btnTradePPC', 'assets/single/create-challenge/popup/btn-trade.png', 138,74);
        this.load.spritesheet('bntCloseInfo', 'assets/single/create-challenge/popup/bnt-close-info.png', 144,79);

        this.load.spritesheet('bgPPloiPPC', 'assets/single/create-challenge/popup/popup-loi.png', 481,377);
        this.load.spritesheet('bgPPxacnhanPPC', 'assets/single/create-challenge/popup/popup-xacnhan.png', 548,343);
        this.load.spritesheet('bgPopupChucnang', 'assets/single/create-challenge/popup/popup-chucnang.png', 626,721);
        this.load.spritesheet('popupESao', 'assets/single/popup/popup-sao.png', 548,343);

        ToanThanToc.SingleCreateChallenges.prototype.keyboard = new KeyboardLib(ToanThanToc.game);
        ToanThanToc.SingleCreateChallenges.prototype.keyboard.loadContent();

    },
    create:function(){
        var ttt =ToanThanToc.SingleCreateChallenges.prototype;

        ttt.bgCtChallSG = ToanThanToc.game.add.sprite(0,-40,'bgCtChallSG');

        ttt.btnMenuSoloBackTT = ToanThanToc.game.add.button(17,35,'btnBackTT',this.ActionClickCreChall,ToanThanToc.game,0,0,1);
        ttt.infoChallengeSG = ToanThanToc.game.add.button(135,35,'infoChallengeSG',this.ActionClickCreChall,ToanThanToc.game,0,0,1);

        /* create text */

        ttt.textStartChallengePerSG=ToanThanToc.game.add.sprite(490,675,'textNumChallengeSG');
        ttt.textStartChallengePerSG.inputEnabled = true;
        ttt.textStartChallengePerSG.events.onInputDown.add(this.inputCountChall);
        ttt.textStartUseSG=ToanThanToc.game.add.sprite(490,770,'textNumChallengeSG');

        /* Create text */
        ttt.textStartChallengePerSG1 = ToanThanToc.game.add.bitmapText(510 ,697,'num','0',35);
        ttt.textStartUseSG1 = ToanThanToc.game.add.bitmapText(510 ,793,'num','0',35);

        /* create check box  */
        ttt.btFrined = ToanThanToc.game.add.button(100,970,'btfriendChallengeSG',null,ToanThanToc.game);
        ttt.btFrined.events.onInputDown.add(this.ActionClickCreChall);
        ttt.btFrined.frame=0;
        ttt.btWorld = ToanThanToc.game.add.button(430,970,'btWorldChallengeSG',null,ToanThanToc.game);
        ttt.btWorld.frame=1;
        ttt.btWorld.events.onInputDown.add(this.ActionClickCreChall);
        ttt.btnConfirmChallengeSG = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX-497/2,1100,'btnConfirmChallengeSG',this.ActionClickCreChall,ToanThanToc.game,0,0,1);
        ttt.btnConfirmChallengeSG.inputEnabled=false;
        /* create time and score  */
        var time =  ToanThanToc.SoloPlay.prototype.ShowTimeTo(
                ToanThanToc.MyScores[ToanThanToc.HighScoresSingle.prototype.Myindex].time/1000);
        ttt.textTimesCh = ToanThanToc.game.add.bitmapText(378 ,375,'num',time,55);
        ttt.imageMode = ToanThanToc.game.add.sprite(166,375,
            (ToanThanToc.MyScores[ToanThanToc.HighScoresSingle.prototype.Myindex].mode=="EASY"?'textEasyChallengeSG':(
                ToanThanToc.MyScores[ToanThanToc.HighScoresSingle.prototype.Myindex].mode=="MEDIUM"?'textMediumChallengeSG':'textHardChallengeSG'
            ))
        );

        ttt.bgCtChallSG.addChild(ttt.btnMenuSoloBackTT);
        ttt.bgCtChallSG.addChild(ttt.infoChallengeSG);
        ttt.bgCtChallSG.addChild(ttt.textTimesCh);
        ttt.bgCtChallSG.addChild(ttt.imageMode);

        ttt.bgCtChallSG.addChild(ttt.textStartChallengePerSG);
        ttt.bgCtChallSG.addChild(ttt.textStartUseSG);

        ttt.bgCtChallSG.addChild(ttt.textStartChallengePerSG1);
        ttt.bgCtChallSG.addChild(ttt.textStartUseSG1);

        ttt.bgCtChallSG.addChild(ttt.btFrined);
        ttt.bgCtChallSG.addChild(ttt.btWorld);
        ttt.bgCtChallSG.addChild(ttt.btnConfirmChallengeSG);

        ttt.CreateKeyborad();

        ttt.initSelectBox();

    },
    update:function(){

    },
    render:function(){
        if(ToanThanToc.SingleCreateChallenges.prototype.countChall>0&&
            ToanThanToc.SingleCreateChallenges.prototype.timeChall>0&&
            parseInt(ToanThanToc.SingleCreateChallenges.prototype.textStartChallengePerSG1._text)>0&&
            ToanThanToc.SingleCreateChallenges.prototype.createStar==false
            )
        {
            log('dang tinh');

            if(ToanThanToc.SingleCreateChallenges.prototype.btFrined.frame==1)
            {
                var start = ToanThanToc.SingleCreateChallenges.prototype.SetTextStart(0.3);
                ToanThanToc.SingleCreateChallenges.prototype.textStartUseSG1.setText(Math.ceil(start).toString());
                ToanThanToc.SingleCreateChallenges.prototype.btnConfirmChallengeSG.inputEnabled=true;
            }
            else if(ToanThanToc.SingleCreateChallenges.prototype.btWorld.frame==1)
            {
                var start = ToanThanToc.SingleCreateChallenges.prototype.SetTextStart(0.2) ;
                ToanThanToc.SingleCreateChallenges.prototype.textStartUseSG1.setText(Math.ceil(start).toString());
                ToanThanToc.SingleCreateChallenges.prototype.btnConfirmChallengeSG.inputEnabled=true;
            }
            ToanThanToc.SingleCreateChallenges.prototype.createStar=true;
            ToanThanToc.SingleCreateChallenges.prototype.isNameClick=null;
        }
    },

    SetTextStart:function(float){
       return ((ToanThanToc.SingleCreateChallenges.prototype.countChall*
            parseInt(ToanThanToc.SingleCreateChallenges.prototype.textStartChallengePerSG1._text)) +
        (ToanThanToc.SingleCreateChallenges.prototype.countChall*
            parseInt(ToanThanToc.SingleCreateChallenges.prototype.textStartChallengePerSG1._text)
            *float));
    },

    CreateKeyborad:function(){
        var keyboardCallback = function (str) {

            switch (ToanThanToc.SingleCreateChallenges.prototype.checkInput) {
                    /* case 0:
                    ToanThanToc.SingleCreateChallenges.prototype.textCountChallengeSG1.setText(str);
                    break;
                case 1:
                    ToanThanToc.SingleCreateChallenges.prototype.textDayChallengeSG1.setText(str);
                    break;*/
                case 2:
                    if(parseInt(str)>=100)
                    {
                        ToanThanToc.SingleCreateChallenges.prototype.textStartChallengePerSG1.setText(str);
                        ToanThanToc.SingleCreateChallenges.prototype.createStar=false;
                    }else{
                        ToanThanToc.SingleCreateChallenges.prototype.CreatePopupEnoughStart();
                    }

                    break;
                    /*  case 3:
                    ToanThanToc.SingleCreateChallenges.prototype.textStartUseSG1.setText(str);
                    break;*/
                default :
                    break;
            }
        };
        ToanThanToc.SingleCreateChallenges.prototype.keyboard.create(keyboardCallback);
    },

    CreatePopupEnoughStart:function(){
        var ttt = ToanThanToc.SingleCreateChallenges.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgPPConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');
        ttt.bgPPConfirm.inputEnabled=true;
        ttt.bgPPConfirm.events.onInputDown.add(ttt.ClickOutEnoughStart);

        ttt.bgPPxacnhanDHSC=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-548/2,ToanThanToc.game.world.centerY-343/2,'popupESao');
        ttt.btnConfirmDHSC=ToanThanToc.game.add.button(210,210,'btnOkPPC',ttt.ClickOutEnoughStart  ,ToanThanToc.game,0,0,1);

        ttt.bgPPxacnhanDHSC.addChild( ttt.btnConfirmDHSC);
        ttt.isNameClick = null;
    },

    CreatePopNOCreateChall:function(){
        log('  sao eu thay dell');

        var ttt = ToanThanToc.SingleCreateChallenges.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgPPERRConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');
        ttt.bgPPERRConfirm.inputEnabled=true;
        ttt.bgPPERRConfirm.events.onInputDown.add(ttt.ClickOut1);

        ttt.bgERRPPxacnhanPPC=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-481/2,ToanThanToc.game.world.centerY-377/2,'bgPPloiPPC');
        ttt.btnERRConfirmPPC=ToanThanToc.game.add.button(85,260,'btnConfirmPPC',this.ActionClickCreChall,ToanThanToc.game,0,0,1);
        ttt.btnERRMenuPPC=ToanThanToc.game.add.button(80,188,'btnMenu2PPC',this.ActionClickCreChall,ToanThanToc.game,0,0,1);
        ttt.btnERRTradePPC=ToanThanToc.game.add.button(255,188,'btnTradePPC',this.ActionClickCreChall,ToanThanToc.game,0,0,1);

        ttt.bgERRPPxacnhanPPC.addChild( ttt.btnERRConfirmPPC);
        ttt.bgERRPPxacnhanPPC.addChild( ttt.btnERRMenuPPC);
        ttt.bgERRPPxacnhanPPC.addChild( ttt.btnERRTradePPC);
        ttt.isNameClick = null;
    },

    CreatePopConfirmCreateChall:function(){
        var ttt = ToanThanToc.SingleCreateChallenges.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgPPConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');
        ttt.bgPPConfirm.inputEnabled=true;
        ttt.bgPPConfirm.events.onInputDown.add(ttt.ClickOut);

        ttt.bgPPxacnhanPPC=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-548/2,ToanThanToc.game.world.centerY-343/2,'bgPPxacnhanPPC');
        ttt.btnConfirmPPC=ToanThanToc.game.add.button(290,200,'btnOkPPC',this.ActionClickCreChall,ToanThanToc.game,0,0,1);
        ttt.btnDeletePPC=ToanThanToc.game.add.button(120,200,'btnDeletePPC',this.ActionClickCreChall,ToanThanToc.game,0,0,1);

        ttt.bgPPxacnhanPPC.addChild( ttt.btnConfirmPPC);
        ttt.bgPPxacnhanPPC.addChild( ttt.btnDeletePPC);
        ttt.isNameClick = null;

    },

    CreatePopInfoCreateChall:function(){
        ///btnMenu2PPC  - nut tuy chon
        /// bntCloseInfo  - nut dong
        /// bgPopupChucnang
        var ttt = ToanThanToc.SingleCreateChallenges.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgInPPConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');
        ttt.bgInPPConfirm.inputEnabled=true;
        ttt.bgInPPConfirm.events.onInputDown.add(ttt.ClickOutInfor);

        ttt.bgInPPxacnhanPPC=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-626/2,ToanThanToc.game.world.centerY-721/2,'bgPopupChucnang');
        ttt.btnInConfirmPPC=ToanThanToc.game.add.button(150,570,'btnMenu2PPC',this.OffPopupInfo,ToanThanToc.game,0,0,1);
        ttt.btnInDeletePPC=ToanThanToc.game.add.button(350,565,'bntCloseInfo',this.ClickOutInfor,ToanThanToc.game,0,0,1);


        ttt.bgInPPxacnhanPPC.addChild( ttt.btnInConfirmPPC);
        ttt.bgInPPxacnhanPPC.addChild( ttt.btnInDeletePPC);
        ttt.isNameClick = null;

    },

    OffPopupInfo:function(){
        var ttt = ToanThanToc.SingleCreateChallenges.prototype;
        if(ttt.isNameClick==null) {
            shareFunction.actionPlayAudio('right');
            ttt.isNameClick = 'btnMenu2PPC';
            SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
            ttt.DeletePageCreateChallenges();
            ToanThanToc.game.stage.destroy();
            ToanThanToc.game.state.start('MenuSingle');
            ttt.isNameClick = null;
        }
    },

    ActionClickCreChall:function(item){
        var ttt = ToanThanToc.SingleCreateChallenges.prototype;
        shareFunction.actionPlayAudio('touch');
        if(ttt.isNameClick==null) {
            log(item.key);
            if (item.key == 'infoChallengeSG') {
                ttt.isNameClick = 'btnConfirmChallengeSG';
                ttt.CreatePopInfoCreateChall();
            }
            else if (item.key == 'btnBackTT') {
                ttt.isNameClick = 'btnBackTT';
                SetCssBody('url(assets/single/background/bgok.png) no-repeat center center fixed');
                ttt.DeletePageCreateChallenges();
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('HighScoresSingle');
                ttt.isNameClick = null;
            }
            else if (item.key == 'btfriendChallengeSG'){
                ttt.isNameClick = 'btfriendChallengeSG';
                if (ttt.btFrined.frame == 0) {
                    ttt.btFrined.frame = 1;
                    ttt.btWorld.frame = 0;
                    ttt.createStar = false;
                    ttt.isNameClick = null;
                }
                else
                {
                    ttt.btWorld.frame = 1;
                    ttt.btFrined.frame = 0;
                    ttt.createStar = false;
                    ttt.isNameClick = null;
                }

            }
            else if (item.key == 'btWorldChallengeSG') {
                ttt.isNameClick = 'btWorldChallengeSG';
                if (ttt.btWorld.frame == 0) {
                    ttt.btWorld.frame = 1;
                    ttt.btFrined.frame = 0;
                    ttt.createStar = false;
                    ttt.isNameClick = null;
                }
                else
                {
                    ttt.btFrined.frame = 1;
                    ttt.btWorld.frame = 0;
                    ttt.createStar = false;
                    ttt.isNameClick = null;
                }

            }
            else if (item.key == 'btnConfirmChallengeSG') {
                ttt.isNameClick = 'btnConfirmChallengeSG';
                ttt.CreatePopConfirmCreateChall();
            }
            else if (item.key == 'btnMenu2PPC') {
                ttt.isNameClick = 'btnMenu2PPC';
                SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
                ttt.DeletePageCreateChallenges();
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('MenuSingle');
                ttt.isNameClick = null;
            }
            else if (item.key == 'btnTradePPC') {
                /*  ok Delete popup */
                ttt.isNameClick = 'btnTradePPC';
                ttt.ClickOut1();
            }
            else if (item.key == 'btnOkPPC') {
                /*  ok popup */
                ttt.isNameClick = 'btnOkPPC';
                if (parseInt(ttt.textStartUseSG1._text) > ToanThanToc.infoUserMath.starMoney) {
                    /* Show Popup chua the tao thach thuc  */
                    ttt.ClickOut();
                    ttt.CreatePopNOCreateChall();
                }
                else if(parseInt(ttt.textStartUseSG1._text) <= ToanThanToc.infoUserMath.starMoney) {
                    ttt.arrayChall={scoreid:ToanThanToc.HighScoresSingle.prototype.Myid,times:ttt.countChall,
                        money:parseInt(ToanThanToc.SingleCreateChallenges.prototype.textStartChallengePerSG1._text),
                        target:(ttt.btFrined.frame==1)?'FRIEND':'GLOBAL',days:ttt.timeChall
                    };
                    /*  Tao thach thuc*/
                    AddChallengeSingle(function(data){
                        if(data=='die')
                        {
                            ttt.isNameClick = null;
                            return false;
                        }
                        else
                        {
                            ttt.DeletePageCreateChallenges();
                            ToanThanToc.game.stage.destroy();
                            ToanThanToc.game.state.start('HighScoresSingle');
                            ttt.isNameClick = null;
                        }

                    },ttt.arrayChall);
                }
            }
            else if (item.key == 'btnDeletePPC') {
                /*  ok Delete popup */
                ttt.isNameClick = 'btnDeletePPC';
                ttt.ClickOut();
            }
            else if (item.key == 'btnConfirmPPC') {
                /*  ok Delete popup */
                ttt.isNameClick = 'btnConfirmPPC';
                ttt.ClickOut1();
            }
        }
    },

    ClickOut1:function(){
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        var ttt =ToanThanToc.SingleCreateChallenges.prototype;
        ttt.bgPPERRConfirm.destroy();
        setTimeout(function(){
            ttt.bgERRPPxacnhanPPC.destroy();
            ttt.isNameClick =null;
        },50);
    },

    ClickOut:function(){
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        var ttt =ToanThanToc.SingleCreateChallenges.prototype;
        ttt.bgPPConfirm.destroy();
        setTimeout(function(){
            ttt.bgPPxacnhanPPC.destroy();
            ttt.isNameClick =null;
        },50);
    },

    ClickOutInfor:function(){
        shareFunction.actionPlayAudio('right');
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        var ttt =ToanThanToc.SingleCreateChallenges.prototype;
        ttt.bgInPPConfirm.destroy();
        setTimeout(function(){
            ttt.bgInPPxacnhanPPC.destroy();
            ttt.isNameClick =null;
        },50);


    },

    ClickOutEnoughStart:function(){
        shareFunction.actionPlayAudio('right');
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        var ttt =ToanThanToc.SingleCreateChallenges.prototype;
        ttt.bgPPConfirm.destroy();
        setTimeout(function(){
            ttt.bgPPxacnhanDHSC.destroy();
            ttt.isNameClick =null;
        },50);
    },

    DeletePageCreateChallenges:function(){
        var ttt =ToanThanToc.SingleCreateChallenges.prototype;
        setTimeout(function(){
            ttt.bgCtChallSG.destroy();
            ttt.btnMenuSoloBackTT.destroy();
            ttt.infoChallengeSG.destroy();
        },80);

    },
    /** event when click n_ */
    inputCountChall : function() {
        ToanThanToc.SingleCreateChallenges.prototype.checkInput = 2;
        ToanThanToc.SingleCreateChallenges.prototype.keyboard.addCheck(true, 5);
        // Add keyboard.
        ToanThanToc.SingleCreateChallenges.prototype.addKeyboard();
        ToanThanToc.game.inputEnabled = true;
    },
    addKeyboard : function() {
        if (ToanThanToc.SingleCreateChallenges.prototype.keyboard != null &&
            !ToanThanToc.SingleCreateChallenges.prototype.keyboard.groups.visible) {
            ToanThanToc.SingleCreateChallenges.prototype.keyboard.groups.visible = true;
        }
    },
    /* select box
    * 2,3,5,10,15,20
    *
    *
    *
    * */
    ShowCountChall:function(){
        var CountChall = [];
        CountChall.push( { value: 2, text: '2 lần' });
        CountChall.push( { value: 3, text: '3 lần' });
        CountChall.push( { value: 5, text: '5 lần' });
        CountChall.push( { value: 10, text: '10 lần' });
        CountChall.push( { value: 15, text: '15 lần' });
        CountChall.push( { value: 20, text: '20 lần' });
        return CountChall;
    },
    ShowTime:function(){
        var time = [];
        time.push( { value: 2, text: '2 ngày' });
        time.push( { value: 3, text: '3 ngày' });
        time.push( { value: 5, text: '5 ngày' });
        time.push( { value: 10, text: '10 ngày' });
        time.push( { value: 15, text: '15 ngày' });
        time.push( { value: 20, text: '20 ngày' });
        return time;
    },
    initSelectBox: function() {
        var ttt= ToanThanToc.SingleCreateChallenges.prototype;
        var count = ttt.ShowCountChall();
        var time = ttt.ShowTime();

        ToanThanToc.SingleCreateChallenges.timeSelectBox = new SelectBox({
            game: ToanThanToc.game,
            data:time ,
            selectBoxSpriteSheetId: 'btnListMsl',
            selectBoxPosition: {x:480 ,y:515},
            selectBoxTitle: 'Số ngày',
            selectBoxTitleStartPosition: {x: 50, y: 34},
            listBackgroundImageId: 'bgListBox1',
            listBackgroundImagePosition: {x: 495, y: 615},
            listTextStartPosition: {x: 65, y: 8},
            listItemBackgroundImageId: 'bgSelectItemMSL',
            oneInstanceMode: true,
            dependencySelectBoxes: [],
            onClickOnSelectBox: function() {
                if(SetMusic.touch)
                    ToanThanToc.music_touch.play();

            },
            onSelect: function(selectedItem) {
                if(SetMusic.touch)
                    ToanThanToc.music_popupMainAction.play();
                if (selectedItem == null) {
                    ttt.timeChall = 0;
                }
                else {
                    ttt.timeChall = selectedItem.value;
                }
                ttt.createStar=false;
            }
        });

        ToanThanToc.SingleCreateChallenges.scoreSelectBox = new SelectBox({
            game: ToanThanToc.game,
            data:count ,
            selectBoxSpriteSheetId: 'btnListMsl',
            selectBoxPosition: {x: 480, y: 405},
            selectBoxTitle: 'Số lần',
            selectBoxTitleStartPosition: {x:70 ,y:34},
            listBackgroundImageId: 'bgListBox1',
            listBackgroundImagePosition: {x: 495, y: 505},
            listTextStartPosition: {x: 65, y: 8},
            listItemBackgroundImageId: 'bgSelectItemMSL',
            oneInstanceMode: true,
            dependencySelectBoxes: [],
            onClickOnSelectBox: function() {
                if(SetMusic.touch)
                    ToanThanToc.music_touch.play();

            },
            onSelect: function(selectedItem) {
                if(SetMusic.touch)
                    ToanThanToc.music_popupMainAction.play();
                if (selectedItem == null) {
                    ttt.countChall = 0;
                }
                else {
                    ttt.countChall = selectedItem.value;
                }
                ttt.createStar=false;
            }
        });
    }
};
function AddChallengeSingle(callback,arr) {
    ToanThanToc.db.setAtuthToken(ToanThanToc.MyToken);
    var  postDelMyScores = ToanThanToc.db.query({api: '/math/addchallenge/', data:arr,
            headers : {'x-auth-token': ToanThanToc.MyToken}}
    );
    postDelMyScores.success(function(data){
        callback(data);
    });
    postDelMyScores.error(function(data){
        callback('die');
    });
}