/**
 * Created by vunl on 12/22/2014.
 */

var localData = {
    set: function(key,object){
        localStorage.setItem(key,JSON.stringify(object));
    },
    get: function(key){
        return JSON.parse(localStorage.getItem(key));
    },
    addItemTo: function(key,object){
        var objFa = [];
        objFa = localData.get(key);
        objFa.unshift(object);
        localStorage.setItem(key,JSON.stringify(objFa));
    },
    removeItemTo: function(key,pos){
        var objFa = [];
        objFa = localData.get(key);
        objFa.splice(pos,1);
        localStorage.setItem(key,JSON.stringify(objFa));
    },
    removeItem :function(key){
        localStorage.removeItem(key);
    }
};