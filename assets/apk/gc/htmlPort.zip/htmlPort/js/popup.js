/**
 * Created by vunl on 12/15/2014.
 */
function Popup(calback){

    var tweenOpen;
    var tweenClose;
    var popup;
    var closeButton;
    var clickButton = null;
    var arrIcon = [];
    var arrNameIcon = [];
    var arrPosIcon = [];
    var arrText = [];
    var arrPosText = [];
    var arrInfo = [];
    var arrStyle = [];
    var namePopup = null;
    var nameClose = null;
    var nameClick = null;
    var arrPosClose = [];
    var arrPosClick = [];
    var game;
    var _t = this;
    var id;
    var name;
    var events =null;
    var btn = null;
    var bg = null;

    this.setMain = function(_game,_id,_name,_namePopup,_nameClose,_arrPosClose,_nameClick,_arrPosClick){
        game = _game;
        id = _id;
        name = _name;
        namePopup = _namePopup;
        nameClose = _nameClose;
        arrPosClose = _arrPosClose;
        nameClick = _nameClick;
        arrPosClick = _arrPosClick;

    };

    this.setIcon = function(_arrNameIcon,_arrPosIcon){
        arrNameIcon = _arrNameIcon;
        arrPosIcon = _arrPosIcon;

    };

    this.setText = function(_arrPosText,_arrInfo,_arrStyle){
        arrPosText = _arrPosText;
        arrInfo = _arrInfo;
        arrStyle = _arrStyle;
    };

    this.setEvent = function(_event){
        events = _event;
    };

    this.createPopup = function(w,h){
        bg = game.add.sprite(0,0,'bgcountdown');
        bg.width = 800;
        bg.height = 1230;
        bg.inputEnabled = true;


        popup = game.add.sprite(game.world.centerX, game.world.centerY, namePopup);
        popup.anchor.set(0.5);
//        popup.width = popup.width - w;
//        popup.height = popup.height - h;

        if(nameClose!=null){
            closeButton = game.add.sprite( arrPosClose[0].x,arrPosClose[0].y,nameClose);
            closeButton.inputEnabled = true;
            closeButton.name = 'close';
            closeButton.events.onInputDown.add(_t.closeWindow);
            popup.addChild(closeButton);
        }

        if(nameClick!=null){
            clickButton = game.add.sprite(arrPosClick[0].x,arrPosClick[0].y,nameClick);
            clickButton.value = id;
            clickButton.name = name;
            clickButton.inputEnabled = true;
            clickButton.events.onInputDown.add(_t.closeWindow);
            popup.addChild(clickButton);
        }

        if(arrPosIcon.length > 0){
            for(var i = 0;i<arrPosIcon.length;i++){
                var icon =game.add.sprite(arrPosIcon[0].x,arrPosIcon[0].y,arrNameIcon[i]);
                //icon.width = 200;
                //icon.height = 163;
                arrIcon.push(icon);
                popup.addChild(icon);
            }
        }

        if(arrInfo.length > 0){
            for(var i = 0;i<arrInfo.length;i++){
                var text  =game.add.text(arrPosText[i].x,arrPosText[i].y,arrInfo[i],arrStyle[i]);
                text.anchor.set(0.5,0);
                arrText.push(text);
                popup.addChild(text);
            }
        }
        popup.bringToTop();
//        if(ToanThanToc.bgContentMin != null){
//            $('#content').css('z-index',1000);
//            $("#content").css('height',window.innerHeight+'px');
//        }

    };
    this.openWindow = function() {
//        if ((tweenOpen && tweenOpen.isRunning) || popup.scale.x == 1){
//            return;
//        }
//        tweenOpen = game.add.tween(popup.scale).to( { x: 1, y: 1 }, 1000, Phaser.Easing.Elastic.Out, true);
        //ToanThanToc.popupShow = true;
    };

    this.closeWindow = function(item) {
//        if (tweenOpen.isRunning || popup.scale.x === 0){
//            return;
//        }
        if(item.name!='close')btn = item;
//        tweenClose = game.add.tween(popup.scale).to( { x: 0, y: 0 }, 500, Phaser.Easing.Elastic.In, true);
        _t.onCompleteTweenClose();
    };


    this.onCompleteTweenClose = function(){

        popup.destroy();
        bg.destroy();
        if(closeButton!=null)closeButton.destroy();
        if(clickButton!=null)clickButton.destroy();
        if(arrIcon.length>0){
            arrIcon.forEach(function(i){
                i.destroy();
            })
        }
        if(arrText.length>0){
            arrText.forEach(function(i){
                i.destroy();
            })
        }

//        if(id=='NoData'){
//            var obj = ToanThanToc.gContent.state.states[ToanThanToc.pages.CONTENT_MAIN];
//            obj.create();
//            obj.resizeContent(ToanThanToc.statusResize);
//        }
        if(btn!=null) {
            if(events!=null){
                events(btn);

            }
            btn = null;
        }

//        if(ToanThanToc.bgContentMin != null){
//            $('#content').css('z-index',700);
//            $('#content').css('height',ToanThanToc.resize.getHeight(940,1230)+'px');
//        }

        if(calback != undefined){
            return calback();
        }
    }


}