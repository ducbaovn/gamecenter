/**
 * Created by ngoin on 07/01/15.
 */






ToanThanToc.OnlineUserView = function(_game){};
ToanThanToc.OnlineUserView.prototype={


    /* Using use strict */

    /* -------------------- VARIABLE ----------------------- */

    background : null,
    backgroundTeamDetail : null,
    timePlay : null,
    mode : null,
    numberTeam : null,
    nameRoom:null,
    memberOfTeam : null,
    starPlay : null,
    listViewer : null,
    btnExit : null,
    listPlayer : null,
    textListViewer : null,
    timerText: null,
    ongame:null,
    ownerId : '',
     arrayViewer : [{"id":"54a39ea647004cbb54f3c746","nickname":"nahi2@nahi.vn",
        "fullname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","onlineStatus":"OFFLINE"},
        {"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn","nickname":"nahi1@nahi.vn","avatar_url":"",
            "gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":1}, {"id":"54a39ea647004cbb54f3c746",
            "fullname":"nahi2@nahi.vn","nickname":"nahi2@nahi.vn","avatar_url":"", "gender":"FEMALE",
            "dob":"2013-12-02T17:00:00.000Z","level":1,"team":2},{"id":"54a39ea647004cbb54f3c746","nickname":"nahi2@nahi.vn",
            "fullname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","onlineStatus":"OFFLINE"},
        {"id":"54a39ea647004cbb54f3c746","nickname":"nahi2@nahi.vn", "fullname":"nahi2@nahi.vn","avatar_url":"",
            "gender":"FEMALE","onlineStatus":"OFFLINE"},{"id":"54a39ea647004cbb54f3c746","nickname":"nahi2@nahi.vn",
            "fullname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","onlineStatus":"OFFLINE"}],




    /* -------------------- VARIABLE ----------------------- */


    /**
     * Load Image for user view.
     */
    preload : function(){

        if( ToanThanToc.game.cache.checkImageKey('userView_bg') &&
            ToanThanToc.game.cache.checkImageKey('flag') &&
            ToanThanToc.game.cache.checkImageKey('isnull') &&
            ToanThanToc.game.cache.checkImageKey('star') &&
            ToanThanToc.game.cache.checkImageKey('bgscore')){
            return;
        }
        ToanThanToc.game.load.spritesheet('userView_bg','assets/online/user-view/bg.png', 800, 1232);
        ToanThanToc.game.load.spritesheet('flag','assets/online/plays/flag.png');
        ToanThanToc.game.load.spritesheet('list_line', 'assets/online/plays/list_line.png');
        ToanThanToc.game.load.spritesheet('isnull', 'assets/online/plays/empty.png');
        ToanThanToc.game.load.spritesheet('star', 'assets/online/result/starscore.png');
        ToanThanToc.game.load.spritesheet('bgscore', 'assets/online/room-play/bgScore.png');
},


    /**
     * Create user view.
     */
//    create : function(dataNewGame, dataViewer){
    create : function(){
        ongame=ToanThanToc.OnlineUserView.prototype;
        /* Set owner */
        ongame.ownerId = ToanThanToc.dataQuestionTemp.owner;
        ongame.background = ToanThanToc.game.add.image(0,0,'userView_bg');

        /* Sort data */
        this.sortData(ToanThanToc.dataQuestionTemp.playboards);

        this.userViewUpdateNewScore(ToanThanToc.dataQuestionTemp);
        this.createListViewer(ToanThanToc.dataWatchRoom.viewers);
//        this.createDetailRoom();


        /* Text timer */
        ToanThanToc.OnlineUserView.prototype.timerText = ToanThanToc.game.add
            .text(350,90,'',{font: "bold 50px Segoe UI", fill: "#ffffff", align: "center"});
        ToanThanToc.OnlineUserView.prototype.CreateNewTime();
        ToanThanToc.OnlineUserView.prototype.ResumeTimer();

        ongame.btnExit = ToanThanToc.game.add.button(160.5, 1095,'btn_exit',this.callbackButtonExit,{},0,0,1,0);

    },


    /**
     * Update view.
     */
     update : function(){
        if(ToanThanToc.OnlineUserView.prototype.listPlayer != null){
            ToanThanToc.OnlineUserView.prototype.listPlayer.update();
        }

        if(ToanThanToc.OnlineUserView.prototype.listViewer != null){
            ToanThanToc.OnlineUserView.prototype.listViewer.update();
        }
//        this.createListViewer(this.arrayViewer);
//        this.createDetailRoom();
        ongame.btnExit.bringToTop();

    },


    /**
     * Create list player.
     */
//        createDetailRoom:function(){
//        if(ToanThanToc.dataWatchRoom != null){
//            if(ToanThanToc.dataWatchRoom.free == true){
//               ongame.backgroundTeamDetail = ToanThanToc.game.add.sprite(91,60,'item_room2');
//                ongame.numberTeam = ToanThanToc.game.add.text(185,223, ToanThanToc.dataWatchRoom.teamLimit,
//                    {font: "bold 35px Segoe UI", fill: "#ffffff", align: "left"});
//            }else{
//                ongame.backgroundTeamDetail = ToanThanToc.game.add.sprite(91,60,'item_room1');
//                ToanThanToc.game.add.text(185, 223, ToanThanToc.dataWatchRoom.teamLimit,
//                    {font: "bold 35px Segoe UI", fill: "#ffffff", align: "left"});
//
//                log(ToanThanToc.dataWatchRoom);
//
//                ongame.memberOfTeam = ToanThanToc.game.add.text(345,223,'0',{font: "bold 35px segoe ui", fill: "#fff"});
//                ongame.memberOfTeam.text = ToanThanToc.dataWatchRoom.memberPerTeam*ToanThanToc.dataWatchRoom.teamLimit;
//                var addition = ToanThanToc.game.add.sprite(555,230,'btn_addition');
//                addition.frame=(ToanThanToc.dataWatchRoom.operator.charAt(0)=='1')?0:1;
//                var subtraction = ToanThanToc.game.add.sprite(590,230,'btn_subtraction');
//                subtraction.frame=(ToanThanToc.dataWatchRoom.operator.charAt(1)=='1')?0:1;
//                var multiplication = ToanThanToc.game.add.sprite(625,230,'btn_multiplication');
//                multiplication.frame=(ToanThanToc.dataWatchRoom.operator.charAt(2)=='1')?0:1;
//                var division = ToanThanToc.game.add.sprite(520,230, 'btn_division');
//                division.frame=(ToanThanToc.dataWatchRoom.operator.charAt(3)=='1')?0:1;
//            }
//            ongame.timePlay = ToanThanToc.game.add.text(185,157,'',{font: "bold 35px segoe ui", fill: "#fff"});
//            ongame.starPlay = ToanThanToc.game.add.text(345,157,'150',{font: "bold 35px segoe ui", fill: "#fff"});
//            ongame.nameRoom = ToanThanToc.game.add.text(250,87,'',{font: "bold 35px segoe ui", fill: "#fff",align:'center'});
//            ongame.nameRoom.anchor.set(0.5,0);
//            ongame.mode = ToanThanToc.game.add.text(520,157,'Khá',{font: "bold 35px segoe ui", fill: "#fff"});
//
//            ongame.timePlay.text = ToanThanToc.dataWatchRoom.timeLimit+'s';
//            ongame.nameRoom.text = ToanThanToc.dataWatchRoom.name;
//            ongame.starPlay.text = ToanThanToc.dataWatchRoom.starPerMember;
//
//            if(ToanThanToc.dataWatchRoom.mode == 'EASY'){
//                ongame.mode.text = 'Khá';
//            }else if(ToanThanToc.dataWatchRoom.mode == 'MEDIUM'){
//                ongame.mode.text = 'Giỏi';
//            }else{
//                ongame.mode.text = 'Xuất sắc';
//            }
//        }
//    },
     createListPlayer : function(x,y,w,h,key,z,array){
        var arrayFreeRoom = {};
        for(var i = 0; i < array.length;++i){
            var arrayTemp = 0;
            var name=array[i].nickname;
            name=name.split('@');
            arrayTemp = [
                { // Level.
                    xBuffer: 390,
                    yBuffer: 22,
                    name: array[i].level,
                    strokeThickness: 2,
                    fontSize: 25,
                    fontWeight: 'bold',
                    anchor: 0,
                    shadow: '0|0|0|0',
                    property: {font: "bold 30px Segoe UI", fill: "#fff", align: "center"},
                    type: 'text',
                    isShow: 1
                },

                {   // Image team.
                    xBuffer: 535,
                    yBuffer: 0,
                    name: 'bgscore',
                    type: 'image',
                    isShow: 1
                },
                { // score text
                    xBuffer: 588,
                    yBuffer: 40,
                    name: (array[i].score==0)?'0':array[i].score,
                    strokeThickness: 5,
                    fontSize: 20,
                    fontWeight: 'bold',
                    anchor: 0.5,
                    shadow: '0|0|0|0',
                    property: {font: "bold 30px Segoe UI", fill: "#ffffff", align: "center"},
                    type: 'text',
                    isShow: 1
                },
                { // Text Name
                    xBuffer: 285,
                    yBuffer: 37,
                    name: name[0],
                    anchor: 0.5,
                    shadow: '0|0|0|0',
                    property: {font: "bold 33px Segoe UI", fill: "#ffffff"},
                    type: 'text',
                    isShow: 1
                },
                { // avatar image
                    xBuffer: 90,
                    yBuffer: 5,
                    width:75,
                    height:75,
                    name: (array[i].avatar_url == '') ? 'avatar_default' : array[i].id,
                    type: 'avatar', isShow: 1
                },
                {   // Image team.
                    xBuffer: 430,
                    yBuffer: 15,
                    name: array[i].team,
                    type: 'image',
                    isShow: 1
                }
            ];
            if(i==0){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -18,
                        yBuffer: -15,
                        name: i+1+'medals',
                        width:100,
                        height:100,
                        type: 'avatar',
                        isShow: 1
                    }
                );
            }else
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -20,
                        yBuffer: -15,
                        name: i+1+'medals',
                        type: 'image',
                        isShow: 1
                    }
                );


            if(i > 0){
                arrayTemp.push({ // devider
                    xBuffer: 0,
                    yBuffer: -20,
                    name: 'list_line',
                    type: 'image',
                    isShow: 1
                });
            }
//
            if(array[i].id == ToanThanToc.OnlineUserView.prototype.ownerId){
                arrayTemp.push({   // Image flag.
                    xBuffer: 140,
                    yBuffer: 0,
                    name: 'flag',
                    type: 'image',
                    isShow: 1
                });
            }


            if(arrayTemp){
                arrayFreeRoom[Object.keys(arrayFreeRoom).length] = arrayTemp;
            }

        }

        /* Create List */
        ToanThanToc.OnlineUserView.prototype.listPlayer = new ListScroll(arrayFreeRoom,x, y, w, h,z,'userView'
            ,ToanThanToc.OnlineUserView.prototype,null,key);
        ToanThanToc.OnlineUserView.prototype.listPlayer.makeList();
    },


    /**
     * Create viewer list
     */
    createListViewer : function(arrayOnline){
        if(arrayOnline.length > 0){
            var text = '';
            var arrayData = {};
            var i = 0;
            for(i; i < arrayOnline.length; ++i){
                text += arrayOnline[i].nickname+", ";
                if(text.length > 30){
                    var arrayDataTemp = [
                        {
                            xBuffer: 10,
                            yBuffer: 0,
                            name: text,
                            property: {font: "30px segoe ui",fill: "#fff"},
                            strokeThickness: 0,
                            fontSize: 25,
                            fontWeight: '',
                            anchor: 0,
                            shadow: '0|0|0|0',
                            type: 'textlist',
                            isShow: 1
                        }
                    ];

                    arrayData[Object.keys(arrayData).length] = arrayDataTemp;
                    text = "";
                }
            }
            if(text != "") {
                arrayData[Object.keys(arrayData).length] = [
                    {
                        xBuffer: 10,
                        yBuffer: 0,
                        name: text,
                        property: {font: "30px segoe ui",fill: "#fff", align: 'left'},
                        strokeThickness: 0,
                        fontWeight: '',
                        anchor: 0,
                        shadow: '0|0|0|0',
                        type: 'textlist', isShow: 1
                    }
                ];
            }
        }

        ToanThanToc.OnlineUserView.prototype.listViewer = new ListScroll(arrayData,80, 915, 700, 180, 40,'userView',
            ToanThanToc.OnlineUserView.prototype,null,'userView_bg');
        ToanThanToc.OnlineUserView.prototype.listViewer.makeList();
        ToanThanToc.OnlineUserView.prototype.textListViewer = ToanThanToc.game.add
            .text(85,875,'Danh sách đang xem (' + arrayOnline.length + ')',{fill:'#ffffff',
                font:'bold 31px Segoe UI'});
        var grd = ToanThanToc.OnlineUserView.prototype.textListViewer.context.createLinearGradient(
            0, 0, 0, ToanThanToc.OnlineUserView.prototype.textListViewer.height);

        //  Add in 2 color stops
        grd.addColorStop(0, '#ffffff');
        grd.addColorStop(1, '#e3eb70');

        //  And apply to the Text
        ToanThanToc.OnlineUserView.prototype.textListViewer.fill = grd;
        ToanThanToc.OnlineUserView.prototype.textListViewer.setShadow(0, 3, 'rgba(0,0,0,0.5)', 0);
    },


    /**
     * Sort list data.
     * @param data
     * @returns {Array}
     */
     sortData : function(data){
        var dataTemp = [];
        /* Get data. */
        var i = 0, n = 0;
        for(i; i< data.length; ++i){
            var j = 0;
            for(j;j<data[i].players.length;++j){
                dataTemp[n] = data[i].players[j];
                n++;
            }
        }
        /* Sort */
        var k = 0;
        for(k;k<dataTemp.length;++k){
            var l = 0;
            for(l;l<dataTemp.length-1;++l){
                if( dataTemp[l].score < dataTemp[l+1].score){
                    // permutations
                    var variableTemp = dataTemp[l+1];
                    dataTemp[l+1] = dataTemp[l];
                    dataTemp[l] = variableTemp;
                }
            }

        }

        if(ToanThanToc.OnlineUserView.prototype.listPlayer){
            /* Destroy list. */
            ToanThanToc.OnlineUserView.prototype.listPlayer.destroyList();
        }
        /* Create listView list player */
        this.createListPlayer(100,290 ,590,460,'userView_bg',110,dataTemp);
    },


    /**
     * Update new score.
     * Sort data and update list player.
     * @param data
     */
     userViewUpdateNewScore : function(data){
        this.sortData(data.playboards);
    },


    /**
     * Listener end game.
     * Show screen end game.
     * @param data
     */
     userViewListenerEndGame : function(data){
        if(ToanThanToc.OnlineMathResult.prototype){
            ToanThanToc.OnlineMathResult.prototype.arrayDefault = data;
            ToanThanToc.OnlineMathResult.prototype.strStarPeople = data.starPerMember;
            ToanThanToc.game.stage.destroy();
            ToanThanToc.game.state.start("OnlineMathResult");
            ToanThanToc.nameSpace = 'mathResult'; // Set nameSpace for update view.
        }else{
//            console.log('ToanThanToc.STATES.mathResult is null');
        }
    },
    /* ----------------------------- TIMER ---------------------------------------- */
    CreateNewTime:function(){
        ToanThanToc.OnlineUserView.prototype.timmer = new Phaser.Time(ToanThanToc.game);
        ToanThanToc.OnlineUserView.prototype.ResetTimer();
    },

    PauseTimer:function(){
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events.pause();
    },

    ResetTimer : function(){
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events.pause();
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events.nextTick=0;
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events._pauseStarted=0;
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events._pauseTotal=0;
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events._started=0;
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events._now=0;
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events.timeCap=0;
    },

    ResumeTimer:function(){
        ToanThanToc.OnlineUserView.prototype.timmer.game.time.events.resume();
    },


    render:function() {
        {
            ToanThanToc.OnlineUserView.prototype.timerText.setText(
                ToanThanToc.OnlineUserView.prototype.ShowTime (parseFloat(ToanThanToc.OnlineUserView
                    .prototype.timmer.game.time.events.seconds).toFixed(3)));
        }
    },
    ShowTime:function(textTime){


        textTime = parseFloat((ToanThanToc.dataQuestionTemp.timeLimit+10)-textTime).toFixed(3);
        if(textTime >= ToanThanToc.dataQuestionTemp.timeLimit){
            textTime = parseFloat(ToanThanToc.dataQuestionTemp.timeLimit).toFixed(3);
        }
        ToanThanToc.OnlineUserView.prototype.secondsPlay =  (textTime >= 0) ? textTime : '0' ;
        var arrTime = ToanThanToc.OnlineUserView.prototype.secondsPlay.toString().split('.');
        var hour = (parseInt(arrTime[0]/3600)==0)?0:parseInt(arrTime[0]/3600);
        var mi =   (parseInt((arrTime[0]%3600)/60)==0)?0:parseInt((arrTime[0]%3600)/60);
        var sec =  (parseInt((arrTime[0]%3600)%60)==0)?0:parseInt((arrTime[0]%3600)%60);
        var miSec = (arrTime.length==2)? (arrTime[1].length>2)?arrTime[1]: arrTime[1] : 0 ;
        return (
        (((hour*60 + mi).toString().length==1)?'0'+(hour*60 + mi).toString():(hour*60 + mi).toString())
        +':'+((sec.toString().length==1)?'0'+sec.toString():sec.toString())
        +','+miSec.toString());
    },

    /* ----------------------------- TIMER ---------------------------------------- */


    /**
     * Destroy.
     */
     destroy : function(){

        //ToanThanToc.dataWatchRoom = null;
        ToanThanToc.dataQuestionTemp = null;
        //ToanThanToc.OnlineMathResult.prototype.background.destroy();
        //ToanThanToc.OnlineMathResult.prototype.backgroundTeamDetail.destroy();
        //ToanThanToc.OnlineMathResult.prototype.timePlay.destroy();
        //ToanThanToc.OnlineMathResult.prototype.mode.destroy();
        //ToanThanToc.OnlineMathResult.prototype.numberTeam.destroy();
        //ToanThanToc.OnlineMathResult.prototype.nameRoom.destroy();
        //ToanThanToc.OnlineMathResult.prototype.memberOfTeam.destroy();
        //ToanThanToc.OnlineMathResult.prototype.starPlay.destroy();
        ToanThanToc.OnlineMathResult.prototype.listViewer.destroyList();
        //ToanThanToc.OnlineMathResult.prototype.btnExit.destroy();
        ToanThanToc.OnlineMathResult.prototype.listPlayer.destroyList();
        //ToanThanToc.OnlineMathResult.prototype.textListViewer.destroy();
        ToanThanToc.OnlineMathResult.prototype.that = null;
        ToanThanToc.OnlineMathResult.prototype.ownerId = null;
    },


    /**
     * Callback button exit.
     */
     callbackButtonExit : function(){
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("OnlineRoomChoose");
        ToanThanToc.nameSpace = 'chooseRoom';

    },
    setOnTopListViewer: function(){
        this.textListViewer.bringToTop();
        this.listViewer.bringToTop();
    }




};