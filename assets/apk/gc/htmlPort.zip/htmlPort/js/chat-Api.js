/**
 * Created by duynguyen on 09/01/2015.
 */

var chatAPI = function () {

    chatThis = this;

    this.isConnected = false;

    this.socket = null;

    this.kenhthegioi = null;

    this.userOnchat = null;

    this.profile = null;

    this.domain = null;

    this.statusCodeErr = 403;

    this.localData = null;

    this.test = null;

    ///===================================== function =================================///

    /**
     * connect API
     */
    this.config = function (_domain,_localData,_callback) {
        if(_domain==null){
            console.log("Config ========= Domain null!!!!!!!!!!!");
            return;
        }
        this.domain = _domain;
        this.localData = _localData;
        console.log('this.localData config chat-API');
        console.log(this.localData);
        //this.localData = localData.get('Account');
        if(!_callback){
            console.log('callback null');
            return;
        }
        return _callback.call(this);
    };

    this.connectAPI = function(){

        console.log("=================== chatAPI.connectAPI.......connecting =======================");
        console.log(this.domain);
        var that = this;
        console.log(this.socket);
        /*check connect*/
        //if(this.socket && this.socket.isConnected()){
        //    console.log('socket connected already');
        //    return false;
        //}

        /*if(this.socket){
            console.log('socket is connected already');
            return;
        }*/

        /*connect*/

        var dbProfile = null;
        dbProfile = new Database();

        console.log('new connect socket');

        //this.socket = io.connect(this.domain);
        this.socket = SocketNahi.connect(this.domain,function () {
            console.log('on connected');
            console.log('this.socket.on(connected,function(st){');
            that.connected = true;

            ////get profile API
            console.log(that.localData);
            var api = dbProfile.query({api: '/user/me',headers : {'x-auth-token': that.localData.token}});
            api.success(function (_data,_resp) {
                console.log('api success');
                console.log(_data);
                chatThis.profile = _data;
                console.log('chatThis.profile');
                console.log(that.profile);
                that.callbackConnect();
            });
            api.error(function (_data,_resp) {
                console.log('API error');
            });
            console.log('this.socket.on(connected,function(st){ ================');
            that.ListenMessages();
        });
        console.log('that.socket');
        console.log(this.socket);
        /*  on socket connected  */
/*        this.socket.on('connect',function(st){
            console.log('on connected');
            console.log('this.socket.on(connected,function(st){');
            that.connected = true;

            //if(this.localData==null) {
            //    this.localData = {
            //        "token": "b4c5a5473b17141b9604018b8c1cacefeffe58e1f775c2e79699ca72a945eae7",
            //        "tokenExpireAt": "2015-02-28T07:00:13.000Z"
            //    }; //token smartplus01@nahi.vn
            //}
            //   //check Local Storage
            //if(this.localData==null){
            //    console.log('localData null!!!!!!!!!!!!!!!');
            //    return 0;}
            //
            ////get profile API
            console.log(that.localData);
            var api = dbProfile.query({api: '/user/me',headers : {'x-auth-token': that.localData.token}});
            api.success(function (_data,_resp) {
                console.log('api success');
                console.log(_data);
                chatThis.profile = _data;
                console.log('chatThis.profile');
                console.log(that.profile);
                that.callbackConnect();
            });
            api.error(function (_data,_resp) {
                console.log('API error');
            });
            console.log('this.socket.on(connected,function(st){ ================');
            that.ListenMessages();
        });*/

        /* on socket error */
/*        this.socket.on('error', function(exception) {
            console.log('SOCKET ERROR');
            console.log(exception);
            that.connected = false;
            return 0;
        });*/
    };


    /**
     * trigger listen messages
     */
    this.ListenMessages= function(){
        this.socket.on('CHAT:ROOM:MESSAGE', function(data){
            Chat.showChat(data.sender ,data.message, data.createdAt,'world');
            console.log(data);
        });
        this.socket.on('CHAT:PEER:MESSAGE', function(data){
            Chat.showChat(data.sender ,data.message, data.createdAt,'private');
            console.log('CHAT:PEER:MESSAGE');
            console.log(data);
            Chat.addLocalStorage();
            Chat.checkObject(localData.get('historyChat'),data);
            localData.addItemTo('historyChat',data);
            Chat.showListHistory();
        });
    };


    /* socket post method */
    this.post= function (_url,_req,_callback) {
        console.log('chatAPI.socket..........');
        console.log(this);
        return chatThis.socket.post(_url,_req,_callback);
    };


    /**
     *  get user API
     */
    this.GetUser= function(nickname){
        var db = null;
        db = new Database();
        var usersearch = db.query({api: '/user/search', data: {'query':nickname},headers : {'x-auth-token': chatThis.profile.token}});
        usersearch.success(function(_data,_resp){
            console.log(_data);
            console.log(_resp);
            if(_resp != 'success'){
                console.log('users search fail......');
                return
            }
            users = [];
            for(var i=0;i<_data.length;i++){
                users[i] = _data[i];
            }
        });
        usersearch.error(function(xhr, status, error){
            console.log('search err');
            console.log(error);
        });
    };


    /**
     * find one user
     */
    this.findUser= function(nickname){
        var db = null;
        var usersearch = db.query({api: '/user/search', data: {'query':nickname},headers : {'x-auth-token': chatThis.profile.token}});
        usersearch.success(function(_data,_resp){
            if(_resp.statusCode == chatAPI.statusCodeErr){
                return
            }
            for(var i=0;i<_data.length;i++){
                if(_data[i].nickname==nickname){
                    console.log(_data[i]);
                    return _data[i];
                }
            }
        });
        usersearch.error(function(xhr, status, error){
            console.log(error);
        });
    };


    /* Set Domain for socket connecting */
    this.setDomain= function (_domain) {
        chatThis.domain = _domain;
    };


    //===================== CALLBACK FUNCTION =======================//

    /* callback connect */
    this.callbackConnect= function () {
        //console.log(this.isConnected);
        //if(!this.isConnected){
        //    console.log('callbackConnect .... fail ........');
        //    return;
        //}
        console.log('connected chatAPI.socket');
        console.log('chatThis.profile.token');
        console.log(chatThis.profile.token);
        console.log('callbackconnect this');
        console.log(this);
        chatThis.post('/chat/auth',{token: chatThis.profile.token},chatThis.callbackAuth);
    };


    /* callback Author */
    this.callbackAuth= function (_data,_resp) {
        console.log('callbackAuth..................................................................');
        console.log(_resp.statusCode);
        if(_resp.statusCode == chatAPI.statusCodeErr){
            console.log('CallbackAuth ERROR==============');
            return }
        console.log('callbackAuth this');
        console.log(chatThis);
        //chatAPI.post(chatAPI.url + '/chat/onlines', {token: chatThis.profile.token}, chatAPI.callbackUserOnline);
        ///// tim room co the tham gia
        chatThis.post('/chat/rooms',{token: chatThis.profile.token},chatThis.callbackRooms);
    };


    /* callback get User online */
    this.callbackUserOnline= function (_data,_resp) {
//        for (var i = 0; i < friends.length; i++) {
//            //log('friend' + i + ': ' + friends[i].nickname);
//        }
    };


    /* callback get Rooms */
    this.callbackRooms= function (_data,_resp) {
        console.log('callbackroom');
        console.log(_data);
        for (var i = 0, len=_data.length; i < len; i++) {
            if (_data[i].kind == 'PUBLIC'){
                chatThis.kenhthegioi = _data[i].id;
                break;
            }
        }
        console.log(chatThis.kenhthegioi);
        if(chatThis.kenhthegioi==null) {
            console.log('kenh the gioi == null ================');
            return
        }
        chatThis.post('/room/' + chatThis.kenhthegioi + '/join', {token: chatThis.profile.token}, chatThis.callbackJoinRoom);
    };


    /* callback Join Room*/
    this.callbackJoinRoom= function (_data,_resp) {
        console.log('callback join room');
        if(_resp.statusCode == chatThis.statusCodeErr){
            console.log('join room fail');
            return
        }
        if (!_data) {
            console.log("no room found");
            return
        }
        ///// sau khi join room
        ///// tim users dang join trong room
        //chatAPI.post('/room/' + chatAPI.kenhthegioi + '/onlines', {token: chatThis.profile.token}, chatAPI.callbackUserInRoom);
        //////  lay messages da chat
        if($("#world").css("display") == "block") {
            chatThis.post('/room/' + chatThis.kenhthegioi + '/messages', {token: chatThis.profile.token, limit: 20}, chatThis.callbackGetMessages);
        }
        else if($("#private").css("display") == "block") {
            try{
                chatThis.post('/chat/messages', {token: chatThis.profile.token,userid:chatThis.userOnchat.attr('user_id')}, chatThis.callbackGetMessagesPrivate);
            }catch (err){}
        }
    };


    /*callback get User online in Room*/
    this.callbackUserInRoom= function (_data,_resp) {
        if(_resp.statusCode == chatThis.statusCodeErr){
            return;
        }
    };


    /*callback get messages on World Room*/
    this.callbackGetMessages= function (_data,_resp) {
        if(_resp.statusCode != 200){
            console.log('get message fail');
            return }
        console.log(_data);
        var len = _data.length;
        for (var i = len - 1; i >= 0; i--) {
            Chat.showChat(_data[i].sender, _data[i].message, _data[i].createdAt,'world');
        }

    };


    /* callback get messages private */
    this.callbackGetMessagesPrivate= function(_data,_resp){
        //if(messages.length!=0 && chatAPI.userOnchat != chatAPI.userOnchat1) {
        //    $("#privateScroll").html('');
        //    for (var i = messages.length - 1; i >= 0; i--) {
        //        Chat.showChat(messages[i].sender, messages[i].message, 'private');
        //    }
        //}
        //else if(chatAPI.userOnchat == chatAPI.userOnchat1){
        //    Chat.showChat(messages[0].sender, messages[0].message, 'private');
        //}
        //else{
        //    $("#privateScroll").html('');
        //}
        //chatAPI.userOnchat1 = chatAPI.userOnchat;
        if(_resp.statusCode != 200){
            console.log('callbackGetMessagesPrivate fail............');
            return;
        }
        console.log('callbackGetMessagesPrivate success');
        $("#privateScroll").html('');
        for (var i = _data.length - 1; i >= 0; i--) {
            Chat.showChat(_data[i].sender, _data[i].message, _data[i].createdAt, 'private');
        }
    };


    /* callback send messages on World Room */
    this.callbacksendPublic= function(_data,_resp) {
        if(_resp.statusCode == chatThis.statusCodeErr){
            return
        }
        $(".chat-text-virtual").val("");
        $(".chat-text").val("");
        $(".chat-text-virtual").blur();
        Chat.showChat(_data.sender,_data.message, _data.createdAt,'world');
    };


    /* callback send messages private */
    this.callbacksendPrivate= function(_data,_resp) {
        if(_resp.statusCode != 200){
            console.log('callbackSendPrivate fail...............');
            return;
        }
        console.log('callback send private');
        console.log(_data);
        var data = _data;
        $(".chat-text-virtual").val("");
        $(".chat-text").val("");
        $(".chat-text-virtual").blur();
        Chat.showChat(_data.sender,_data.message, _data.createdAt,'private');
    };




    ///===================== CHAT API NAVIGATION ========================///

};