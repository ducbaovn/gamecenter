/**
 * @author       Roca Chien <chienvd@nahi.vn>
 * @copyright    2014 NAHI JSC.
 * @license      {@link http://www.nahi.vn/vn/gioi-thieu-ve-nahi.html}
 */

/**
 * This is variable from device. Any variable from device assign to html,
 *
 * @class DeviceVariable
 * @constructor
 * @param {object} [config=null] - The default config object or null.
 */

var DeviceVariable = function(config){
    /**
     * @property {object} config - The SmartPlus.Database config object.
     */
    if(config) this.parseConfig(config);

    /**
     * @property {number} timeOut - The time out to waiting connection with the server. Default: 60 second
     */
    this.platform = "123123";

    this.deviceID = "123123";

    this.xAuthToken = "";

    this.tokenExpireAt = "";
};
DeviceVariable.prototype = {
    parseConfig: function (config) {

        this.config = config;

        if (config['platform'])
        {
            this.platform = config['platform'];
        }

        if (config['deviceID'])
        {
            this.deviceID = config['deviceID'];
        }

        if (config['xAuthToken'])
        {
            this.xAuthToken = config['xAuthToken'];
        }

        if (config['tokenExpireAt'])
        {
            this.tokenExpireAt = config['tokenExpireAt'];
        }
    }
};