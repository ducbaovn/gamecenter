/* TRAN PHAN THANH
 *  Thanhpt@nahi.vn
 *  Create: 5/11/2014
 *  Project: Game Center
 *  main.js
 * */

//-------------------------------------
"use strict";
//-------------------------------------
function RunGameMath(){
    /*  Waiting screen*/
    ToanThanToc.waiting = new Phaser.Game(ToanThanToc.SCREEN_WIDTH, ToanThanToc.SCREEN_HEIGHT, Phaser.CANVAS, 'waiting', true, true);
    jQuery.extend(ToanThanToc.waiting, ToanThanToc.Waiting);
    ToanThanToc.waiting.open();
    //Start game
    var game = new Phaser.Game(ToanThanToc.SCREEN_WIDTH, ToanThanToc.SCREEN_HEIGHT , Phaser.CANVAS, 'gameMath',true,true);
    ToanThanToc.game=game;
    ToanThanToc.game.state.add('Boot', ToanThanToc.Boot);
    ToanThanToc.game.state.add('Loader', ToanThanToc.Loader);
    ToanThanToc.game.state.add('FlashIntro', ToanThanToc.FlasIntro);
    ToanThanToc.game.state.add('Menu', ToanThanToc.Menu);
    /* STATE FOR SOLO */
    ToanThanToc.game.state.add('MenuSolo', ToanThanToc.MenuSolo);
    ToanThanToc.game.state.add('SoloPlay',ToanThanToc.SoloPlay);
    ToanThanToc.game.state.add('EndSoloPlay',ToanThanToc.EndSoloPlay);
    /*STATE FOR SINGLE*/
    ToanThanToc.game.state.add('MenuSingle', ToanThanToc.MenuSingle);
    ToanThanToc.game.state.add('SinglePlay', ToanThanToc.SinglePlay);
    ToanThanToc.game.state.add('HighScoresSingle', ToanThanToc.HighScoresSingle);
    ToanThanToc.game.state.add('SingleCreateChallenges', ToanThanToc.SingleCreateChallenges);
    ToanThanToc.game.state.add('SingleListChallenges', ToanThanToc.SingleListChallenges);

    /* STATE FOR ONLINE MODE */
    ToanThanToc.game.state.add('MenuOnline',ToanThanToc.MenuOnline);
    ToanThanToc.game.state.add('OnlineRoomChoose',ToanThanToc.OnlineRoomChoose);
    ToanThanToc.game.state.add('OnlineRoomWaiting',ToanThanToc.OnlineRoomWaiting);
    ToanThanToc.game.state.add('OnlineCreateRoom',ToanThanToc.CreateRoom);
    ToanThanToc.game.state.add('OnlineMathResult',ToanThanToc.OnlineMathResult);
    ToanThanToc.game.state.add('OnlineDetailResultWin',ToanThanToc.OnlineDetailResultWin);
    ToanThanToc.game.state.add('OnlineDetailResultLose',ToanThanToc.OnlineDetailResultLose);
    ToanThanToc.game.state.add('OnlinePlayingRoom',ToanThanToc.OnlinePlayingRoom);
    ToanThanToc.game.state.add('OnlineUserView',ToanThanToc.OnlineUserView);


    ToanThanToc.game.state.start('Boot');
}

function GetConfigMath(callback) {
    ToanThanToc.db.setAtuthToken(ToanThanToc.MyToken);
    var  postConfigMath = ToanThanToc.db.query({api: '/math/config'});
    postConfigMath.success(function(data){
        ToanThanToc.configMath = data;
        callback(ToanThanToc.configMath);
    });
    postConfigMath.error(function(data){
        callback('error');
        return false;
    });
}

function GetUserMathInfor(callback) {
    ToanThanToc.db.setAtuthToken(ToanThanToc.MyToken);
    var  postUserMathInfo = ToanThanToc.db.query({api: '/math/myinfo'});
    postUserMathInfo.success(function(data){
        ToanThanToc.infoUserMath = data;
        callback(ToanThanToc.infoUserMath);
    });
    postUserMathInfo.error(function(data){
        callback('error');
        return false;
    });
}

window.onload = function()
{
    /*Sync device variable to Javascript*/
    ToanThanToc.device = new DeviceVariable();
    /*     Connection with APIs*/
    ToanThanToc.db = new Database();
    ToanThanToc.db.parseHeader();

    /* Fix Scale */
    ToanThanToc.innerWidth = window.innerWidth;
    ToanThanToc.innerHeight = window.innerHeight;

    log(' window.innerWidth = '+ window.innerWidth);
    log(' window.innerHeight = '+ window.innerHeight);
    /* run video lasted pause */
    var wh= ToanThanToc.innerWidth.toString() +'px ' +ToanThanToc.innerHeight.toString()+'px';
    $('#waiting').css({'background-size':wh});
    fixBgLoad();
    if(ToanThanToc.innerWidth<ToanThanToc.innerHeight)
        $('video').css({
            'position': 'absolute',
            'height': 'inherit',
            'width': ToanThanToc.innerWidth.toString()+'px',
            'top': '0',
            'left': '0'
        });
    else
    {
        $('video').css({
           'position': 'absolute',
            width: '100%',
            top:  '-'+(ToanThanToc.innerWidth - ToanThanToc.innerHeight ).toString()+'px',
            left:0
        });
    }

    /*  su dung HTML5 Video */
    //ToanThanToc.video = document.getElementById('player1');
    //ToanThanToc.video.muted = true;
    //ToanThanToc.video.play();
    setTimeout(function(){
        //ToanThanToc.video.pause();
        RunGameMath();
    },10);

};