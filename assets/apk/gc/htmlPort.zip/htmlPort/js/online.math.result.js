/**
 * Created by TILE on 06/01/15.
 */
"use strict";

/**
 * Return result when the end of a math.
 * @param _game
 * @constructor
 */
ToanThanToc.OnlineMathResult = function(_game){};
ToanThanToc.OnlineMathResult.prototype = {
    /* ----------------- VARIABLE -------------------- */
    btnExit:null,
    txtStyle1 :[{font: "70px segoe ui", fill: "#FFF"}],
//        txtStyle2 = {font: "70px segoe ui",fontWeight:'bold', fill: "#FFF200", strokeThickness:8},
    txtStyle3 : {font: "40px segoe ui", fill: "#FFF", strokeThickness:8},
    txtSecond : null,
    background:null,
    strDetail : 'Chi tiết',
    strPeople : 'người',
    arrayButton : [],
    txtTeam : null,
    teamNumberPeople: null,
    txtPeople : null,
    strTeam : 'Đội ',
    strStarPeople : '1',
    indexWinner : -1,
    cong:null,

    /**
     * Data test default.
     * @type {{owner: string, mathroom: string, startTime: string, endTime: string, status: string,
     * name: string, playboards: {name: string, scoreUpdatedAt: string, score: number, players:
     * {id: string, fullname: string, nickname: string, avatar_url: string, gender: string, dob: string,
     * level: number, team: number, score: number}[]}[], id: string}}
     */
    arrayDefault : {"owner":"54a39ea647004cbb54f3c746","mathroom":"54b488a70cfff4277235a58f",
        "startTime":"2015-01-13T02:54:43.277Z","endTime":"2015-01-13T02:54:43.277Z","status":"FINISHED","name":"A",
        "playboards":[{"name":"1","scoreUpdatedAt":"2015-01-13T02:54:38.650Z","score":22,
            "players":[{"id":"54a39ea647004cbb54f3c746","fullname":"nahi2@nahi.vn","nickname":"nahi2@nahi.vn",
                "avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":1,"score":22}]},
            {"name":"2","scoreUpdatedAt":"2015-01-13T02:54:41.355Z","score":6,
                "players":[{"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn","nickname":"nahi1@nahi.vn",
                    "avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":2,"score":6}]}],
        "id":"54b488c10cfff4277235a591"},

    /** List View */
     list : null,
     bg_second:null,


    /* ----------------- VARIABLE END -------------------- */

    /**
     * Create math result
     */
        preload:function(){

        if( ToanThanToc.game.cache.checkImageKey('result_bgMathResult') &&
            ToanThanToc.game.cache.checkImageKey('onlineStarWin') &&
            ToanThanToc.game.cache.checkImageKey('result_btnDetail') &&
            ToanThanToc.game.cache.checkImageKey('list_line') &&
            ToanThanToc.game.cache.checkImageKey('1medals') &&
            ToanThanToc.game.cache.checkImageKey('2medals') &&
            ToanThanToc.game.cache.checkImageKey('result_out') &&
            ToanThanToc.game.cache.checkImageKey('result_back') &&
            ToanThanToc.game.cache.checkImageKey('result_topPlayer') &&
            ToanThanToc.game.cache.checkImageKey('avatar_default') &&
            ToanThanToc.game.cache.checkImageKey('Score')){
            return;
        }
        ToanThanToc.game.load.spritesheet('result_bgMathResult','assets/online/result/bgMathResult.png', 800, 1232);
        ToanThanToc.game.load.spritesheet('onlineStarWin', 'assets/online/result/starscore.png');
        ToanThanToc.game.load.spritesheet('result_btnDetail', 'assets/online/result/btnDetail.png',130,84);
        ToanThanToc.game.load.spritesheet('list_line', 'assets/online/plays/list_line.png');
        ToanThanToc.game.load.spritesheet('1medals', 'assets/online/result/medals_1.png');
        ToanThanToc.game.load.spritesheet('2medals', 'assets/online/room-play/2medals.png');
        ToanThanToc.game.load.spritesheet('result_out', 'assets/online/result/out.png',105,115);
        ToanThanToc.game.load.spritesheet('result_back', 'assets/online/result/back.png',105,115);
        ToanThanToc.game.load.spritesheet('result_topPlayer', 'assets/online/result/topPlayer.png');
        ToanThanToc.game.load.spritesheet('Score', 'assets/online/result/Score.png');
    },
    create : function(){

        /*show button home chat*/
        $('#homeVirtual').show();

        var that=ToanThanToc.OnlineMathResult.prototype;

        that.background = ToanThanToc.game.add.image(0,0,'result_bgMathResult');
        that.btnExit = ToanThanToc.game.add.button(160.5,1026,'btn_exit',this.clickExit, ToanThanToc.game,0,0,1,0);
        that.bg_second = ToanThanToc.game.add.image(310,890,'onlineStarWin');

        that.txtTeam = ToanThanToc.game.add.text(91,915,that.strTeam,{fill:'#ffffff',font:'bold 45px Segoe UI',strokeThickness:0});
        that.txtTeam.setShadow(0, 3, 'rgba(0,0,0,0.5)', 0);
        that.cong=ToanThanToc.game.add.text(230,910,'+',{fill:'#ffffff',font:'bold 53px Segoe UI',strokeThickness:0});
        that.cong.setShadow(0, 3, 'rgba(0,0,0,0.5)', 0);
        that.teamNumberPeople = ToanThanToc.game.add.text(590,917,'/ người',{fill:'#ffffff',font:'bold 35px Segoe UI'});
        that.txtPeople = ToanThanToc.game.add.text(460,908,that.strStarPeople,{fill:'#ffffff',font:'bold 50px Segoe UI', align:'center'});
        that.txtPeople.anchor.set(0.5,0);
//        txtTeam.setStyle(txtStyle2);
//        txtTeam.fontWeight = 'bold';
//        txtTeam.fontSize = 50;
//        txtPeople.setStyle(txtStyle3);
//        txtPeople.fontWeight = 'bold';
//        txtPeople.fontSize = 30;


        // Create list
        that.createList(this.arrayDefault.playboards);

        /** Check winner. */
        that.indexWinner = this.checkTeamWin(that.arrayDefault.playboards);
        if(ToanThanToc.nameSpaceBefore!="OnlineDetailResultWin") {
            this.checkThisWin();
        }

    },

    /**
     * Default update.
     */
    update: function(){
        if(ToanThanToc.OnlineMathResult.prototype.list != null){
            ToanThanToc.OnlineMathResult.prototype.list.update();
        }
    },



    /**
     * Button exit click.
     */
    clickExit : function(){
        shareFunction.actionPlayAudio('touch');
        shareFunction.actionPlayAudio('music');
        if(ToanThanToc.dataQuestionTemp != null){
            ToanThanToc.game.stage.destroy();
            ToanThanToc.game.state.start("OnlineRoomWaiting");
            ToanThanToc.nameSpace = 'waitingRoom';
        }

    },


    /**
     * Scroll view
     */
    createList : function(array){
        var arrayFreeRoom = {};
        for(var i = 0; i < array.length;++i){
            var arrayTemp = 0;
            var temp = i+1;
            arrayTemp = [

                { // Number people of a team.
                    xBuffer: 237,
                    yBuffer: 35,
                    name: array[i].players.length+" "+ToanThanToc.OnlineMathResult.prototype.strPeople,
//                    strokeThickness: 5,
//                    fontSize: 20,
//                    fontWeight: 'bold',
                    anchor: 0,
                    shadow: '0|3|rgba(0,0,0,1)|0',
                    property: {font: "bold 35px Segoe UI", fill: "#ffffff", align: "center"},
                    type: 'textmem',
                    isShow: 1
                },


                { // Text team
                    xBuffer: 68,
                    yBuffer: 27,
                    name: 'Đội '+ array[i].players[0].team,
//                    strokeThickness: 5,
//                    fontSize: 30,
//                    fontWeight: 'bold',
                    anchor: 0,
                    shadow: '0|0|rgba(0,0,0,0)|0',
                    property: {font: "bold 45px Segoe UI", fill: "#ffffff", align: "center",strokeThickness:0, stroke:'#a5e24d'},
                    type: 'text', isShow: 1
                },
                {
                    xBuffer: 412,
                    yBuffer: 14,
                    name: 'result_btnDetail',
                    property: {type:i},
                    type: 'button',
                    isShow: 1
                },
                {
                    xBuffer: -55, yBuffer: 110, name: 'list_line',
                    property: {},
                    type: 'image', isShow: 1
                }
            ];
            if(i == 0) {
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -43,
                        yBuffer: 0,
                        name: '1medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }else if(i == 1) {
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -43,
                        yBuffer: 0,
                        name: '2medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }else if(i == 2){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -43,
                        yBuffer: 0,
                        name: '3medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }else{
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: 5,
                        yBuffer: 10,
                        name: temp + 'medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }


            if(arrayTemp){
                arrayFreeRoom[Object.keys(arrayFreeRoom).length] = arrayTemp;
            }

        }


        /* Create List */
        ToanThanToc.OnlineMathResult.prototype.list = new ListScroll(arrayFreeRoom,
            150, 218, 480, 500,117,'mathResult',ToanThanToc.OnlineMathResult.prototype,
            ToanThanToc.OnlineMathResult.prototype.arrayButton,'result_bgMathResult');
        ToanThanToc.OnlineMathResult.prototype.list.makeList();
    },

    /**
     * List click item.
     */
    onClick : function(){
        shareFunction.actionPlayAudio('touch');
        ToanThanToc.game.stage.destroy();
//        ToanThanToc.game.state.start("OnlineDetailResultWin");
        ToanThanToc.OnlineMathResult.prototype.showDetailTeam(ToanThanToc
            .OnlineMathResult.prototype.arrayDefault, this.type);
    },


    /**
     * Function check team win.
     * @param data
     * @returns {number} index of the team win.
     */
    checkTeamWin : function(data){
        var i = 1;
        var winner = 0;
        var k = -1; // Check all the team score is zero.
        for(i;i < data.length; ++i){
            if(data[i].score > data[winner].score){
                winner = i;
            }
            if(data[i-1].score > 0){
                k = 0;
            }
        }

        /* If all the team score is zero. */
        if(k == -1){
            winner = k;
        }

        if(winner != -1){
            /** Show name team win. */
            ToanThanToc.OnlineMathResult.prototype.txtTeam.text += data[winner].name;
        }else{
            /** Show name team win. */
            ToanThanToc.OnlineMathResult.prototype.cong.text = '';
            ToanThanToc.OnlineMathResult.prototype.txtTeam.text = "HOÀ";


        }
        // Return index team win.
        return winner;
    },

    /**
     * Show detail room.
     * For detail button click.
     * @param data
     */
    showDetailTeam : function(data,idButton){

        if(this.indexWinner != -1){
            if(Socket.checkIDResutl(data.playboards[ToanThanToc.OnlineMathResult.prototype.indexWinner]) == true){ // Show team winner.
                ToanThanToc.OnlineDetailResultWin.prototype.array = data.playboards[idButton];
                ToanThanToc.OnlineDetailResultWin.prototype.starPerMember =
                    data.starPerMember ? data.starPerMember : 0;
                ToanThanToc.game.state.start("OnlineDetailResultWin");
                ToanThanToc.nameSpace = 'winnerScreen';
            }else{ // Show team lose.
                ToanThanToc.OnlineDetailResultLose.prototype.array = data.playboards[idButton];
                ToanThanToc.game.state.start("OnlineDetailResultLose");
                ToanThanToc.nameSpace = 'loserScreen';
            }
        }else{ // all team score is zero.
            ToanThanToc.OnlineDetailResultLose.prototype.array = data.playboards[idButton];
            ToanThanToc.game.state.start("OnlineDetailResultLose");
            ToanThanToc.nameSpace = 'loserScreen';
        }
    },
    checkThisWin: function () {
        if(this.indexWinner != -1){
            var n = ToanThanToc.OnlineMathResult.prototype.indexWinner;
            if (Socket.checkIDResutl(this.arrayDefault.playboards[n]) == true) {
                shareFunction.actionPlayAudio('win');
            }else {
                shareFunction.actionPlayAudio('lose');
            }
        }else{ // all team score is zero.
            shareFunction.actionPlayAudio('lose');
        }
        shareFunction.actionStopAudio('music');
    },
    destroy: function(){
        this.btnExit.destroy();
        this.txtStyle1 = null;
        this.txtStyle3 = null;
        this.txtSecond = null;
        this.background = null;
        this.that = null;
        this.strDetail = null;
        this.strPeople = null;
        this.arrayButton = null;
        this.txtTeam = null;
        this.txtPeople = null;
        this.strTeam = null;
        this.strStarPeople = null;
        this.indexWinner = null;
        /** List View */
        this.list = null;
        this.bg_second = null;
    }

};
