/**
 * Created by duynguyen on 27/01/2015.
 * share.function
 */

var shareFunction = {

    /*action play audio*/
    actionPlayAudio: function(_type){
        if(SetMusic.touch)
        {
            if(_type=='touch') {
                ToanThanToc.music_touch.play();
            }else if(_type=='right'){
                ToanThanToc.music_popupMainAction.play();
            }else if(_type=='wrong'){
                ToanThanToc.music_wrong.play();
            }else if(_type=='win'){
                if(SetMusic.music)
                ToanThanToc.music_win.play();
            }else if(_type=='lose') {
                if(SetMusic.music)
                ToanThanToc.music_lose.play();
            }else if(_type=='music'){
                ToanThanToc.music_music.play();
            }
        }
    },

    /*action stop audio*/
    actionStopAudio: function(_type){
        if(_type=='touch') {
            ToanThanToc.music_touch.stop();
        }else if(_type=='right'){
            ToanThanToc.music_popupMainAction.stop();
        }else if(_type=='wrong'){
            ToanThanToc.music_wrong.stop();
        }else if(_type=='win'){
            ToanThanToc.music_win.stop();
        }else if(_type=='lose') {
            ToanThanToc.music_lose.stop();
        }else if(_type=='music'){
            ToanThanToc.music_music.stop();
        }

    }
};