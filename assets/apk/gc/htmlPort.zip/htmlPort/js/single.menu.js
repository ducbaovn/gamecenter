/**
 * Created by thanhpt from NAHI on 1/21/2015.
 * @Author: tpt2213
 */
"use strict";

ToanThanToc.MenuSingle = function (game) {
};

ToanThanToc.MenuSingle.prototype = {
    btnMenuSoloPlay:null,
    btnMenuSoloDivision:null,
    btnMenuSoloMinus:null,
    btnMenuSoloMulti:null,
    btnMenuSoloPlus:null,

    btnMenuSoloEasy:null,
    btnMenuSoloMedium:null,
    btnMenuSoloHard:null,

    isLevl:null,
    isPlaySingle:false,
    isBackSingle:false,
    isHighScores:false,
    preload : function() {
        ToanThanToc.MenuSingle.prototype.isNameClick=null;
        ToanThanToc.popupShow=0;
    },

    create : function() {

        /*show button home chat*/
        $('#homeVirtual').show();

        /*   Phan MenuSingleMenuSingle    */
        ToanThanToc.SinglePlay.prototype.isNameClick=null;
        ToanThanToc.popupShow=0;
        this.CreatePageMenuSingle();
       // this.initSelectBox();
    },

    render:function() {

    },

    update : function() {
        if(ToanThanToc.MenuSingle.prototype.isPlaySingle)
        {
            ToanThanToc.MenuSingle.prototype.isPlaySingle=false;
            ToanThanToc.MenuSingle.prototype.SetScorceTime();
            SetCssBody('url(assets/single/background/bg.png) no-repeat center center fixed');
            ToanThanToc.MenuSingle.prototype.DeletePageMenuSingle();
            ToanThanToc.game.stage.destroy();
            ToanThanToc.MenuSingle.prototype.isNameClick=null;
            ToanThanToc.game.state.start('SinglePlay');
        }
        else if(ToanThanToc.MenuSingle.prototype.isBackSingle)
        {
            SetCssBody('url(assets/solo/background/background.png) no-repeat center center fixed');
            ToanThanToc.MenuSingle.prototype.isBackSingle=false;
            ToanThanToc.MenuSingle.prototype.DeletePageMenuSingle();
            ToanThanToc.game.stage.destroy();
            ToanThanToc.MenuSingle.prototype.isNameClick=null;
            ToanThanToc.game.state.start('Menu');
        }
        else if(ToanThanToc.MenuSingle.prototype.isHighScores){
            SetCssBody('url(assets/single/background/bgok.png) no-repeat center center fixed');
            ToanThanToc.MenuSingle.prototype.isHighScores=false;
            ToanThanToc.MenuSingle.prototype.DeletePageMenuSingle();
            ToanThanToc.game.stage.destroy();
            ToanThanToc.nameSpace = '';
            ToanThanToc.MenuSingle.prototype.isNameClick=null;
            ToanThanToc.game.state.start('HighScoresSingle');
        }
    },

    ShowTime:function(item){
        var time = [];
        if(item==20){
            time.push( { value: 20, text: '20 giây' ,selected: true});
            time.push( { value: 30, text: '30 giây' });
            time.push( { value: 50, text: '50 giây' });
        }
        else if(item==30){
            time.push( { value: 20, text: '20 giây' });
            time.push( { value: 30, text: '30 giây' ,selected: true});
            time.push( { value: 50, text: '50 giây' });
        }
        else if(item==50){
            time.push( { value: 20, text: '20 giây' });
            time.push( { value: 30, text: '30 giây' });
            time.push( { value: 50, text: '50 giây' ,selected: true});
        }
        else if(item==0)
        {
            time.push( { value: 20, text: '20 giây' });
            time.push( { value: 30, text: '30 giây' });
            time.push( { value: 50, text: '50 giây' });
        }
        return time
    },

    ShowScore:function(item){
        var score = [];
        if(item==20){
            score.push( { value: 20, text: '20 điểm' ,selected: true});
            score.push( { value: 30, text: '30 điểm' });
            score.push( { value: 50, text: '50 điểm' });
        }
        else if(item==30){
            score.push( { value: 20, text: '20 điểm' });
            score.push( { value: 30, text: '30 điểm' ,selected: true});
            score.push( { value: 50, text: '50 điểm' });
        }
        else if(item==50){
            score.push( { value: 20, text: '20 điểm' });
            score.push( { value: 30, text: '30 điểm' });
            score.push( { value: 50, text: '50 điểm' ,selected: true});
        }
        else if(item==0)
        {
            score.push( { value: 20, text: '20 điểm' });
            score.push( { value: 30, text: '30 điểm' });
            score.push( { value: 50, text: '50 điểm' });
        }
        return score
    },

    initSelectBox: function() {
        var score = ToanThanToc.MenuSingle.prototype.ShowScore(ToanThanToc.soloPlayScore);
        var time = ToanThanToc.MenuSingle.prototype.ShowTime(ToanThanToc.soloPlayTime);

        log(score);
        log(time);
        ToanThanToc.MenuSingle.timeSelectBox = new SelectBox({
            game: ToanThanToc.game,
            data: time,
            selectBoxSpriteSheetId: 'btnListMsl',
            selectBoxPosition: {x: 129, y: 898},
            selectBoxTitle: 'Thời gian',
            selectBoxTitleStartPosition: {x: 40, y: 34},
            listBackgroundImageId: 'bgListBox',
            listBackgroundImagePosition: {x: 145, y: 987},
            listTextStartPosition: {x: 65, y: 22},
            listItemBackgroundImageId: 'bgSelectItemMSL',
            oneInstanceMode: true,
            dependencySelectBoxes: [],
            onClickOnSelectBox: function() {
                if(SetMusic.touch)
                    ToanThanToc.music_touch.play();
            },
            onSelect: function(selectedItem) {
                if(SetMusic.touch)
                    ToanThanToc.music_popupMainAction.play();
                if (selectedItem == null) {
                    ToanThanToc.soloPlayTime = 0;
                }
                else {
                    ToanThanToc.soloPlayTime = selectedItem.value;
                }
            }
        });

        ToanThanToc.MenuSingle.scoreSelectBox = new SelectBox({
            game: ToanThanToc.game,
            data: score,
            selectBoxSpriteSheetId: 'btnListMsl',
            selectBoxPosition: {x: 426, y: 898},
            selectBoxTitle: 'Điểm',
            selectBoxTitleStartPosition: {x: 85, y: 34},
            listBackgroundImageId: 'bgListBox',
            listBackgroundImagePosition: {x: 442, y: 987},
            listTextStartPosition: {x: 55, y: 22},
            listItemBackgroundImageId: 'bgSelectItemMSL',
            oneInstanceMode: true,
            dependencySelectBoxes: [],
            onClickOnSelectBox: function() {
                if(SetMusic.touch)
                    ToanThanToc.music_touch.play();
            },
            onSelect: function(selectedItem) {
                if(SetMusic.touch)
                    ToanThanToc.music_popupMainAction.play();
                if (selectedItem == null) {
                    ToanThanToc.soloPlayScore = 0;
                }
                else {
                    ToanThanToc.soloPlayScore = selectedItem.value;
                }
            }
        });

        ToanThanToc.MenuSingle.timeSelectBox.setDependencySelectBoxes([ToanThanToc.MenuSingle.scoreSelectBox]);
        ToanThanToc.MenuSingle.scoreSelectBox.setDependencySelectBoxes([ToanThanToc.MenuSingle.timeSelectBox]);
    },

    CreatePageMenuSingle: function(){

        ToanThanToc.MenuSingle.prototype.logoNahi =ToanThanToc.game.add.sprite(16,16,'logoNAHI');
        ToanThanToc.MenuSingle.prototype.logoVNM =ToanThanToc.game.add.sprite(707,16,'logoVnm');

        ToanThanToc.MenuSingle.prototype.btnMenuSoloEasy = ToanThanToc.game.add.sprite(180,285,'btnMenuSoloEasy');
        ToanThanToc.MenuSingle.prototype.btnMenuSoloEasy.inputEnabled=true;
        ToanThanToc.MenuSingle.prototype.btnMenuSoloEasy.events.onInputDown.add(this.ActionClickMenuSingle,ToanThanToc.game);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloMedium = ToanThanToc.game.add.sprite(180,415,'btnMenuSoloMedium');
        ToanThanToc.MenuSingle.prototype.btnMenuSoloMedium.inputEnabled=true;
        ToanThanToc.MenuSingle.prototype.btnMenuSoloMedium.events.onInputDown.add(this.ActionClickMenuSingle,ToanThanToc.game);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloHard = ToanThanToc.game.add.sprite(180,539,'btnMenuSoloHard');
        ToanThanToc.MenuSingle.prototype.btnMenuSoloHard.inputEnabled=true;
        ToanThanToc.MenuSingle.prototype.btnMenuSoloHard.events.onInputDown.add(this.ActionClickMenuSingle,ToanThanToc.game);
        ToanThanToc.MenuSingle.prototype.ShowLevel();

        ToanThanToc.MenuSingle.prototype.btnMenuSoloPlus = ToanThanToc.game.add.button(133,700,'btnMenuSoloPlus',null,ToanThanToc.game);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloPlus.events.onInputDown.add(this.ActionClickMenuSingle);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloMinus = ToanThanToc.game.add.button(275,700,'btnMenuSoloMinus',null,ToanThanToc.game);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloMinus.events.onInputDown.add(this.ActionClickMenuSingle);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloMulti = ToanThanToc.game.add.button(415,700,'btnMenuSoloMulti',null,ToanThanToc.game);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloMulti.events.onInputDown.add(this.ActionClickMenuSingle);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloDivision = ToanThanToc.game.add.button(558,700,'btnMenuSoloDivision',null,ToanThanToc.game);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloDivision.events.onInputDown.add(this.ActionClickMenuSingle);

        ToanThanToc.MenuSingle.prototype.ShowPhepTinh();

        ToanThanToc.MenuSingle.prototype.btnMenuSoloPlay = ToanThanToc.game.add.button(40,985,'btnMenuSoloPlay',null,ToanThanToc.game,0,0,1);
        ToanThanToc.MenuSingle.prototype.btnMenuSoloPlay.events.onInputDown.add(this.ActionClickMenuSingle);

        ToanThanToc.MenuSingle.prototype.btnMenuSoloBackTT = ToanThanToc.game.add.button(
                ToanThanToc.game.world.centerX-113/2,988,'btnBackTT',this.ActionClickMenuSingle,ToanThanToc.game,0,0,1);

        ToanThanToc.MenuSingle.prototype.btnHighScoreSG = ToanThanToc.game.add.button(524,953,'btnHighScoreSG',null,ToanThanToc.game,0,0,1);
        ToanThanToc.MenuSingle.prototype.btnHighScoreSG.events.onInputDown.add(this.ActionClickMenuSingle);
    },

    ShowLevel:function(){
        if(ToanThanToc.isLevelSolo==null)
        {
            ToanThanToc.isLevelSolo='EASY';
            ToanThanToc.MenuSingle.prototype.btnMenuSoloEasy.frame=2;
        }
        else if(ToanThanToc.isLevelSolo=='EASY')
            ToanThanToc.MenuSingle.prototype.btnMenuSoloEasy.frame=2;
        else if(ToanThanToc.isLevelSolo=='MEDIUM')
            ToanThanToc.MenuSingle.prototype.btnMenuSoloMedium.frame=2;
        else if(ToanThanToc.isLevelSolo=='HARD')
            ToanThanToc.MenuSingle.prototype.btnMenuSoloHard.frame=2;

    },

    ShowPhepTinh:function(){
        if(!ToanThanToc.plusSolo && !ToanThanToc.minusSolo && !ToanThanToc.multiSolo && !ToanThanToc.divisionSolo)
        {
            ToanThanToc.MenuSingle.prototype.btnMenuSoloPlus.frame=2;
            ToanThanToc.plusSolo=true;
        }
        if(ToanThanToc.plusSolo)
            ToanThanToc.MenuSingle.prototype.btnMenuSoloPlus.frame=2;
        if(ToanThanToc.minusSolo)
            ToanThanToc.MenuSingle.prototype.btnMenuSoloMinus.frame=2;
        if(ToanThanToc.multiSolo)
            ToanThanToc.MenuSingle.prototype.btnMenuSoloMulti.frame=2;
        if(ToanThanToc.divisionSolo)
            ToanThanToc.MenuSingle.prototype.btnMenuSoloDivision.frame=2;
    },

    setUnCheckThreeOption:function(){
        ToanThanToc.MenuSingle.prototype.btnMenuSoloEasy.frame=0;
        ToanThanToc.MenuSingle.prototype.btnMenuSoloMedium.frame=0;
        ToanThanToc.MenuSingle.prototype.btnMenuSoloHard.frame=0;
        ToanThanToc.isLevelSolo=null;
    },

    CheckForCheck:function(){
        var i=0;
        var tam = false;
        if(tam==ToanThanToc.plusSolo)
            i++;
        if(tam==ToanThanToc.minusSolo)
            i++;
        if(tam==ToanThanToc.multiSolo)
            i++;
        if(tam==ToanThanToc.divisionSolo)
            i++;
        if(i==4)
            return true;
        return false;
    },

    ActionClickMenuSingle : function(item){
        log(item.key);
        if(ToanThanToc.music_touch && SetMusic.touch && item.key!='btnOff'&& item.key!='btnXacNhan')
            ToanThanToc.music_touch.play();
        /* Chon cac level */
        if(ToanThanToc.MenuSingle.prototype.isNameClick==null)
        {
            if(item.key=='btnMenuSoloEasy') {
                ToanThanToc.MenuSingle.prototype.setUnCheckThreeOption();
                ToanThanToc.isLevelSolo='EASY';
                ToanThanToc.MenuSingle.prototype.btnMenuSoloEasy.frame=1;
                ToanThanToc.MenuSingle.prototype.btnMenuSoloEasy.frame=2;
            }
            else if(item.key=='btnMenuSoloMedium')
            {
                ToanThanToc.MenuSingle.prototype.setUnCheckThreeOption();
                ToanThanToc.isLevelSolo='MEDIUM';
                ToanThanToc.MenuSingle.prototype.btnMenuSoloMedium.frame=1;
                ToanThanToc.MenuSingle.prototype.btnMenuSoloMedium.frame=2;
            }else if(item.key=='btnMenuSoloHard')
            {
                ToanThanToc.MenuSingle.prototype.setUnCheckThreeOption();
                ToanThanToc.isLevelSolo='HARD';
                ToanThanToc.MenuSingle.prototype.btnMenuSoloHard.frame=1;
                ToanThanToc.MenuSingle.prototype.btnMenuSoloHard.frame=2;

                /* Chon cac phep tinh */
            }else if(item.key=='btnMenuSoloPlus')
            {
                if(ToanThanToc.plusSolo)
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloPlus.frame=0;
                    ToanThanToc.plusSolo = false;
                }
                else{
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloPlus.frame=1;
                    setTimeout(function(){
                        ToanThanToc.MenuSingle.prototype.btnMenuSoloPlus.frame=2;
                        ToanThanToc.plusSolo = true;
                    },50);
                }
                if(ToanThanToc.MenuSingle.prototype.CheckForCheck())
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloPlus.frame=2;
                    ToanThanToc.plusSolo=true;
                }

            }else if(item.key=='btnMenuSoloMinus')
            {
                if(ToanThanToc.minusSolo)
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloMinus.frame=0;
                    ToanThanToc.minusSolo=false;
                }
                else{
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloMinus.frame=1;
                    setTimeout(function(){
                        ToanThanToc.MenuSingle.prototype.btnMenuSoloMinus.frame=2;
                        ToanThanToc.minusSolo=true;
                    },50);
                }
                if(ToanThanToc.MenuSingle.prototype.CheckForCheck())
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloMinus.frame=2;
                    ToanThanToc.minusSolo=true;
                }

            }else if(item.key=='btnMenuSoloMulti')
            {
                if(ToanThanToc.multiSolo)
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloMulti.frame=0;
                    ToanThanToc.multiSolo = false;
                }
                else
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloMulti.frame=1;
                    setTimeout(function(){
                        ToanThanToc.MenuSingle.prototype.btnMenuSoloMulti.frame=2;
                        ToanThanToc.multiSolo=true;
                    },50);
                }
                if(ToanThanToc.MenuSingle.prototype.CheckForCheck())
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloMulti.frame=2;
                    ToanThanToc.multiSolo=true;
                }
            }else if(item.key=='btnMenuSoloDivision')
            {
                if(ToanThanToc.divisionSolo)
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloDivision.frame=0;
                    ToanThanToc.divisionSolo=false;
                }else{
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloDivision.frame=1;
                    setTimeout(function(){
                        ToanThanToc.MenuSingle.prototype.btnMenuSoloDivision.frame=2;
                        ToanThanToc.divisionSolo=true;
                    },50);
                }
                if(ToanThanToc.MenuSingle.prototype.CheckForCheck())
                {
                    ToanThanToc.MenuSingle.prototype.btnMenuSoloDivision.frame=2;
                    ToanThanToc.divisionSolo=true;
                }
            }else if(item.key=='btnMenuSoloPlay')
            {
                ToanThanToc.MenuSingle.prototype.isNameClick='btnMenuSoloPlay';
                ToanThanToc.MenuSingle.prototype.SetConFixMath();
                ToanThanToc.MenuSingle.prototype.isPlaySingle=true;
            }else if(item.key=='btnHighScoreSG'){
                ToanThanToc.MenuSingle.prototype.isNameClick='btnHighScoreSG';
                ToanThanToc.MenuSingle.prototype.GetMyHighScores();
            }
            else if(item.key=='btnBackTT'){
                ToanThanToc.MenuSingle.prototype.isNameClick='btnBackTT';
                ToanThanToc.MenuSingle.prototype.isBackSingle=true;
            }
        }

    },

    SetConFixMath:function(){

        if (ToanThanToc.isLevelSolo.toUpperCase()== ToanThanToc.configMath[0].mode ) {
            ToanThanToc.MenuSingle.prototype.SetValueConfigMath(ToanThanToc.configMath[0]);
        } else if (ToanThanToc.isLevelSolo.toUpperCase()== ToanThanToc.configMath[1].mode) {
            ToanThanToc.MenuSingle.prototype.SetValueConfigMath(ToanThanToc.configMath[1]);
        } else if (ToanThanToc.isLevelSolo.toUpperCase()== ToanThanToc.configMath[2].mode) {
            ToanThanToc.MenuSingle.prototype.SetValueConfigMath(ToanThanToc.configMath[2]);
        }
    },

    SetValueConfigMath:function(value){
        ToanThanToc.MenuSingle.prototype.excellenceCombo=value.excellenceCombo;
        ToanThanToc.MenuSingle.prototype.excellenceQuestion=value.excellenceQuestion;
        ToanThanToc.MenuSingle.prototype.excellenceTime=value.excellenceTime;
        ToanThanToc.MenuSingle.prototype.expPerLevel=value.expPerLevel;
        ToanThanToc.MenuSingle.prototype.moneyPerLevel=value.moneyPerLevel;
        ToanThanToc.MenuSingle.prototype.timeBonus=value.timeBonus;
    },

    SetScorceTime : function(){
        ToanThanToc.numQuestion = ToanThanToc.soloPlayScore;
        ToanThanToc.numQuestion = ToanThanToc.numQuestion+1;
    },

    DeletePageMenuSingle : function(){
        var TT = ToanThanToc.MenuSingle.prototype;
        TT.btnMenuSoloEasy.destroy();
        TT.btnMenuSoloMedium.destroy();
        TT.btnMenuSoloHard.destroy();
        TT.btnMenuSoloPlus.destroy();
        TT.btnMenuSoloMinus.destroy();
        TT.btnMenuSoloMulti.destroy();
        TT.btnMenuSoloDivision.destroy();
        TT.btnMenuSoloPlay.destroy();
        TT.btnHighScoreSG.destroy();
        TT.logoNahi.destroy();
        TT.logoVNM.destroy();
    },

    GetMyHighScores:function(){
   /*     if(ToanThanToc.MyScores!='')
        {
            ToanThanToc.MenuSingle.prototype.isHighScores=true;
        }
        else*/
        {
            var postMyScores = ToanThanToc.db.query({api: '/math/myscore/', data:{},
                    headers : {'x-auth-token': ToanThanToc.MyToken}}
            );
            postMyScores.success(function(data){
               // log("callback called MyScores! " + JSON.stringify(data));
                ToanThanToc.MyScores=data;
                ToanThanToc.MenuSingle.prototype.isHighScores=true;
            });
            postMyScores.error(function(data){
                /*popup internet co van de */
                return false;
                //ToanThanToc.SinglePlay.prototype.CreatePopupEndGame();
            });
        }

    }
};