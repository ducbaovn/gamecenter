/* HO SY DAI
 *  daish@nahi.vn
 *  Create: 08/12/2014
 *  Project: Game Center
 *  Select.js
 * */
"use strict";

ToanThanToc.OnlineRoomChoose = function (_game) {

};
//that.prototype = Object.create(Phaser.State.prototype);
//constructor = that;
//-------------------------------------

ToanThanToc.OnlineRoomChoose.prototype = {
    bg_action: null,
    nahi_room: null,
    free_room: null,
    exit: null,
    listNahi: undefined,
    listFree: undefined,
    arrayButtonNahi:{},
    arrayButtonFree: {},
    keyboard: null,
    arrayCheckPass: [],
    create: function() {
        ToanThanToc.OnlineRoomWaiting.prototype.flagOnClick=1;
        ToanThanToc.dataAvatar=[];
        var that = ToanThanToc.OnlineRoomChoose.prototype;
        that.bg_action = ToanThanToc.game.add.sprite(0, 0, 'bg_action');
        that.bg_action.inputEnabled=true;

        that.nahi_room = ToanThanToc.game.add.button(182, 258, 'btn_nahi_room',
            that.actionOnClickNahiRoom, ToanThanToc.game, 1, 1, 1);
        that.free_room = ToanThanToc.game.add.button(396, 258, 'btn_free_room',
            that.actionOnClickFreeRoom, ToanThanToc.game, 0, 0, 0);
        that.nahi_room.setFrames(1, 1, 1);
        that.free_room.setFrames(0, 0, 0);
        that.exit = ToanThanToc.game.add.button(160.5, 1070, 'btn_exit',
            that.actionOnClickExit, ToanThanToc.game, 1, 0, 0);
        Socket.execute(function (socketRoomList) {
            //console.log(socketRoomList);
            socketRoomList.post(domainAPI + urlNahiRoom, {token: xAuthToken},
                that.actionDrawNahiRoom);
        });
    },

    preload: function(){
        if( ToanThanToc.game.cache.checkImageKey('bg_action') &&
            ToanThanToc.game.cache.checkImageKey('btn_nahi_room') &&
            ToanThanToc.game.cache.checkImageKey('btn_free_room') &&
            ToanThanToc.game.cache.checkImageKey('slide') &&
            ToanThanToc.game.cache.checkImageKey('lock') &&
            ToanThanToc.game.cache.checkImageKey('btn_go')){
            return;
        }
        ToanThanToc.game.load.spritesheet('bg_action', 'assets/online/selects/background.png',800,1232);
        ToanThanToc.game.load.spritesheet('btn_nahi_room', 'assets/online/selects/nahi_room.png', 215, 76);
        ToanThanToc.game.load.spritesheet('btn_free_room', 'assets/online/selects/free_room.png', 215, 76);
        ToanThanToc.game.load.spritesheet('slide', 'assets/online/selects/slide.png');
        ToanThanToc.game.load.spritesheet('lock', 'assets/online/selects/lock.png');
        ToanThanToc.game.load.spritesheet('btn_go', 'assets/online/selects/btn_go.png', 192, 66);


        ToanThanToc.OnlineRoomChoose.prototype.keyboard = new KeyboardLib(ToanThanToc.game);
        ToanThanToc.OnlineRoomChoose.prototype.keyboard.loadContent();
    },
    actionOnClickNahiRoom: function(){
        //console.log('nahi room');
        shareFunction.actionPlayAudio('touch');
        var that = ToanThanToc.OnlineRoomChoose.prototype;
        that.nahi_room.setFrames(1, 1, 1);
        that.free_room.setFrames(0, 0, 0);
        if(that.listFree != null){
            that.listFree.destroyList();
        }
        if(that.listNahi != null){
            that.listNahi.destroyList();
        }
        Socket.execute(function (socketRoomList) {
            socketRoomList.post(domainAPI + urlNahiRoom, {token: xAuthToken},
                that.actionDrawNahiRoom);
        });
    },
    actionOnClickFreeRoom: function(){
        //console.log('free room');
        console.log('action onclick freeRoom');
        shareFunction.actionPlayAudio('touch');
        var that = ToanThanToc.OnlineRoomChoose.prototype;
        that.free_room.setFrames(1, 1, 1);
        that.nahi_room.setFrames(0, 0, 0);
        if(that.listNahi != null){
            that.listNahi.destroyList();
        }
        if(that.listFree != null){
            that.listFree.destroyList();
        }
        Socket.execute(function (socketRoomList) {
            socketRoomList.post(domainAPI + urlFreeRoom, {token: xAuthToken,limit:100},
                that.actionDrawFreeRoom);
        });
    },

    actionOnClickExit: function(){
        shareFunction.actionPlayAudio('touch');
        var that = ToanThanToc.OnlineRoomChoose.prototype;
        if(that.listFree != null)
            that.listFree.destroyList();
        if(that.listNahi != null)
            that.listNahi.destroyList();
        //destroyArray([that.bg_action, that.nahi_room, that.free_room, that.exit]);
        //that.create();

        /* Open state menuOnline */
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("MenuOnline");
    },

    actionDrawNahiRoom: function(data){
        var that = ToanThanToc.OnlineRoomChoose.prototype;
        if(that.listNahi != null){
            that.listNahi.destroyList();
        }

        if(data.stateCode == 200) {
            that.drawListNAHI(data);
        }else{
            var p = new Popup();
            p.setMain(ToanThanToc.game,'Disconnect','','popup','popupClose',[{x:-150,y:20}],null,[]);
            p.setText([{x:0,y:-120}],['Mất kết nối'],[{fill:'#ffffff',font:'30px Segoe UI',align:'center'}]);
            p.createPopup(350,350);
            p.openWindow();
        }

    },
    drawListNAHI: function(data){
            var that = ToanThanToc.OnlineRoomChoose.prototype;
            var array_result = data.result;
            var arrayNahiRoom = {};
            if(array_result.length > 0){
                var arrayTemp = 0;
                for (var index = 0; index < array_result.length; index++) {
                    // Get mode game play of room.
                    var mode = '';
                    if(array_result[index].mode == 'EASY'){
                        mode = 'Khá';
                    }else if(array_result[index].mode == 'MEDIUM'){
                        mode = 'Giỏi';
                    }else{
                        mode = 'Xuất sắc';
                    }
                    arrayTemp = [
                        { // background.
                            xBuffer: 0,
                            yBuffer: 0,
                            name: (array_result[index].free == false ? 'item_room1' : 'item_room2'),
                            property: {},
                            type: 'image',
                            isShow: 1
                        },
                        { // Name
                            xBuffer: 165,
                            yBuffer: 45,
                            name: (array_result[index].name.length > 13 ? array_result[index]
                                .name.substr(0, 7) + '...' : array_result[index].name),
                            strokeThickness: 5,
                            anchor: 0.5,
                            shadow: '0|0|0|0',
                            property: {font: "bold 35px Segoe UI", fill: "#ffffff", align: "center"},
                            type: 'text',
                            isShow: 1
                        },
                        { // Time limit.
                            xBuffer: 85,
                            yBuffer: 105,
                            name: array_result[index].timeLimit + 's',
                            strokeThickness: 5,
                            anchor: 0,
                            shadow: '0|0|0|0',
                            property: {font: "bold 35px Segoe UI", fill: "#fff", align: "center"},
                            type: 'text',
                            isShow: 1
                        },
                        { // Team limit
                            xBuffer: 100,
                            yBuffer: 176,
                            name: array_result[index].teamLimit,
                            strokeThickness: 5,
                            anchor: 0.5,
                            shadow: '0|0|0|0',
                            property: {stroke: '#553727', font: "bold 35px Segoe UI", fill: "#ffffff"},
                            type: 'text',
                            isShow: 1
                        },
                        {  // mode of room play.
                            xBuffer: 500,
                            yBuffer: 120,
                            name: mode ,
                            strokeThickness: 5,
                            anchor: 0.5,
                            shadow: '0|0|0|0',
                            property: {stroke: '#553727', font: "bold 35px Segoe UI",
                                fill: "#ffffff",align: "center"},
                            type: 'text',
                            isShow: 1
                        },
                        { // money of room.
                            xBuffer: 270,
                            yBuffer: 120,
                            name: (array_result[index].starPerMember=='0')?'0':array_result[index].starPerMember,
                            strokeThickness: 5,
                            anchor: 0.5,
                            shadow: '0|0|0|0',
                            property: {font: "bold 35px Segoe UI", fill: "#ffffff", align: "center"},
                            type: 'text',
                            isShow: 1
                        },
                        {  // watch room button.
                            xBuffer: 420,
                            yBuffer: 15,
                            name: 'btn_go',
                            property: {type: 'nahi', id: "go_" + array_result[index].id, frame: [0, 0, 1]},
                            type: 'button',
                            isShow: 1
                        },
                        { // member of team.
                            xBuffer: 270,
                            yBuffer: 180,
                            name: array_result[index].memberPerTeam*array_result[index].teamLimit,
                            strokeThickness: 5,
                            anchor: 0.5,
                            shadow: '0|0|0|0',
                            property: {stroke: '#553727', font: "bold 35px Segoe UI",
                                fill: "#fff", align: "center"},
                            type: 'text',
                            isShow: 1
                        },
                        { // operation +
                            xBuffer: 430,
                            yBuffer: 165,
                            property: {},
                            name: 'btn_division',
                            frame:(array_result[index].operator.charAt(3) == '1') ?
                                '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                            type: 'image',
                            isShow: 1
                        },
                        { // operation -
                            xBuffer: 465,
                            yBuffer: 165,
                            property: {},
                            name: 'btn_addition',
                            frame:(array_result[index].operator.charAt(0) == '1') ?
                                '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                            type: 'image',
                            isShow: 1
                        },
                        { // operation *
                            xBuffer: 504,
                            yBuffer: 165,
                            property: {},
                            name: 'btn_subtraction',
                            frame:(array_result[index].operator.charAt(1) == '1') ?
                                '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                            type: 'image',
                            isShow: 1
                        },
                        { // operation /
                            xBuffer: 540,
                            yBuffer: 165,
                            property: {},
                            name: 'btn_multiplication',
                            frame:(array_result[index].operator.charAt(2) == '1') ?
                                '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                            type: 'image',
                            isShow: 1
                        }
                    ];
                    arrayNahiRoom[Object.keys(arrayNahiRoom).length] = arrayTemp;
                }
            }
            that.listNahi =
                new ListScroll(arrayNahiRoom, 88.5, 350, 610, 700, 240, 'chooseRoom',
                    that, that.arrayButtonNahi, 'bg_action');
            that.listNahi.makeList();
            that.listNahi.setOnTop([that.nahi_room, that.free_room, that.exit]);
    },

    onClick: function(){ // click watch room
        shareFunction.actionPlayAudio('touch');
        var self = ToanThanToc.OnlineRoomChoose.prototype;
        if(this.type == 'nahi'){
            for(var i = 0; i < Object.keys(self.arrayButtonNahi).length; i++) {
                var key = i + '|' + this.id;
                var id = this.id.split('_');
                id = id[1];
                if (self.arrayButtonNahi[key] != undefined) {
                    self.arrayButtonNahi[key].setFrames(1, 1, 0);
                    self.socketJoinRoom(id, null);
                }
            }
        }else{
            for(var i = 0; i < Object.keys(self.arrayButtonFree).length; i++) {
                var key = i + '|' + this.id;
                var id = this.id.split('_');
                id = id[1];
                if (self.arrayButtonFree[key] != undefined) {
                    self.arrayButtonFree[key].setFrames(1, 1, 0);
                    ToanThanToc.id = id;
                    if(self.hasPassword(id)){
                        self.keyboard.create(function(dataKey){

                            self.socketJoinRoom(id,dataKey);
                        });
                        if (self.keyboard != null
                            && !self.keyboard.groups.visible) {
                            self.keyboard.groups.visible = true;
                        }
                    }else{
                        self.socketJoinRoom(id,null);
                    }
                }
            }
        }
    },
    socketJoinRoom: function(id, pass){
        Socket.execute(function(socketRoom){
            var input = {};
            if(pass != null || pass != undefined){
                input = {token: xAuthToken, roomid: id, password: pass};
            }else{
                input = {token: xAuthToken, roomid: id, password: null};
            }
            ToanThanToc.data = {id: id, password: pass};

            socketRoom.post(domainAPI + urlWatchRoom, input, function(data){
                //console.log(data);
                if(data.stateCode == 200) {
                    //console.log('watch room '+JSON.stringify(data));
                }else{
                    var p = new Popup();
                    p.setMain(ToanThanToc.game,'Error Pass','','popup','popupClose',[{x:-150,y:20}],null,[]);
                    p.setText([{x:0,y:-100}],['Sai mật khẩu'],[{fill:'#ffffff',font:'30px Segoe UI',align:'center'}]);
                    p.createPopup(350,350);
                    p.openWindow();

                }
            });
        });
    },

    hasPassword: function(roomid){

        var that = ToanThanToc.OnlineRoomChoose.prototype;

        if(that.arrayCheckPass.indexOf(roomid) != -1)
            return true;
        else
            return false;
    },
    update: function() {
        if(ToanThanToc.OnlineRoomChoose.prototype.listNahi != undefined){
            ToanThanToc.OnlineRoomChoose.prototype.listNahi.update();
        }
        if(ToanThanToc.OnlineRoomChoose.prototype.listFree != undefined){
            ToanThanToc.OnlineRoomChoose.prototype.listFree.update();
        }
    },

    actionDrawFreeRoom: function(data){

        console.log('action draw freeroom');
        var that = ToanThanToc.OnlineRoomChoose.prototype;

        if(that.listFree != null){
            that.listFree.destroyList();
        }
        if(data.stateCode == 200) {
            var array_result = data.result;
            var arrayFreeRoom = {};
            if(array_result.length > 0){
                var arrayTemp = 0;
                for (var index = 0; index < array_result.length; index++) {
                    if(array_result[index].hasPassword){
                        that.arrayCheckPass.push(array_result[index].id);
                    }

                    // Get mode game play of room.
                    var mode = '';
                    if(array_result[index].mode == 'EASY'){
                        mode = 'Khá';
                    }else if(array_result[index].mode == 'MEDIUM'){
                        mode = 'Giỏi';
                    }else{
                        mode = 'Xuất sắc';
                    }
                    //console.log(array_result[index].name+'-'+array_result[index].name.length);
                    if(array_result[index].status != 'DISABLE'){
                        arrayTemp = [
                            { // background
                                xBuffer: 0,
                                yBuffer: 0,
                                name: (array_result[index].free ==
                                false ? 'item_room1' : 'item_room2'),
                                property: {},
                                type: 'image',
                                isShow: 1
                            },
                            { // lock
                                xBuffer: -10,
                                yBuffer: 20,
                                name:(array_result[index].hasPassword)?'lock':'slide',
                                property: {},
                                type: 'image',
                                isShow: 1
                            },
                            { // name
                                xBuffer: 170,
                                yBuffer: 45,
                                name: (array_result[index].name.length > 13 ? array_result[index]
                                    .name.substr(0, 7) + '...' : array_result[index].name),
                                strokeThickness: 5,
                                anchor: 0.5,
                                shadow: '0|0|0|0',
                                property: {font: "bold 35px Segoe UI", fill: "#ffffff", align: "center"},
                                type: 'text',
                                isShow: 1
                            },
                            { // Time limit.
                                xBuffer: 85,
                                yBuffer: 105,
                                name: array_result[index].timeLimit + 's',
                                strokeThickness: 5,
                                anchor: 0,
                                shadow: '0|0|0|0',
                                property: {font: "bold 35px Segoe UI", fill: "#fff", align: "center"},
                                type: 'text',
                                isShow: 1
                            },
                            { // Team limit
                                xBuffer: 100,
                                yBuffer: 180,
                                name: array_result[index].teamLimit,
                                strokeThickness: 5,
                                anchor: 0.5,
                                shadow: '0|0|0|0',
                                property: {stroke: '#553727', font: "bold 35px Segoe UI", fill: "#ffffff"},
                                type: 'text',
                                isShow: 1
                            },
                            { // mode room
                                xBuffer: 500,
                                yBuffer: 120,
                                name: mode,
                                strokeThickness: 5,
                                anchor: 0.5,
                                shadow: '0|0|0|0',
                                property: {stroke: '#553727', font: "bold 35px Segoe UI", fill: "#ffffff",align: "center"},
                                type: 'text',
                                isShow: 1
                            },
                            {
                                xBuffer: 270,
                                yBuffer: 120,
                                name: (array_result[index].starPerMember=='0')?'0':array_result[index].starPerMember,
                                strokeThickness: 5,
                                anchor: 0.5,
                                shadow: '0|0|0|0',
                                property: {font: "bold 35px Segoe UI", fill: "#ffffff", align: "center"},
                                type: 'text',
                                isShow: 1
                            },
                            {
                                xBuffer: 420,
                                yBuffer: 15,
                                name: 'btn_go',
                                fontSize: 30,
                                property: {type: 'free', id: "go_" + array_result[index].id, frame: [0, 0, 1]},
                                type: 'button',
                                isShow: 1
                            },
                            { // member of team.
                                xBuffer: 270,
                                yBuffer: 182,
                                name: array_result[index].memberPerTeam*array_result[index].teamLimit,
                                strokeThickness: 5,
                                anchor: 0.5,
                                shadow: '0|0|0|0',
                                property: {stroke: '#553727', font: "bold 35px Segoe UI",
                                    fill: "#fff", align: "center"},
                                type: 'text',
                                isShow: 1
                            },
                            { // operation +
                                xBuffer: 430,
                                yBuffer: 165,
                                property: {},
                                name: 'btn_division',
                                frame:(array_result[index].operator.charAt(3) == '1') ?
                                    '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                                type: 'image',
                                isShow: 1
                            },
                            { // operation -
                                xBuffer: 465,
                                yBuffer: 165,
                                property: {},
                                name: 'btn_addition',
                                frame:(array_result[index].operator.charAt(0) == '1') ?
                                    '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                                type: 'image',
                                isShow: 1
                            },
                            { // operation *
                                xBuffer: 504,
                                yBuffer: 165,
                                property: {},
                                name: 'btn_subtraction',
                                frame:(array_result[index].operator.charAt(1) == '1') ?
                                    '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                                type: 'image',
                                isShow: 1
                            },
                            { // operation /
                                xBuffer: 540,
                                yBuffer: 165,
                                property: {},
                                name: 'btn_multiplication',
                                frame:(array_result[index].operator.charAt(2) == '1') ?
                                    '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                                type: 'image',
                                isShow: 1
                            }

                        ];

                        arrayFreeRoom[Object.keys(arrayFreeRoom).length] = arrayTemp;
                    }

                }
            }
            that.listFree = new ListScroll(arrayFreeRoom, 88.5, 330, 610, 740, 240,
                'chooseRoom', that, that.arrayButtonFree, 'bg_action');
            that.listFree.makeList();
            that.listFree.setOnTop([that.nahi_room,
                that.free_room, that.exit]);
        }else{
            var p = new Popup();
            p.setMain(ToanThanToc.game,'Disconnect','','popup','popupClose',[{x:-150,y:20}],null,[]);
            p.setText([{x:0,y:-120}],['Mất kết nối'],[{fill:'#ffffff',font:'30px Segoe UI',align:'center'}]);
            p.createPopup(350,350);
            p.openWindow();
        }
    },

    /**
     * Destroy select.
     */
    destroy: function(){
        this.bg_action = null;
        this.nahi_room = null;
        this.free_room = null;
        this.exit = null;
        this.listNahi = undefined;
        this.listFree = undefined;
        this.arrayButtonNahi = null;
        this.arrayButtonFree = null;
        this.keyboard = null;
        this.arrayCheckPass = null;
    }

};



