/* ThanhPT from NAHI ---
 * @dateCreate 22/12/2014
 * @author tpt2213
 * */
"use strict";

ToanThanToc.FlasIntro = function (game) {

};

ToanThanToc.FlasIntro.prototype = {
    preload : function() {
        ToanThanToc.game.input.maxPointers = 0;
        //*   Phan FlasIntro    *//*
    },
    PlayVideo:function(){
        var that = this;
        //*   Phan FlasIntro    *//*
        ToanThanToc.timer_Background = ToanThanToc.game.time.create(true);
        ToanThanToc.timer_Background.add(Phaser.Timer.SECOND*0.8, ToanThanToc.FlasIntro.prototype.FadeBackgound, ToanThanToc.game);
        ToanThanToc.timer_Background.start();
         /* ToanThanToc.FlasIntro.prototype.VideoInro();
        setTimeout(function(){
            ToanThanToc.video.muted = false;
            $('#video-bg').css({'z-index':'2000'});
            ToanThanToc.video.play();
        },30);*/
    },
    create : function() {
        ToanThanToc.FlasIntro.prototype.PlayVideo();

        /*  login */
        ////handle check token
        localData.set('gamelanding','boot');
        var localStorage = localData.get('Account');
        if(localStorage==null){
            console.log('localdata null');
            window.location.href = 'chat.html';
        }else{
            var dateLogin = new Date(localData.get('Account').tokenExpireAt);
            var dateNow = new Date();
            if(dateNow > dateLogin){
                localData.removeItem('Account');
                localData.removeItem('gamelanding');
                log('localdata null');
                window.location.href = 'chat.html';
            }
            else{
                xAuthToken = localStorage.token;
                ToanThanToc.MyToken = localStorage.token;
                localData.set('gamelanding','toanthantoc');
            }
        }

    },
    isCompleteVideo:false,
    update:function(){
        if(ToanThanToc.FlasIntro.prototype.isCompleteVideo)
        {
            ToanThanToc.FlasIntro.prototype.isCompleteVideo=false;
          /*  ToanThanToc.video.pause();
            $('#video-bg').css({'z-index':'-1'});
            $('#video-bg').html('');
            delete(ToanThanToc.video);*/
            ToanThanToc.timer_Background.stop();
            SetCssBody('url(assets/solo/background/background.png) no-repeat center center fixed');

            /*Position home chat button*/
            //$("#homeVirtual").css({'top':$("#gameMath canvas").height()/3 ,'left':$("#gameMath canvas").width() - $("#homeVirtual").width() });

            if(ToanThanToc.innerWidth>ToanThanToc.innerHeight || ToanThanToc.innerWidth==ToanThanToc.innerHeight )
            {
                ToanThanToc.game.canvas.style.marginLeft=(ToanThanToc.innerWidth/2 - parseInt($("#gameMath canvas").css("width").replace('px',''))/2)+'px';
                setTimeout(function(){
                    ToanThanToc.game.stage.destroy();
                    ToanThanToc.game.state.start("Menu");
                },80);
            }
            else
            {
                log('the veu nao'+((ToanThanToc.heighPerFect==0)?0:ToanThanToc.heighPerFect/2).toString());
                ToanThanToc.game.canvas.style.marginTop=((ToanThanToc.heighPerFect==0)?0:ToanThanToc.heighPerFect/2) +'px';
                //alert(ToanThanToc.heighPerFect/2 -3);
                if(parseInt($("#gameMath canvas").css("height").replace('px',''))==ToanThanToc.innerHeight)
                {
                    ToanThanToc.game.canvas.style.marginTop = '0px';
                    ToanThanToc.heighPerFect=0;
                }
                ToanThanToc.game.canvas.style.width= ToanThanToc.innerWidth+'px';
                setTimeout(function(){
                    ToanThanToc.game.stage.destroy();
                    ToanThanToc.game.state.start("Menu");
                },80);
            }
        }
    },
    VideoInro : function() {
        var that = this;
        $('#video-bg').ready(
            $('#video-bg').click(function(){
                ToanThanToc.FlasIntro.prototype.isCompleteVideo=true;
            })
        );
    },
    FadeBackgound:function() {
        ToanThanToc.FlasIntro.prototype.isCompleteVideo=true;
    }
};