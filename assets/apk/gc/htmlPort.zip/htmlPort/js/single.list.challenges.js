/**
 * Created by thanhpt on 1/31/2015.
 */
ToanThanToc.SingleListChallenges = function (_game) {

};
//that.prototype = Object.create(Phaser.State.prototype);
//constructor = that;
//-------------------------------------

ToanThanToc.SingleListChallenges.prototype = {
    bg_action: null,
    players_menu: null,
    your_menu: null,

    playersList: undefined,
    yourList: undefined,
    arrayPlayersButton:{},
    arrayYourButton: {},

    preload: function(){
        ToanThanToc.popupShow=0;
        ToanThanToc.SingleListChallenges.prototype.isNameClick=null;
        if( ToanThanToc.game.cache.checkImageKey('bgActionSingleList') &&
            ToanThanToc.game.cache.checkImageKey('btnPlayersMenuSLChall') &&
            ToanThanToc.game.cache.checkImageKey('btnYourMenuSLChall') &&
            ToanThanToc.game.cache.checkImageKey('btnGoSLChall')){
            return false;
        }
        ToanThanToc.game.load.spritesheet('bgActionSingleList', 'assets/single/list-challenges/bg.png',800,1232);
        ToanThanToc.game.load.spritesheet('btnPlayersMenuSLChall', 'assets/single/list-challenges/players_menu.png', 218, 75);
        ToanThanToc.game.load.spritesheet('btnYourMenuSLChall', 'assets/single/list-challenges/your_menu.png', 218, 75);
        ToanThanToc.game.load.spritesheet('itemMiddlingSLChall', 'assets/single/list-challenges/item-middling.png');
        ToanThanToc.game.load.spritesheet('itemGoodSLChall', 'assets/single/list-challenges/item-good.png');
        ToanThanToc.game.load.spritesheet('itemExcellentSLChall', 'assets/single/list-challenges/item-excellent.png');
        ToanThanToc.game.load.spritesheet('radioFriendSLChall', 'assets/single/list-challenges/radio-friend.png', 151, 52);
        ToanThanToc.game.load.spritesheet('radioWorldSLChall', 'assets/single/list-challenges/radio-world.png', 165, 52);
        ToanThanToc.game.load.spritesheet('btnGoSLChall', 'assets/single/list-challenges/btn_go.png', 166, 59);
        ToanThanToc.game.load.spritesheet('btnRemoveSLChall', 'assets/single/list-challenges/btn_remove.png', 67, 71);

        ToanThanToc.game.load.spritesheet('otherChallengeEasy', 'assets/single/list-challenges/other-challenge-easy.png', 678, 316);
        ToanThanToc.game.load.spritesheet('otherChallengeHard', 'assets/single/list-challenges/other-challenge-hard.png',678, 316);
        ToanThanToc.game.load.spritesheet('otherChallengeMedium', 'assets/single/list-challenges/other-challenge-medium.png', 678, 316);


        ToanThanToc.game.load.spritesheet('popupDelChall', 'assets/single/popup/popup-del-chall.png', 548, 343);
        ToanThanToc.game.load.spritesheet('popupThamgia', 'assets/single/popup/popup-thamgia.png', 548, 343);

        ToanThanToc.game.load.spritesheet('btnExitPPSGCh', 'assets/single/popup/btn-exit.png', 135, 91);
        ToanThanToc.game.load.spritesheet('btnBackPPSGCh', 'assets/single/popup/btn-back.png', 135, 91);
        ToanThanToc.game.load.spritesheet('btnTryPPSGCh', 'assets/single/popup/btn-try.png', 135, 93);
        ToanThanToc.game.load.spritesheet('bgWinnerChall', 'assets/single/popup/popup-winner-Cha.png', 571, 548);
        ToanThanToc.game.load.spritesheet('bgLoserPPSGCh', 'assets/single/popup/popup-loser-cha.png', 567, 551);


    },

    create: function() {
        var parent = ToanThanToc.SingleListChallenges.prototype;
        parent.bg_action = ToanThanToc.game.add.sprite(0, 0, 'bgActionSingleList');

        parent.players_menu = ToanThanToc.game.add.button(
            ToanThanToc.game.world.centerX-217, 200, 'btnPlayersMenuSLChall', parent.actionOnClickPlayers, ToanThanToc.game);
        parent.your_menu = ToanThanToc.game.add.button(
            ToanThanToc.game.world.centerX, 200, 'btnYourMenuSLChall', parent.actionOnClickYours, ToanThanToc.game);
        parent.btnMenuSoloBackTT = ToanThanToc.game.add.button(17,35,'btnBackTT',this.ActionClickBack,ToanThanToc.game,1,1,0);

        parent.actionDrawYour(ToanThanToc.YourChall);

        parent.btnMenuSoloBackTT = ToanThanToc.game.add.button(17,35,'btnBackTT',this.ActionClickBack,ToanThanToc.game,1,1,0);
        parent.your_menu.frame = 0;
        parent.players_menu.frame = 1;
        parent.players_menu.bringToTop();
        parent.your_menu.bringToTop();
    },

    update: function() {

        if(ToanThanToc.SingleListChallenges.prototype.playersList != undefined && ToanThanToc.nameSpace == 'SingleListChallengesPlayers'){
            ToanThanToc.SingleListChallenges.prototype.playersList.update();
        }
        if(ToanThanToc.SingleListChallenges.prototype.yourList != undefined && ToanThanToc.nameSpace == 'SingleListChallengesYour'){
            ToanThanToc.SingleListChallenges.prototype.yourList.update();
        }
    },

    CreatePopupDelChall:function(){
        var ttt = ToanThanToc.SingleListChallenges.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgPPDelChConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');
        ttt.bgPPDelChConfirm.inputEnabled=true;
        ttt.bgPPDelChConfirm.events.onInputDown.add(ttt.ClickOutDelChall);

        ttt.bgPPxacnhanDelCh=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-548/2,ToanThanToc.game.world.centerY-343/2,'popupDelChall');

        ttt.btnConfirmDelCh=ToanThanToc.game.add.button(290,200,'btnOkPPC',null,ToanThanToc.game,0,0,1);
        ttt.btnConfirmDelCh.key='btnOkDelCh';
        ttt.btnConfirmDelCh.events.onInputDown.add(ttt.ActionClickListChall);

        ttt.btnDeleteDelCh=ToanThanToc.game.add.button(120,200,'btnDeletePPC',null,ToanThanToc.game,0,0,1);
        ttt.btnDeleteDelCh.key='btnDeleteDelCh';
        ttt.btnDeleteDelCh.events.onInputDown.add(ttt.ClickOutDelChall);

        ttt.bgPPxacnhanDelCh.addChild(ttt.btnConfirmDelCh);
        ttt.bgPPxacnhanDelCh.addChild(ttt.btnDeleteDelCh);
        ttt.isNameClick = null;
    },

    CreatePopupJoinChall:function(){
        var ttt = ToanThanToc.SingleListChallenges.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgPPJointConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');
        ttt.bgPPJointConfirm.inputEnabled=true;
        ttt.bgPPJointConfirm.events.onInputDown.add(ttt.ClickOutDelJoint);

        ttt.bgPPxacnhanJointCh=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-548/2,ToanThanToc.game.world.centerY-343/2,'popupThamgia');
        ttt.btnConfirmJointCh=ToanThanToc.game.add.button(290,200,'btnOkPPC',null,ToanThanToc.game,0,0,1);
        ttt.btnConfirmJointCh.key='btnOkJoint';
        ttt.btnConfirmJointCh.events.onInputDown.add(ttt.ActionClickListChall);

        ttt.btnDeleteJointCh=ToanThanToc.game.add.button(120,200,'btnDeletePPC',null,ToanThanToc.game,0,0,1);
        ttt.btnDeleteJointCh.key='btnDeleteJoint';
        ttt.btnDeleteJointCh.events.onInputDown.add(ttt.ClickOutDelJoint);

        ttt.bgPPxacnhanJointCh.addChild( ttt.btnConfirmJointCh);
        ttt.bgPPxacnhanJointCh.addChild( ttt.btnDeleteJointCh);
        ttt.isNameClick = null;
    },

    actionOnClickPlayers: function(){
        var parent = ToanThanToc.SingleListChallenges.prototype;
        if( parent.players_menu.frame==1)
        {
            shareFunction.actionPlayAudio('touch');
            if(parent.yourList != null){
                parent.yourList.destroyList();
            }
            if(parent.playersList != null){
                parent.playersList.destroyList();
            }

            parent.actionDrawPlayers(ToanThanToc.PlayerChall);

            parent.players_menu.frame=0;
            parent.your_menu.frame=1;
            parent.players_menu.bringToTop();
            parent.your_menu.bringToTop();
            parent.btnMenuSoloBackTT.bringToTop();
        }
    },

    actionOnClickYours: function(){
        var parent = ToanThanToc.SingleListChallenges.prototype;
        if( parent.your_menu.frame==1) {
            shareFunction.actionPlayAudio('touch');
            if (parent.playersList != null) {
                parent.playersList.destroyList();
            }
            if (parent.yourList != null) {
                parent.yourList.destroyList();
            }
            parent.actionDrawYour(ToanThanToc.YourChall);

            parent.your_menu.frame =0;
            parent.players_menu.frame =  1;
            parent.players_menu.bringToTop();
            parent.your_menu.bringToTop();
            parent.btnMenuSoloBackTT.bringToTop();
        }
    },

    actionDrawPlayers: function(data){
        var parent = ToanThanToc.SingleListChallenges.prototype;
        if(parent.playersList != null){
            parent.playersList.destroyList();
        }
        var array_result = data;
        var arrayPlayersData = {};
        if(array_result.length > 0){
            var arrayTemp = 0;
            for (var index = 0; index < array_result.length; index++) {
                // Get mode game play of room.
                arrayTemp = [
                    { // background.
                        xBuffer: 0,
                        yBuffer: 0,
                        name: (array_result[index].mode == 'EASY' ? 'otherChallengeEasy' : (array_result[index].mode == 'MEDIUM' ? 'otherChallengeMedium':'otherChallengeHard')),
                        property: {},
                        type: 'image',
                        isShow: 1
                    },
                    { // Time
                        xBuffer: 180,
                        yBuffer: 147,
                        name: ToanThanToc.SoloPlay.prototype.ShowTimeTo(array_result[index].time/1000),
                        strokeThickness: 5,
                        anchor: 0.5,
                        shadow: '0|0|0|0',
                        property: {font: "bold 35px Segoe UI", fill: "#ffffff", align: "center"},
                        type: 'text',
                        isShow: 1
                    },
                    { // Money
                        xBuffer: 160,
                        yBuffer: 195,
                        name: array_result[index].moneyPerOne,
                        strokeThickness: 5,
                        anchor: 0,
                        shadow: '0|0|0|0',
                        property: {font: "bold 35px Segoe UI", fill: "#fff", align: "center"},
                        type: 'text',
                        isShow: 1
                    },
                    { // remainingTimes
                        xBuffer: 220,
                        yBuffer: 270,
                        name: array_result[index].remainingTimes,
                        strokeThickness: 5,
                        anchor: 0.5,
                        shadow: '0|0|0|0',
                        property: {stroke: '#553727', font: "bold 35px Segoe UI", fill: "#ffffff"},
                        type: 'text',
                        isShow: 1
                    },
                    { // Full name
                        xBuffer: 135,
                        yBuffer: 44,
                        name: FixFullName(array_result[index].user.fullname),
                        strokeThickness: 5,
                        anchor: 0,
                        shadow: '0|0|0|0',
                        property: {stroke: '#553727', font: "bold 35px Segoe UI", fill: "#ffffff"},
                        type: 'text',
                        isShow: 1
                    },
                    {  // Finish
                        xBuffer: 495,
                        yBuffer: 210,
                        name:formatDate(array_result[index].expiredAt) ,
                        strokeThickness: 5,
                        anchor: 0.5,
                        shadow: '0|0|0|0',
                        property: {stroke: '#553727', font: "bold 35px Segoe UI",
                            fill: "#ffffff",align: "center"},
                        type: 'text',
                        isShow: 1
                    },
                    {  //Radio button friend
                        xBuffer: 310,
                        yBuffer: 240,
                        name: 'radioFriendSLChall',
                        property: {type: 'radioFriendSLChall', id: "friendradio_" + array_result[index].id, frame:
                            (array_result[index].target=="FRIEND")?1 :0},
                        type: 'spriteImage',
                        isShow: 1
                    },
                    {  //Radio button world
                        xBuffer: 465,
                        yBuffer: 240,
                        name: 'radioWorldSLChall',
                        property: {type: 'radioWorldSLChall', id: "worldradio_" + array_result[index].id, frame:
                            (array_result[index].target=="GLOBAL")?1 :0},
                        type: 'spriteImage',
                        isShow: 1
                    },
                    {  //Button Go
                        xBuffer: 480,
                        yBuffer: 30,
                        name: 'btnGoSLChall',
                        property:(ToanThanToc.infoUserMath.starMoney>= array_result[index].moneyPerOne)? {type: 'goChall', id: "goChall_" + array_result[index].id, frame: [0, 0, 1]}:{frame:1},
                        type:(ToanThanToc.infoUserMath.starMoney>= array_result[index].moneyPerOne)? 'button':'spriteImage',
                        isShow: 1
                    }

                ];
                arrayTemp.push(
                    { // operation +
                        xBuffer: 490,
                        yBuffer: 100,
                        property: {},
                        name: 'btn_division',
                        frame:(array_result[index].operator.charAt(3) == '1') ?
                            '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                        type: 'image',
                        isShow: 1
                    },
                    { // operation -
                        xBuffer: 530,
                        yBuffer: 100,
                        property: {},
                        name: 'btn_addition',
                        frame:(array_result[index].operator.charAt(0) == '1') ?
                            '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                        type: 'image',
                        isShow: 1
                    },
                    { // operation *
                        xBuffer: 570,
                        yBuffer: 100,
                        property: {},
                        name: 'btn_subtraction',
                        frame:(array_result[index].operator.charAt(1) == '1') ?
                            '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                        type: 'image',
                        isShow: 1
                    },
                    { // operation /
                        xBuffer: 610,
                        yBuffer: 100,
                        property: {},
                        name: 'btn_multiplication',
                        frame:(array_result[index].operator.charAt(2) == '1') ?
                            '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                        type: 'image',
                        isShow: 1
                    }

                );
                arrayPlayersData[Object.keys(arrayPlayersData).length] = arrayTemp;
            }
        }
        parent.playersList = new ListScroll(arrayPlayersData, 60, 300, 610, 900, 310, 'SingleListChallengesPlayers', parent, parent.arrayPlayersButton, 'bgActionSingleList');
        parent.playersList.makeList();
    },

    actionDrawYour: function(data){
        var parent = ToanThanToc.SingleListChallenges.prototype;
        if(parent.yourList != null){
            parent.yourList.destroyList();
        }
        var array_result = data;
        var arrayPlayersData = {};
        if(array_result.length > 0){
            var arrayTemp = 0;
            for (var index = 0; index < array_result.length; index++) {
                // Get mode game play of room.
                arrayTemp = [
                    { // background.
                        xBuffer: 0,
                        yBuffer: 0,
                        name: (array_result[index].mode == 'EASY' ? 'itemMiddlingSLChall' : (array_result[index].mode == 'MEDIUM' ? 'itemGoodSLChall':'itemExcellentSLChall')),
                        property: {},
                        type: 'image',
                        isShow: 1
                    },
                    { // Time
                        xBuffer: 160,
                        yBuffer: 147,
                        name: ToanThanToc.SoloPlay.prototype.ShowTimeTo(array_result[index].time/1000),
                        strokeThickness: 5,
                        anchor: 0.5,
                        shadow: '0|0|0|0',
                        property: {font: "bold 35px Segoe UI", fill: "#ffffff", align: "center"},
                        type: 'text',
                        isShow: 1
                    },
                    { // Money
                        xBuffer: 140,
                        yBuffer: 195,
                        name: array_result[index].moneyPerOne,
                        strokeThickness: 5,
                        anchor: 0,
                        shadow: '0|0|0|0',
                        property: {font: "bold 35px Segoe UI", fill: "#fff", align: "center"},
                        type: 'text',
                        isShow: 1
                    },
                    { // remainingTimes
                        xBuffer: 200,
                        yBuffer: 270,
                        name: array_result[index].availTimes.toString(),
                        strokeThickness: 5,
                        anchor: 0.5,
                        shadow: '0|0|0|0',
                        property: {stroke: '#553727', font: "bold 35px Segoe UI", fill: "#ffffff"},
                        type: 'text',
                        isShow: 1
                    },
                    {  // Finish
                        xBuffer: 470,
                        yBuffer: 210,
                        name: formatDate(array_result[index].expiredAt) ,
                        strokeThickness: 5,
                        anchor: 0.5,
                        shadow: '0|0|0|0',
                        property: {stroke: '#553727', font: "bold 35px Segoe UI",
                            fill: "#ffffff",align: "center"},
                        type: 'text',
                        isShow: 1
                    },
                    {  //Radio button friend
                        xBuffer: 310,
                        yBuffer: 240,
                        name: 'radioFriendSLChall',
                        property: {type: 'radioFriendSLChall', id: "friendradio_" + array_result[index].id, frame:
                            (array_result[index].target=="FRIEND")? 1:0},
                        type: 'spriteImage',
                        isShow: 1
                    },
                    {  //Radio button world
                        xBuffer: 465,
                        yBuffer: 240,
                        name: 'radioWorldSLChall',
                        property: {type: 'radioWorldSLChall', id: "worldradio_" + array_result[index].id, frame:
                            (array_result[index].target=="GLOBAL")?1 :0},
                        type: 'spriteImage',
                        isShow: 1
                    },
                    {  //Button Remove
                        xBuffer: 600,
                        yBuffer: 45,
                        name: 'btnRemoveSLChall',
                        property: (array_result[index].isHolding==false)?{type: 'btnRemoveChall', id: "btnRemoveChall_" + array_result[index].id, frame: [0, 0, 1]}: {frame:1},
                        type:(array_result[index].isHolding==false)? 'button':'spriteImage',
                        isShow: 1
                    }

                ];
                arrayPlayersData[Object.keys(arrayPlayersData).length] = arrayTemp;
            }
        }
        parent.yourList = new ListScroll(arrayPlayersData, 75, 300, 610, 900, 310, 'SingleListChallengesYour', parent, parent.arrayYourButton, 'bgActionSingleList');
        parent.yourList.makeList();
    },

    ActionClickBack:function(){
        var ttt = ToanThanToc.SingleListChallenges.prototype;
        shareFunction.actionPlayAudio('touch');
        if(ttt.isNameClick==null)
        {
            ttt.isNameClick = 'btnBackTT';
            ttt.destroy();
            ToanThanToc.game.stage.destroy();
            ToanThanToc.game.state.start('HighScoresSingle');
            ttt.isNameClick = null;
        }
    },

    ActionClickListChall:function(item){
        var ttt = ToanThanToc.SingleListChallenges.prototype;
        shareFunction.actionPlayAudio('right');
        if(ttt.isNameClick==null){
            if(item.key=='btnOkDelCh'){
                ttt.isNameClick='btnOkDelCh';
                DelYourChall(function(data){
                 if(data=='erro') return false;
                     GetListMyChall(function(data){
                         if(data=='erro') return false;
                         if (ttt.playersList != null) {
                             ttt.playersList.destroyList();
                         }
                         if (ttt.yourList != null) {
                             ttt.yourList.destroyList();
                         }
                         ttt.actionDrawYour(ToanThanToc.YourChall);
                         ttt.players_menu.bringToTop();
                         ttt.your_menu.bringToTop();
                         ttt.btnMenuSoloBackTT.bringToTop();
                     });
                 },ttt.idChall );
                ttt.ClickOutDelChall();
            }
            else if(item.key=='btnOkJoint'){
                ttt.isNameClick = 'btnOkJoint';
                SetCssBody('url(assets/single/background/bg.png) no-repeat center center fixed');
                ttt.destroy();
                ToanThanToc.JointPlayChall=true;
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('SinglePlay');
                ttt.isNameClick = null;
            }
        }
    },
    idChall:null,

    onClick: function(){ // click watch room
        var self = ToanThanToc.SingleListChallenges.prototype;
        if(self.isNameClick==null){
            if(this.type == 'goChall'){
                self.isNameClick='goChallenges';
                shareFunction.actionPlayAudio('touch');
                for(var i = 0; i < Object.keys(self.arrayPlayersButton).length; i++) {
                    var key = i + '|' + this.id;
                    var id = this.id.split('_');
                    id = id[1];
                    if (self.arrayPlayersButton[key] != undefined) {
                        ToanThanToc.challengeid=id;
                        ToanThanToc.isLevelSolo=ToanThanToc.PlayerChall[i].mode;
                        ToanThanToc.challengeIndex=i;
                        self.CreatePopupJoinChall();
                        self.isNameClick=null;
                    }
                }
            }else if(this.type =='btnRemoveChall'){
                self.isNameClick='DelChallenges';
                shareFunction.actionPlayAudio('touch');
                for(var i = 0; i < Object.keys(self.arrayYourButton).length; i++) {
                    var key = i + '|' + this.id;
                    var id = this.id.split('_');
                    id = id[1];
                    if (self.arrayYourButton[key] != undefined) {
                        self.idChall = id;
                        self.CreatePopupDelChall();
                        return false;
                    }
                }
            }
        }
    },

    ClickOutDelChall:function(){
        shareFunction.actionPlayAudio('right');
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        var ttt =ToanThanToc.SingleListChallenges.prototype;
        ttt.bgPPDelChConfirm.destroy();
        setTimeout(function(){
            ttt.bgPPxacnhanDelCh.destroy();
            ttt.isNameClick = null;
        },50);
    },
    ClickOutDelJoint:function(){
        shareFunction.actionPlayAudio('right');
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        var ttt =ToanThanToc.SingleListChallenges.prototype;
        ttt.bgPPJointConfirm.destroy();
        setTimeout(function(){
            ttt.bgPPxacnhanJointCh.destroy();
            ttt.isNameClick = null;
        },50);
    },

    /**
     * Destroy select.
     */
    destroy: function(){
        var ttt = ToanThanToc.SingleListChallenges.prototype;
        setTimeout(function(){
            ttt.bg_action.destroy();
            ttt.players_menu.destroy();
            ttt.your_menu.destroy();
            ttt.btnMenuSoloBackTT.destroy();
            if(ttt.playersList != null){
                ttt.playersList.destroyList();
            }
            if(ttt.yourList != null){
                ttt.yourList.destroyList();
            }
            ttt.arrayPlayersButton=[];
            ttt.arrayYourButton = [];
        },50);
    }

};
function formatDate(date)
{
    var value =  new Date(date) ;
    return ((value.getHours().toString().length==1)?'0'+value.getHours().toString():value.getHours().toString())
        +':'+
        ((value.getMinutes().toString().length==1)?'0'+value.getMinutes().toString():value.getMinutes().toString())
        + ':'+
        ((value.getSeconds().toString().length==1)?'0'+value.getSeconds().toString():value.getSeconds().toString())
        +' '+
        ((value.getDate().toString().length==1)?'0'+value.getDate().toString():value.getDate().toString())
        + "-" +
        ((value.getMonth().toString().length==1)?'0'+value.getMonth().toString():value.getMonth().toString())
        + "-" +
        ((value.getFullYear().toString().length==1)?'0'+value.getFullYear().toString():value.getFullYear().toString())
        ;
}

function DelYourChall(callback,id)
{
    ToanThanToc.db.setAtuthToken(ToanThanToc.MyToken);
    var  postDelMyScores = ToanThanToc.db.query({api: '/math/stopchallenge/', data:{id:id},
            headers : {'x-auth-token': ToanThanToc.MyToken}}
    );
    postDelMyScores.success(function(data){

        callback(data);
    });
    postDelMyScores.error(function(data){
        callback('erro');
    });
}

function FixFullName(text){
    var te = text.toString().trim();
    if(te.length>=13)
    {
        te =  te.substr(0,11)+'...';
    }
  return te;
}