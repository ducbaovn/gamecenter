/**
 * @author       Roca Chien <chienvd@nahi.vn>
 * @copyright    2014 NAHI JSC.
 * @license      {@link http://www.nahi.vn/vn/gioi-thieu-ve-nahi.html}
 */

/**
 * This is the Error control.
 *
 * @class Error
 * @constructor
 * @param {object} [config=null] - The default config object or null.
 */

ToanThanToc.Error = {
    author: function (){
        log("================== SmartPlus.Error.API Math ======================");
        /* Call back GameCenter API ERR */
        localData.removeItem('Account');
        localData.removeItem('gamelanding');
        log('localdata null');
        window.location.href = 'chat.html';
        return false;
    }

};