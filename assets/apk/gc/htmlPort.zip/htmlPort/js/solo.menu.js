/* ThanhPT from NAHI ---
 * @dateCreate 22/12/2014
 * @author tpt2213
 * */
"use strict";

ToanThanToc.MenuSolo = function (game) {
};

ToanThanToc.MenuSolo.prototype = {
    btnMenuSoloPlay:null,
    btnMenuSoloDivision:null,
    btnMenuSoloMinus:null,
    btnMenuSoloMulti:null,
    btnMenuSoloPlus:null,

    btnMenuSoloEasy:null,
    btnMenuSoloMedium:null,
    btnMenuSoloHard:null,

    isLevl:null,
    isPlayingSoLo:false,
    isBackPlaySolo:false,
    preload : function() {
        ToanThanToc.SoloPlay.prototype.isNameClick=null;
        ToanThanToc.popupShow=0;
    },

    create : function() {

        /*show button home chat*/
        $('#homeVirtual').show();

        /*   Phan MenuSoloMenuSolo    */

        ToanThanToc.game.input.maxPointers = 1;
        this.CreatePageMenuSolo();
        setTimeout(function(){ToanThanToc.MenuSolo.prototype.initSelectBox();},20);
    },

    render:function() {

    },

    update : function() {
        if(ToanThanToc.MenuSolo.prototype.isPlayingSoLo)
        {
            ToanThanToc.MenuSolo.prototype.isPlayingSoLo=false;
            ToanThanToc.MenuSolo.prototype.SetScorceTime();
            SetCssBody('url(assets/solo/play/bg-playscreen.png) no-repeat center center fixed');
            ToanThanToc.MenuSolo.prototype.DeletePageMenuSolo();
            ToanThanToc.game.stage.destroy();
            ToanThanToc.game.state.start('SoloPlay');
        }
        else if(ToanThanToc.MenuSolo.prototype.isBackPlaySolo)
        {
            SetCssBody('url(assets/solo/background/background.png) no-repeat center center fixed');
            ToanThanToc.MenuSolo.prototype.isBackPlaySolo=false;
            ToanThanToc.Menu.prototype.isclick=null;
            ToanThanToc.MenuSolo.prototype.DeletePageMenuSolo();
            setTimeout(function(){
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('Menu');
            },80);
        }
    },

    ShowTime:function(item){
        var time = [];
        if(item==20){
            time.push( { value: 20, text: '20 giây' ,selected: true});
            time.push( { value: 30, text: '30 giây' });
            time.push( { value: 50, text: '50 giây' });
        }
        else if(item==30){
            time.push( { value: 20, text: '20 giây' });
            time.push( { value: 30, text: '30 giây' ,selected: true});
            time.push( { value: 50, text: '50 giây' });
        }
        else if(item==50){
            time.push( { value: 20, text: '20 giây' });
            time.push( { value: 30, text: '30 giây' });
            time.push( { value: 50, text: '50 giây' ,selected: true});
        }
        else if(item==0)
        {
            time.push( { value: 20, text: '20 giây' });
            time.push( { value: 30, text: '30 giây' });
            time.push( { value: 50, text: '50 giây' });
        }
        return time
    },

    ShowScore:function(item){
        var score = [];
        if(item==20){
            score.push( { value: 20, text: '20 điểm' ,selected: true});
            score.push( { value: 30, text: '30 điểm' });
            score.push( { value: 50, text: '50 điểm' });
        }
        else if(item==30){
            score.push( { value: 20, text: '20 điểm' });
            score.push( { value: 30, text: '30 điểm' ,selected: true});
            score.push( { value: 50, text: '50 điểm' });
        }
        else if(item==50){
            score.push( { value: 20, text: '20 điểm' });
            score.push( { value: 30, text: '30 điểm' });
            score.push( { value: 50, text: '50 điểm' ,selected: true});
        }
        else if(item==0)
        {
            score.push( { value: 20, text: '20 điểm' });
            score.push( { value: 30, text: '30 điểm' });
            score.push( { value: 50, text: '50 điểm' });
        }
        return score
    },

    CreatePageMenuSolo: function(){
        ToanThanToc.MenuSolo.prototype.btnMenuSoloBackTT = ToanThanToc.game.add.button(100,1086,'btnBackTT',this.ActionClickMenuSolo,ToanThanToc.game,0,0,1);
//        ToanThanToc.MenuSolo.prototype.btnMenuSoloBackTT = ToanThanToc.game.add.sprite(100,1086,'btnBackTT');

        ToanThanToc.MenuSolo.prototype.logoNahi =ToanThanToc.game.add.sprite(16,16,'logoNAHI');
        ToanThanToc.MenuSolo.prototype.logoVNM =ToanThanToc.game.add.sprite(707,16,'logoVnm');

        ToanThanToc.MenuSolo.prototype.btnMenuSoloEasy = ToanThanToc.game.add.sprite(180,285,'btnMenuSoloEasy');
        ToanThanToc.MenuSolo.prototype.btnMenuSoloEasy.inputEnabled=true;
        ToanThanToc.MenuSolo.prototype.btnMenuSoloEasy.events.onInputDown.add(this.ActionClickMenuSolo,ToanThanToc.game);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloMedium = ToanThanToc.game.add.sprite(180,415,'btnMenuSoloMedium');
        ToanThanToc.MenuSolo.prototype.btnMenuSoloMedium.inputEnabled=true;
        ToanThanToc.MenuSolo.prototype.btnMenuSoloMedium.events.onInputDown.add(this.ActionClickMenuSolo,ToanThanToc.game);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloHard = ToanThanToc.game.add.sprite(180,539,'btnMenuSoloHard');
        ToanThanToc.MenuSolo.prototype.btnMenuSoloHard.inputEnabled=true;
        ToanThanToc.MenuSolo.prototype.btnMenuSoloHard.events.onInputDown.add(this.ActionClickMenuSolo,ToanThanToc.game);
        ToanThanToc.MenuSolo.prototype.ShowLevel();

        ToanThanToc.MenuSolo.prototype.btnMenuSoloPlus = ToanThanToc.game.add.button(133,700,'btnMenuSoloPlus',null,ToanThanToc.game);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloPlus.events.onInputDown.add(this.ActionClickMenuSolo);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloMinus = ToanThanToc.game.add.button(275,700,'btnMenuSoloMinus',null,ToanThanToc.game);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloMinus.events.onInputDown.add(this.ActionClickMenuSolo);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloMulti = ToanThanToc.game.add.button(415,700,'btnMenuSoloMulti',null,ToanThanToc.game);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloMulti.events.onInputDown.add(this.ActionClickMenuSolo);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloDivision = ToanThanToc.game.add.button(558,700,'btnMenuSoloDivision',null,ToanThanToc.game);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloDivision.events.onInputDown.add(this.ActionClickMenuSolo);

        ToanThanToc.MenuSolo.prototype.ShowPhepTinh();

        ToanThanToc.MenuSolo.prototype.btnMenuSoloPlay = ToanThanToc.game.add.button(300,1085,'btnMenuSoloPlay',null,ToanThanToc.game,0,0,1);
        ToanThanToc.MenuSolo.prototype.btnMenuSoloPlay.events.onInputDown.add(this.ActionClickMenuSolo);
	},

    ShowLevel:function(){
        if(ToanThanToc.isLevelSolo==null)
        {
            ToanThanToc.isLevelSolo='EASY';
            ToanThanToc.MenuSolo.prototype.btnMenuSoloEasy.frame=2;
        }
        else if(ToanThanToc.isLevelSolo=='EASY')
            ToanThanToc.MenuSolo.prototype.btnMenuSoloEasy.frame=2;
        else if(ToanThanToc.isLevelSolo=='MEDIUM')
            ToanThanToc.MenuSolo.prototype.btnMenuSoloMedium.frame=2;
        else if(ToanThanToc.isLevelSolo=='HARD')
            ToanThanToc.MenuSolo.prototype.btnMenuSoloHard.frame=2;

    },

    ShowPhepTinh:function(){
        if(!ToanThanToc.plusSolo && !ToanThanToc.minusSolo && !ToanThanToc.multiSolo && !ToanThanToc.divisionSolo)
        {
            ToanThanToc.MenuSolo.prototype.btnMenuSoloPlus.frame=2;
            ToanThanToc.plusSolo=true;
        }
        if(ToanThanToc.plusSolo)
            ToanThanToc.MenuSolo.prototype.btnMenuSoloPlus.frame=2;
        if(ToanThanToc.minusSolo)
            ToanThanToc.MenuSolo.prototype.btnMenuSoloMinus.frame=2;
        if(ToanThanToc.multiSolo)
            ToanThanToc.MenuSolo.prototype.btnMenuSoloMulti.frame=2;
        if(ToanThanToc.divisionSolo)
            ToanThanToc.MenuSolo.prototype.btnMenuSoloDivision.frame=2;
    },

    setUnCheckThreeOption:function(){
        ToanThanToc.MenuSolo.prototype.btnMenuSoloEasy.frame=0;
        ToanThanToc.MenuSolo.prototype.btnMenuSoloMedium.frame=0;
        ToanThanToc.MenuSolo.prototype.btnMenuSoloHard.frame=0;
        ToanThanToc.isLevelSolo=null;
    },

    CheckForCheck:function(){
        var i=0;
        var tam = false;
        if(tam==ToanThanToc.plusSolo)
            i++;
        if(tam==ToanThanToc.minusSolo)
            i++;
        if(tam==ToanThanToc.multiSolo)
            i++;
        if(tam==ToanThanToc.divisionSolo)
            i++;
        if(i==4)
            return true;
        return false;
    },

    ActionClickMenuSolo : function(item){
        log(item.key);
        if(ToanThanToc.music_touch && SetMusic.touch && item.key!='btnOff'&& item.key!='btnXacNhan')
            ToanThanToc.music_touch.play();
        /* Chon cac level */
        if(item.key=='btnMenuSoloEasy') {
            ToanThanToc.MenuSolo.prototype.setUnCheckThreeOption();
            ToanThanToc.isLevelSolo='EASY';
            ToanThanToc.MenuSolo.prototype.btnMenuSoloEasy.frame=1;
            ToanThanToc.MenuSolo.prototype.btnMenuSoloEasy.frame=2;
        }
        else if(item.key=='btnMenuSoloMedium')
        {
            ToanThanToc.MenuSolo.prototype.setUnCheckThreeOption();
            ToanThanToc.isLevelSolo='MEDIUM';
            ToanThanToc.MenuSolo.prototype.btnMenuSoloMedium.frame=1;
            ToanThanToc.MenuSolo.prototype.btnMenuSoloMedium.frame=2;
        }
        else if(item.key=='btnMenuSoloHard')
        {
            ToanThanToc.MenuSolo.prototype.setUnCheckThreeOption();
            ToanThanToc.isLevelSolo='HARD';
            ToanThanToc.MenuSolo.prototype.btnMenuSoloHard.frame=1;
            ToanThanToc.MenuSolo.prototype.btnMenuSoloHard.frame=2;

        /* Chon cac phep tinh */
        }else if(item.key=='btnMenuSoloPlus')
        {
            if(ToanThanToc.plusSolo)
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloPlus.frame=0;
                ToanThanToc.plusSolo = false;
            }
            else{
                ToanThanToc.MenuSolo.prototype.btnMenuSoloPlus.frame=1;
                setTimeout(function(){
                    ToanThanToc.MenuSolo.prototype.btnMenuSoloPlus.frame=2;
                    ToanThanToc.plusSolo = true;
                },50);
            }
            if(ToanThanToc.MenuSolo.prototype.CheckForCheck())
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloPlus.frame=2;
                ToanThanToc.plusSolo=true;
            }

        }else if(item.key=='btnMenuSoloMinus')
        {
            if(ToanThanToc.minusSolo)
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloMinus.frame=0;
                ToanThanToc.minusSolo=false;
            }
            else{
                ToanThanToc.MenuSolo.prototype.btnMenuSoloMinus.frame=1;
                setTimeout(function(){
                    ToanThanToc.MenuSolo.prototype.btnMenuSoloMinus.frame=2;
                    ToanThanToc.minusSolo=true;
                },50);
            }
            if(ToanThanToc.MenuSolo.prototype.CheckForCheck())
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloMinus.frame=2;
                ToanThanToc.minusSolo=true;
            }

        }else if(item.key=='btnMenuSoloMulti')
        {
            if(ToanThanToc.multiSolo)
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloMulti.frame=0;
                ToanThanToc.multiSolo = false;
            }
            else
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloMulti.frame=1;
                setTimeout(function(){
                    ToanThanToc.MenuSolo.prototype.btnMenuSoloMulti.frame=2;
                    ToanThanToc.multiSolo=true;
                },50);
            }
            if(ToanThanToc.MenuSolo.prototype.CheckForCheck())
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloMulti.frame=2;
                ToanThanToc.multiSolo=true;
            }
        }else if(item.key=='btnMenuSoloDivision')
        {
            if(ToanThanToc.divisionSolo)
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloDivision.frame=0;
                ToanThanToc.divisionSolo=false;
            }else{
                ToanThanToc.MenuSolo.prototype.btnMenuSoloDivision.frame=1;
                setTimeout(function(){
                    ToanThanToc.MenuSolo.prototype.btnMenuSoloDivision.frame=2;
                    ToanThanToc.divisionSolo=true;
                },50);
            }
            if(ToanThanToc.MenuSolo.prototype.CheckForCheck())
            {
                ToanThanToc.MenuSolo.prototype.btnMenuSoloDivision.frame=2;
                ToanThanToc.divisionSolo=true;
            }
        }
        else if(item.key=='btnMenuSoloPlay')
        {
            ToanThanToc.MenuSolo.prototype.isPlayingSoLo=true;
        }
		else if(item.key=='btnBackTT')
        {
            ToanThanToc.MenuSolo.prototype.isBackPlaySolo=true;
        }
    },

    SetScorceTime : function(){
        ToanThanToc.numQuestion = ToanThanToc.soloPlayScore;
        ToanThanToc.numQuestion = ToanThanToc.numQuestion+1;
    },

    DeletePageMenuSolo : function(){
        var TT = ToanThanToc.MenuSolo.prototype;
        TT.btnMenuSoloEasy.destroy();
        TT.btnMenuSoloMedium.destroy();
        TT.btnMenuSoloHard.destroy();
        TT.btnMenuSoloPlus.destroy();
        TT.btnMenuSoloMinus.destroy();
        TT.btnMenuSoloMulti.destroy();
        TT.btnMenuSoloDivision.destroy();
        TT.btnMenuSoloPlay.destroy();
        TT.logoNahi.destroy();
        TT.logoVNM.destroy();
        ToanThanToc.MenuSolo.prototype.btnMenuSoloBackTT.destroy();
    },

    initSelectBox: function() {
        var score = ToanThanToc.MenuSolo.prototype.ShowScore(ToanThanToc.soloPlayScore);
        var time = ToanThanToc.MenuSolo.prototype.ShowTime(ToanThanToc.soloPlayTime);
        ToanThanToc.MenuSolo.timeSelectBox = new SelectBox({
            game: ToanThanToc.game,
            data: time,
            selectBoxSpriteSheetId: 'btnListMsl',
            selectBoxPosition: {x: 129, y: 898},
            selectBoxTitle: 'Thời gian',
            selectBoxTitleStartPosition: {x: 40, y: 34},
            listBackgroundImageId: 'bgListBox',
            listBackgroundImagePosition: {x: 145, y: 987},
            listTextStartPosition: {x: 65, y: 22},
            listItemBackgroundImageId: 'bgSelectItemMSL',
            oneInstanceMode: true,
            dependencySelectBoxes: [],
            onClickOnSelectBox: function() {
                if(SetMusic.touch)
                    ToanThanToc.music_touch.play();
            },
            onSelect: function(selectedItem) {
                if(SetMusic.touch)
                    ToanThanToc.music_popupMainAction.play();
                if (selectedItem == null) {
                    ToanThanToc.soloPlayTime = 0;
                }
                else {
                    ToanThanToc.soloPlayTime = selectedItem.value;
                }
            }
        });

        ToanThanToc.MenuSolo.scoreSelectBox = new SelectBox({
            game: ToanThanToc.game,
            data: score,
            selectBoxSpriteSheetId: 'btnListMsl',
            selectBoxPosition: {x: 426, y: 898},
            selectBoxTitle: 'Điểm',
            selectBoxTitleStartPosition: {x: 85, y: 34},
            listBackgroundImageId: 'bgListBox',
            listBackgroundImagePosition: {x: 442, y: 987},
            listTextStartPosition: {x: 55, y: 22},
            listItemBackgroundImageId: 'bgSelectItemMSL',
            oneInstanceMode: true,
            dependencySelectBoxes: [],
            onClickOnSelectBox: function() {
                if(SetMusic.touch)
                    ToanThanToc.music_touch.play();
            },
            onSelect: function(selectedItem) {
                if(SetMusic.touch)
                    ToanThanToc.music_popupMainAction.play();
                if (selectedItem == null) {
                    ToanThanToc.soloPlayScore = 0;
                }
                else {
                    ToanThanToc.soloPlayScore = selectedItem.value;
                }
            }
        });

        ToanThanToc.MenuSolo.timeSelectBox.setDependencySelectBoxes([ToanThanToc.MenuSolo.scoreSelectBox]);
        ToanThanToc.MenuSolo.scoreSelectBox.setDependencySelectBoxes([ToanThanToc.MenuSolo.timeSelectBox]);
    }

};


