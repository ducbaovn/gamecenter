/**
 * @author       Tpt2213 <thanhpt@nahi.vn>
 * @copyright    2014 NAHI JSC.
 * @date     20/12/2014
 */

/**
 * This is the waiting popup.
 *
 * @class Waiting
 * @constructor
 * @param {object} [config=null] - The default config object or null.
 */

/**
 * How to use
 * ToanThanToc.waiting.start()   -> For new state and start a state.
 * ToanThanToc.waiting.open()   -> For open the popup waiting.
 * ToanThanToc.waiting.close()  -> For close the popup waiting.
 */
//-------------------------------------
"use strict";
//-------------------------------------

ToanThanToc.Waiting = {
    isStart: false,
    stateAction: {
        timeGap: null,
        doubleClickHeld: false,
        lastClickTime: null,
        doubleClickDelay: 20,
        waitingIMG:null,

        preload: function(){
         //  this.load.spritesheet('waitingIMG',  'assets/waitting/waitting.png', 643, 521);
        },
        create : function(){

            this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL; /* SHOW_ALL; EXACT_FIT; NO_SCALE */
            this.scale.pageAlignHorizontally = true;
            this.scale.pageAlignVertically = true;

            this.scale.minWidth = ToanThanToc.innerWidth/2;
            this.scale.minHeight = ToanThanToc.innerHeight/2;
            this.scale.maxWidth = ToanThanToc.innerWidth;
            this.scale.maxHeight = ToanThanToc.innerHeight;

            this.scale.forceLandscape = false;
            this.scale.setScreenSize(true);
           // ToanThanToc.FlasIntro.prototype.FixSize();
            // Show the waiting
//            this.waitingIMG = this.add.sprite(this.game.world.centerX-318 , this.game.world.centerY-265, 'waitingIMG');
//            this.waitingIMG.animations.add('walk');
//            this.waitingIMG.animations.play('walk', 2, true);

        },
        update: function() {
            // call gesture's update method each frame.
            if(this.game.input.activePointer.justPressed(0)){
                this.timeGap = this.game.time.now - this.lastClickTime;
                if(this.timeGap < this.doubleClickDelay){
                    this.doubleClickHeld = true;
                }
                this.lastClickTime = this.game.time.now;
            }

            if(this.doubleClickHeld === true){
                // Do this code while second click is still held.
                //ToanThanToc.waiting.close();
                log("De dong popup goi ham: ToanThanToc.waiting.close();");
                this.doubleClickHeld = false;
            }

            // If the pointer is released, then the second click obviously can't be held down.
            if(this.game.input.activePointer.justReleased(0)){
                this.doubleClickHeld = false;
            }
        }
    },
    close : function(){
        log("ToanThanToc.waiting.close");
        //$("#gameCenter").show();
        $("#waiting").css({
            'background-size': '0px',
            'width': '0px',
            'height': '0px',
            'z-index':'-1'
        });

        $("#waiting").hide();
        //log(this);
        //ToanThanToc.waiting.stateAction.waitingIMG.animations.stop();
    },
    start : function(){
        log("ToanThanToc.waiting.start");

        this.state.add("waiting", this.stateAction);
        this.state.start("waiting");
    },
    open : function(){
        log("ToanThanToc.waiting.open");
        //$("#gameCenter").hide();
        $("#waiting").show();

        if(!this.isStart) {
            this.start();
            this.isStart = true;
            return;
        }
       // this.stateAction.waitingIMG.animations.play('walk', 2, true);
    }
};