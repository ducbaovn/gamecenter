/**
 * Created by thanhpt From NAHI on 1/21/2015.
 * @Author: tpt2213
 */

"use strict";
ToanThanToc.SinglePlay = function (game) {

};

ToanThanToc.SinglePlay.prototype = {
    ScoreSG:0,
    startTimeQ:0,
    TimeScroreAtt:[],
    numCombo:0,
    arrayMoneyShow:[],
    amThanh:false,
    preload : function() {
        ToanThanToc.popupShow=0;
        ToanThanToc.SinglePlay.prototype.isNameClick=null;
    if( ToanThanToc.game.cache.checkImageKey('num0SG')&&
        ToanThanToc.game.cache.checkImageKey('num1SG')&&
        ToanThanToc.game.cache.checkImageKey('num2SG')&&
        ToanThanToc.game.cache.checkImageKey('num4SG')&&
        ToanThanToc.game.cache.checkImageKey('num5SG')&&
        ToanThanToc.game.cache.checkImageKey('num6SG')&&
        ToanThanToc.game.cache.checkImageKey('num7SG')
        ) return false;
        log('-------------------Preload single.play-------------------------');
        this.load.spritesheet('avatarUserMath', (ToanThanToc.infoUserMath.avatar_url=="")? 'assets/single/avartar/avr.png':ToanThanToc.infoUserMath.avatar_url.toString(), 121,154);

        this.load.spritesheet('woodBoard', 'assets/single/play/wood-board.png', 801,193);
        this.load.spritesheet('questionBoard', 'assets/single/play/question-board.png', 616,564);

        this.load.spritesheet('num0SG', 'assets/single/play/0.png', 168.5,108);
        this.load.spritesheet('num1SG', 'assets/single/play/1.png', 168.5,108);
        this.load.spritesheet('num2SG', 'assets/single/play/2.png', 168.5,108);
        this.load.spritesheet('num3SG', 'assets/single/play/3.png', 168.5,108);
        this.load.spritesheet('num4SG', 'assets/single/play/4.png', 168.5,108);
        this.load.spritesheet('num5SG', 'assets/single/play/5.png', 168.5,108);
        this.load.spritesheet('num6SG', 'assets/single/play/6.png', 168.5,108);
        this.load.spritesheet('num7SG', 'assets/single/play/7.png', 168.5,108);
        this.load.spritesheet('num8SG', 'assets/single/play/8.png', 168.5,108);
        this.load.spritesheet('num9SG', 'assets/single/play/9.png', 168.5,108);
        this.load.spritesheet('numMinusSG', 'assets/single/play/minus.png', 168.5,108);
        this.load.spritesheet('numClearSG', 'assets/single/play/clear.png', 168.5,108);

        this.load.spritesheet('popupEndGameSGP', 'assets/single/popup/popup-end-game.png', 734,914);
        this.load.spritesheet('btnMenuSGP', 'assets/single/popup/btn-menu.png', 192,77);
        this.load.spritesheet('btnRedoSGP', 'assets/single/popup/btn-redo.png', 170,78);

        this.load.spritesheet('aEinstein', 'assets/single/popup/a-einstein.png',70,70);
        this.load.spritesheet('aExp', 'assets/single/popup/a-exp.png', 70,70);
        this.load.spritesheet('comboSprite', 'assets/single/play/combo-sprite.png', 830,348);
        this.load.spritesheet('btnFeelingLose', 'assets/single/play/btn-feeling-lose.png', 140,140);
    },

    create : function() {

        /*hide button home chat*/
        $('#homeVirtual').hide();

        /*   Phan MenuSingleMenuSingle    */
        ToanThanToc.MenuSingle.prototype.SetConFixMath();
        ToanThanToc.soloPlayTime=0;
        ToanThanToc.soloPlayScore=20;
        ToanThanToc.SinglePlay.prototype.dapAn='';
        ToanThanToc.SinglePlay.prototype.lanthu=0;
        ToanThanToc.game.input.maxPointers=1;
        this.CreatePagePlaySingle();
        this.CreatePopup();
        ToanThanToc.SinglePlay.prototype.CreateNewTime();
    },

    render:function() {
      /*  if(ToanThanToc.soloPlayTime!=0)*/
        {
           ToanThanToc.SinglePlay.prototype.textTime.setText(
               ToanThanToc.SinglePlay.prototype.ShowTime (parseFloat(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds).toFixed(3))
           );
        }
        if(SetMusic.music==true&&ToanThanToc.music_win.isPlaying==false&&
            ToanThanToc.SinglePlay.prototype.amThanh==false&&ToanThanToc.music_music.isPlaying==false)
        {
            setTimeout(function(){
                ToanThanToc.EndSoloPlay.prototype.amThanh = true;
                ToanThanToc.music_music.restart();
            },100);
        }
      /*  if(ToanThanToc.soloPlayTime!=0)
            if(parseInt(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds)>=ToanThanToc.soloPlayTime)
                if(ToanThanToc.SinglePlay.prototype.OffGameTime()==false)
                    return false;*/
    },

    update : function() {
        if(ToanThanToc.SinglePlay.prototype.isCount)
        {
            ToanThanToc.SinglePlay.prototype.countDownImg.destroy();
            ToanThanToc.SinglePlay.prototype.isCount=false;
            delete (ToanThanToc.SinglePlay.prototype.countDown);
            ToanThanToc.SinglePlay.prototype.isNameClick=null;
            ToanThanToc.SinglePlay.prototype.ResumeTimer();
            ToanThanToc.SinglePlay.prototype.CreateScroce();
            ToanThanToc.SinglePlay.prototype.CreateQuestion();
        }

    },

    CreateNewTime:function(){
        ToanThanToc.SinglePlay.prototype.timmer = new Phaser.Time(ToanThanToc.game);
        ToanThanToc.SinglePlay.prototype.ResetTimer();
    },

    PauseTimer:function(){
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events.pause();
    },

    ResetTimer : function(){
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events.pause();
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events.nextTick=0;
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events._pauseStarted=0;
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events._pauseTotal=0;
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events._started=0;
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events._now=0;
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events.timeCap=0;
    },

    ResumeTimer:function(){
        ToanThanToc.SinglePlay.prototype.timmer.game.time.events.resume();
    },

    CreateScroce:function(){
        if(ToanThanToc.soloPlayScore!=0)
        {
            ToanThanToc.SinglePlay.prototype.textScore.setText('0/'+ToanThanToc.soloPlayScore.toString());
        }
    },

    OffGameScore:function(){
        if(ToanThanToc.SinglePlay.prototype.ScoreSG.toString()==ToanThanToc.soloPlayScore.toString())
        {
            ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
            ToanThanToc.SinglePlay.prototype.timeEndSave = ToanThanToc.SinglePlay.prototype.ShowTime (parseFloat(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds).toFixed(3));
            ToanThanToc.SinglePlay.prototype.PauseTimer();
            /* Neu thoi gian khong co thi off */
            ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
            ToanThanToc.SinglePlay.prototype.SendScoreMathSingle('');
            return false;
        }
    },

    OffGameTime:function(){
        ToanThanToc.SinglePlay.prototype.PauseTimer();
        /* Neu thoi gian khong co thi off */
        ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
        ToanThanToc.SinglePlay.prototype.ResetTimer();
        ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
        /*ToanThanToc.SinglePlay.prototype.CreatePopupEndGame();*/
        return false;
    },

    CreateQuestion:function(){
        /*  if(ToanThanToc.game.input.pointer3==null)
        {
            ToanThanToc.SinglePlay.prototype.CreateMultiPointer();
            log('CreateMultiPointer');
        }*/

        /*if(ToanThanToc.soloPlayTime!=0)
            if(parseInt(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds)>=ToanThanToc.soloPlayTime)
                if(ToanThanToc.SinglePlay.prototype.OffGameTime()==false)
                    return false;*/

        ToanThanToc.answer=null;
        var phepTinh1 = ToanThanToc.SoloPlay.prototype.CreatePhepTinh();
        var arrayDe = ToanThanToc.SoloPlay.prototype.RandomQuestion(phepTinh1);
        var num1 = arrayDe[0];
        var num2 = arrayDe[2];
        ToanThanToc.SinglePlay.prototype.arrayQ=[num1.toString(),phepTinh1.toString(),num2.toString()];
        ToanThanToc.answer = arrayDe[3];
        ToanThanToc.SinglePlay.prototype.arrDA = ToanThanToc.answer.toString().split("");
        ToanThanToc.SinglePlay.prototype.AnimationQuestionBoard();
    },

    CreatePopup:function(){
        log(ToanThanToc.game.world.height);
        log(ToanThanToc.game.world.centerY);

        ToanThanToc.SinglePlay.prototype.bgPPSL =  ToanThanToc.game.add.image(0,0, 'bgPopupOk');
        ToanThanToc.SinglePlay.prototype.bgPPSL.inputEnabled=true;
        ToanThanToc.SinglePlay.prototype.bgPPSL.events.onInputDown.add(ToanThanToc.SinglePlay.prototype.CloseWindow);
        ToanThanToc.Menu.prototype.BacgroundForPopup();

        ToanThanToc.SinglePlay.prototype.bgPopupSound  = ToanThanToc.game.add.image(ToanThanToc.game.world.centerX - 631/2 ,ToanThanToc.game.world.centerY - 445/2-35  , 'bgSLPopupSound');

        var w = ToanThanToc.SinglePlay.prototype.bgPopupSound.width;
        var h = ToanThanToc.SinglePlay.prototype.bgPopupSound.height;

        ToanThanToc.SinglePlay.prototype.bgPopupSound.width =ToanThanToc.SinglePlay.prototype.bgPopupSound.width - 630;
        ToanThanToc.SinglePlay.prototype.bgPopupSound.height = ToanThanToc.SinglePlay.prototype.bgPopupSound.height  -395;
        ToanThanToc.SinglePlay.prototype.bgPopupSound.x=ToanThanToc.game.world.centerX - ToanThanToc.SinglePlay.prototype.bgPopupSound.width/2;
        ToanThanToc.SinglePlay.prototype.bgPopupSound.y=ToanThanToc.game.world.centerY - ToanThanToc.SinglePlay.prototype.bgPopupSound.height/2;

        ToanThanToc.SinglePlay.prototype.btnOkPlaySG = ToanThanToc.game.add.button(215, 287, 'btnOkPlaySL', this.ActionClickSinglePlay, ToanThanToc.game);

        ToanThanToc.SinglePlay.prototype.bgPopupSound.addChild(ToanThanToc.SinglePlay.prototype.btnOkPlaySG);
        ToanThanToc.SinglePlay.prototype.tweenOpen1 = ToanThanToc.game.add.tween( ToanThanToc.SinglePlay.prototype.bgPopupSound).to( { width:w, height:h,x:ToanThanToc.game.world.centerX - 631/2 ,y:ToanThanToc.game.world.centerY - 445/2-35  }, 5, Phaser.Easing.Sinusoidal.Out, true);
    },

    SetAudio:function(){

    },

    CreatePopupEndGame:function(){

        ToanThanToc.music_win.play();

        var percent=0;
        if (ToanThanToc.MenuSingle.prototype.timeBonus > 0) {
            percent = (ToanThanToc.MenuSingle.prototype.timeBonus - parseInt(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds*1000)) / ToanThanToc.MenuSingle.prototype.timeBonus;
            if (percent <= 0) {
                percent = 0;
            }
        }
        var expForLevel = (ToanThanToc.MenuSingle.prototype.expPerLevel +
            ToanThanToc.MenuSingle.prototype.excellenceCombo*ToanThanToc.SinglePlay.prototype.numCombo) * (1 + percent);
        var moneyForLevel = ToanThanToc.MenuSingle.prototype.moneyPerLevel * (1 + percent);

        var EXPcombo = ToanThanToc.MenuSingle.prototype.excellenceCombo*ToanThanToc.SinglePlay.prototype.numCombo;
        var EXPcomboBonus = Math.ceil(expForLevel-ToanThanToc.MenuSingle.prototype.expPerLevel-EXPcombo);

        var MoneyBonus = (ToanThanToc.infoUserMath.energy<10)? 0 : Math.ceil(moneyForLevel - ToanThanToc.MenuSingle.prototype.moneyPerLevel);

        ToanThanToc.SinglePlay.prototype.bgPPSL =  ToanThanToc.game.add.image(0,0, 'bgPopupOk');
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ToanThanToc.SinglePlay.prototype.popupEndGameSGP = ToanThanToc.game.add.sprite(
            ToanThanToc.game.world.centerX-734/2,ToanThanToc.game.world.centerY-914/2,'popupEndGameSGP'
        );
        ToanThanToc.SinglePlay.prototype.btnMenuSGP=ToanThanToc.game.add.button(
            165,640,'btnMenuSGP',this.ActionClickPUEnd,ToanThanToc.game,0,0,1
        );
        ToanThanToc.SinglePlay.prototype.btnRedoSGP=ToanThanToc.game.add.button(
            400,640,'btnRedoSGP',this.ActionClickPUEnd,ToanThanToc.game,0,0,1
        );
            //numGree
            //numBlue
        ToanThanToc.SinglePlay.prototype.textTimePlay=ToanThanToc.game.add.bitmapText(236,386,'numBlue',
            (ToanThanToc.soloPlayTime!=0)?'00:'+ToanThanToc.soloPlayTime.toString()+',000 giây'
                :ToanThanToc.SinglePlay.prototype.timeEndSave+' giây',
            27);

        ToanThanToc.SinglePlay.prototype.textEXP=ToanThanToc.game.add.bitmapText(236,476,'numBlue',
            ToanThanToc.SinglePlay.prototype.exp._text,27);

        ToanThanToc.SinglePlay.prototype.textComboEXP =ToanThanToc.game.add.bitmapText(ToanThanToc.SinglePlay.prototype.textEXP.width +236 ,476,'numGreen',
          ' + ' + (ToanThanToc.MenuSingle.prototype.excellenceCombo*ToanThanToc.SinglePlay.prototype.numCombo).toString(),27);

        ToanThanToc.SinglePlay.prototype.textBonusEXP =ToanThanToc.game.add.bitmapText(
                ToanThanToc.SinglePlay.prototype.textEXP.width +ToanThanToc.SinglePlay.prototype.textComboEXP.width +236 ,476,'numRed',
                ' + ' + EXPcomboBonus.toString(),27);

        ToanThanToc.SinglePlay.prototype.textEinStein=ToanThanToc.game.add.bitmapText(238,565,'numBlue',
            ToanThanToc.SinglePlay.prototype.einstein._text,27);
        ToanThanToc.SinglePlay.prototype.textComboEinStein =ToanThanToc.game.add.bitmapText(
                ToanThanToc.SinglePlay.prototype.textEinStein.width + 238,567,'numRed',' + '+MoneyBonus.toString(),27);

        ToanThanToc.SinglePlay.prototype.popupEndGameSGP.addChild(ToanThanToc.SinglePlay.prototype.btnMenuSGP);
        ToanThanToc.SinglePlay.prototype.popupEndGameSGP.addChild(ToanThanToc.SinglePlay.prototype.btnRedoSGP);
        ToanThanToc.SinglePlay.prototype.popupEndGameSGP.addChild(ToanThanToc.SinglePlay.prototype.textTimePlay);
        ToanThanToc.SinglePlay.prototype.popupEndGameSGP.addChild(ToanThanToc.SinglePlay.prototype.textEXP);
        ToanThanToc.SinglePlay.prototype.popupEndGameSGP.addChild(ToanThanToc.SinglePlay.prototype.textComboEXP);
        ToanThanToc.SinglePlay.prototype.popupEndGameSGP.addChild(ToanThanToc.SinglePlay.prototype.textBonusEXP);
        ToanThanToc.SinglePlay.prototype.popupEndGameSGP.addChild(ToanThanToc.SinglePlay.prototype.textEinStein);
        ToanThanToc.SinglePlay.prototype.popupEndGameSGP.addChild(ToanThanToc.SinglePlay.prototype.textComboEinStein);

        return false;
    },

    /* tao so lan hien thi tien */
    TestArraySame:function(arr){
        var a =false;
        for(var k =0 ;k<arr.length;k++)
        {
            for(var j =k+1 ;j<arr.length;j++)
            {
                if(arr[k]==arr[j])
                {
                    a=true;
                }
            }
        }
        return a;
    },
    TestIndexExit:function(arr,a){
        log(arr);
        var b=false;
        for(var k =0 ;k<arr.length;k++)
        {
            if(arr[k]==a)
            {
               b=true;
            }
        }
        return b;
    },
    CreateArrayShowMoney:function(){
        ToanThanToc.SinglePlay.prototype.arrayMoneyShow=[];
        var index=0;
        var bool=false,bool1=false;
        for(var i=0;i<ToanThanToc.MenuSingle.prototype.moneyPerLevel;i++)
        {
            index =  ToanThanToc.game.rnd.integerInRange(1,ToanThanToc.soloPlayScore);
            while(index<=0||index>ToanThanToc.soloPlayScore){
                index =  ToanThanToc.game.rnd.integerInRange(1,ToanThanToc.soloPlayScore)+ToanThanToc.game.rnd.integerInRange(-8,13);
                if(index>0 && index<=ToanThanToc.soloPlayScore
                    &&  ToanThanToc.SinglePlay.prototype.TestIndexExit(ToanThanToc.SinglePlay.prototype.arrayMoneyShow,index)==false
                    &&  ToanThanToc.SinglePlay.prototype.TestArraySame(ToanThanToc.SinglePlay.prototype.arrayMoneyShow)==false
                )
                {
                    bool = ToanThanToc.SinglePlay.prototype.TestIndexExit(ToanThanToc.SinglePlay.prototype.arrayMoneyShow,index);
                    bool1 = ToanThanToc.SinglePlay.prototype.TestArraySame(ToanThanToc.SinglePlay.prototype.arrayMoneyShow);
                    if(bool==false&&bool1==false)
                        break;
                }
            }
            bool = ToanThanToc.SinglePlay.prototype.TestIndexExit(ToanThanToc.SinglePlay.prototype.arrayMoneyShow,index);
            bool1 = ToanThanToc.SinglePlay.prototype.TestArraySame(ToanThanToc.SinglePlay.prototype.arrayMoneyShow);
            if(bool==false&&bool1==false)
                ToanThanToc.SinglePlay.prototype.arrayMoneyShow.push(index);
            else
            {
                index =  ToanThanToc.game.rnd.integerInRange(1,ToanThanToc.soloPlayScore);
                while(index<=0||index>ToanThanToc.soloPlayScore){
                    index =  ToanThanToc.game.rnd.integerInRange(1,ToanThanToc.soloPlayScore)+ToanThanToc.game.rnd.integerInRange(-8,13);
                    if(index>0 && index<=ToanThanToc.soloPlayScore
                        &&  ToanThanToc.SinglePlay.prototype.TestIndexExit(ToanThanToc.SinglePlay.prototype.arrayMoneyShow,index)==false
                        &&  ToanThanToc.SinglePlay.prototype.TestArraySame(ToanThanToc.SinglePlay.prototype.arrayMoneyShow)==false
                        )
                    {
                        bool = ToanThanToc.SinglePlay.prototype.TestIndexExit(ToanThanToc.SinglePlay.prototype.arrayMoneyShow,index);
                        bool1 = ToanThanToc.SinglePlay.prototype.TestArraySame(ToanThanToc.SinglePlay.prototype.arrayMoneyShow);
                        if(bool==false&&bool1==false)
                            break;
                    }
                }
                ToanThanToc.SinglePlay.prototype.arrayMoneyShow.push(index);
            }
        }

        ToanThanToc.SinglePlay.prototype.arrayMoneyShow.sort();

        log(ToanThanToc.SinglePlay.prototype.arrayMoneyShow);
    },

    CreatePagePlaySingle:function(){
        var SG = ToanThanToc.SinglePlay.prototype;
        SG.num0SG = ToanThanToc.game.add.button(325,1013,'num0SG',null,ToanThanToc.game,0,0,1);
        SG.num0SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num0SG.name='0';
        SG.num1SG = ToanThanToc.game.add.button(116,605,'num1SG',null,ToanThanToc.game,0,0,1);
        SG.num1SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num1SG.name='1';
        SG.num2SG = ToanThanToc.game.add.button(325,605,'num2SG',null,ToanThanToc.game,0,0,1);
        SG.num2SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num2SG.name='2';
        SG.num3SG = ToanThanToc.game.add.button(530,605,'num3SG',null,ToanThanToc.game,0,0,1);
        SG.num3SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num3SG.name='3';
        SG.num4SG = ToanThanToc.game.add.button(116,740,'num4SG',null,ToanThanToc.game,0,0,1);
        SG.num4SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num4SG.name='4';
        SG.num5SG = ToanThanToc.game.add.button(325,740,'num5SG',null,ToanThanToc.game,0,0,1);
        SG.num5SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num5SG.name='5';
        SG.num6SG = ToanThanToc.game.add.button(530,740,'num6SG',null,ToanThanToc.game,0,0,1);
        SG.num6SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num6SG.name='6';
        SG.num7SG = ToanThanToc.game.add.button(116,877,'num7SG',null,ToanThanToc.game,0,0,1);
        SG.num7SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num7SG.name='7';
        SG.num8SG = ToanThanToc.game.add.button(325,877,'num8SG',null,ToanThanToc.game,0,0,1);
        SG.num8SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num8SG.name='8';
        SG.num9SG = ToanThanToc.game.add.button(530,877,'num9SG',null,ToanThanToc.game,0,0,1);
        SG.num9SG.events.onInputDown.add(SG.ActionClickNum);
        SG.num9SG.name='9';
        SG.numMinusSG = ToanThanToc.game.add.button(116,1013,'numMinusSG',null,ToanThanToc.game,0,0,1);
        SG.numMinusSG.events.onInputDown.add(SG.ActionClickNum);
        SG.numMinusSG.name='-';
        SG.numClearSG = ToanThanToc.game.add.button(530,1013,'numClearSG',null,ToanThanToc.game,0,0,1);
        SG.numClearSG.events.onInputDown.add(SG.ActionClickNum);

        SG.woodBoard = ToanThanToc.game.add.sprite(0,0,'woodBoard');
        SG.einstein = ToanThanToc.game.add.bitmapText(276,34,'num', '0' ,30);
        SG.exp = ToanThanToc.game.add.bitmapText(276,100, 'num','0' ,30);
        SG.textTime = ToanThanToc.game.add.bitmapText(497,34,'num','00:00,000',30);
        SG.textScore = ToanThanToc.game.add.bitmapText(497,100,'num','0',30);

        SG.woodBoard.addChild(SG.einstein);
        SG.woodBoard.addChild(SG.exp);
        SG.woodBoard.addChild(SG.textTime);
        SG.woodBoard.addChild(SG.textScore);

        SG.questionBoard = ToanThanToc.game.add.sprite(92,135,'questionBoard');
        SG.textQuestion = ToanThanToc.game.add.bitmapText(206,175,'numBoard','',80);
        SG.questionBoard.addChild(SG.textQuestion);
        SG.textAnswer = ToanThanToc.game.add.bitmapText(282.72,290,'numBoard','',70);
        SG.questionBoard.addChild(SG.textAnswer);

        ToanThanToc.SinglePlay.prototype.animaQuestionBoard = SG.questionBoard.animations.add('fire');

        SG.avatarUserMath = ToanThanToc.game.add.sprite(35,19,'avatarUserMath');
        ToanThanToc.SinglePlay.prototype.CreateArrayShowMoney();

        if(ToanThanToc.challengeid=='')
        {
            SG.SettingSGP = ToanThanToc.game.add.button(670,21,'btnSettingSoloPlay',null,ToanThanToc.game,0,0,1);
            SG.SettingSGP.events.onInputDown.add(SG.ActionClickSettingSGP);
        }
        else
        {
            SG.SettingSGP = ToanThanToc.game.add.button(668,18  ,'btnFeelingLose',function(){
                shareFunction.actionPlayAudio('touch');
                ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
                ToanThanToc.SinglePlay.prototype.timeEndSave = ToanThanToc.SinglePlay.prototype.ShowTime (parseFloat(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds).toFixed(3));
                ToanThanToc.SinglePlay.prototype.PauseTimer();
                /* Neu thoi gian khong co thi off */
                ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
                ToanThanToc.SinglePlay.prototype.SendScoreMathSingle('thuaDiCung');
            },ToanThanToc.game,0,0,1);

        }

        SG.aEinstein=ToanThanToc.game.add.sprite(
            ToanThanToc.game.rnd.integerInRange(50,700),ToanThanToc.game.rnd.integerInRange(280,900),'aEinstein'
        );
        SG.aExp=ToanThanToc.game.add.sprite(
            ToanThanToc.game.rnd.integerInRange(50,700),ToanThanToc.game.rnd.integerInRange(280,900),'aExp'
        );

        SG.aExp.visible=false;
        SG.aEinstein.visible=false;
        ToanThanToc.SinglePlay.prototype.ArrayDrawEXP = this.DrawParabol(SG.aExp,206,79);
        ToanThanToc.SinglePlay.prototype.ArrayDrawMoney = this.DrawParabol(SG.aEinstein,206,13);

        SG.comboSprite=ToanThanToc.game.add.sprite( 10,85,'comboSprite');
        SG.comboSprite.visible=false;
        ToanThanToc.SinglePlay.prototype.animaCombo = SG.comboSprite.animations.add('jumb');
    },

    animaQuestionBoard:null,

    CreateAminationCountDown:function(){
        ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
        ToanThanToc.SinglePlay.prototype.countDownImg = ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-185 , ToanThanToc.game.world.centerY-185  , 'countDown');
        ToanThanToc.SinglePlay.prototype.countDown =   ToanThanToc.SinglePlay.prototype.countDownImg.animations.add('walk');

        ToanThanToc.SinglePlay.prototype.countDown.onStart.add( this.AnimationStarted, ToanThanToc.game);
        ToanThanToc.SinglePlay.prototype.countDown.onLoop.add(this.AnimationLooped, ToanThanToc.game);
        ToanThanToc.SinglePlay.prototype.countDown.onComplete.add(this.AnimationStopped, ToanThanToc.game);

        /// true se co loop
        ToanThanToc.SinglePlay.prototype.countDown.play(3, false);
    },

    /* crate popup WIN challenges */
    CreatePopupWinChallenge:function(){
        shareFunction.actionPlayAudio('win');
        var ttt = ToanThanToc.SinglePlay.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgPPDelChConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');

        ttt.bgWinnerChall=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-571/2,ToanThanToc.game.world.centerY-548/2,'bgWinnerChall');

        ttt.btnBackPPSGChW=ToanThanToc.game.add.button(100,400,'btnBackPPSGCh',
        function(){
            shareFunction.actionPlayAudio('right');
            if(ttt.isNameClick==null) {
                ttt.isNameClick='btnBackPPSGCh';
                GetListMyChall(function(data){
                    if(data=='erro') return false;
                    GetListYourChall(function(data){
                        if(data=='erro') return false;
                        else
                        {
                            ToanThanToc.Menu.prototype.HideBgPopupBottom();
                            ToanThanToc.Menu.prototype.HideBgPopupTop();
                            ToanThanToc.SinglePlay.prototype.ScoreSG=0;
                            ToanThanToc.SinglePlay.prototype.playSingleId='';
                            ttt.DeleteQuestionAndAnswer();
                            ttt.SetDefaultMoneyAndEXP();
                            SetCssBody('url(assets/single/background/bgok.png) no-repeat center center fixed');
                            ttt.DeletePageSinglePlay();
                            ToanThanToc.game.stage.destroy();
                            ToanThanToc.game.state.start('SingleListChallenges');
                        }
                    });
                });
                ttt.isNameClick=null;
            }
        },ToanThanToc.game,0,0,1);
        ttt.btnExitPPSGChF=ToanThanToc.game.add.button(335,400,'btnExitPPSGCh',
        function(){
            shareFunction.actionPlayAudio('right');
            if(ttt.isNameClick==null){
                ttt.isNameClick='btnExitPPSGCh';
                ToanThanToc.Menu.prototype.HideBgPopupBottom();
                ToanThanToc.Menu.prototype.HideBgPopupTop();
                ToanThanToc.SinglePlay.prototype.ScoreSG=0;
                ToanThanToc.SinglePlay.prototype.playSingleId='';
                ttt.DeleteQuestionAndAnswer();
                ttt.SetDefaultMoneyAndEXP();
                SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
                ttt.DeletePageSinglePlay();
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('MenuSingle');
                ttt.isNameClick=null;
            }
        },ToanThanToc.game,0,0,1);

        ttt.textStart001=ToanThanToc.game.add.bitmapText(335,325,'numGreen',(ToanThanToc.PlayerChall[ToanThanToc.challengeIndex].moneyPerOne).toString(),30);

        ttt.bgWinnerChall.addChild( ttt.btnBackPPSGChW);
        ttt.bgWinnerChall.addChild( ttt.btnExitPPSGChF);
        ttt.bgWinnerChall.addChild( ttt.textStart001);
        ttt.isNameClick = null;
    },

    /* crate popup FAIL challenges */
    CreatePopupFailChallenge:function(){
        shareFunction.actionPlayAudio('lose');
        var ttt = ToanThanToc.SinglePlay.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgPPDelChConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');

        ttt.bgWinnerChall=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-571/2,ToanThanToc.game.world.centerY-548/2,'bgLoserPPSGCh');

        ttt.btnBackPPSGChW=ToanThanToc.game.add.button(60,380,'btnBackPPSGCh',
            function(){
                shareFunction.actionPlayAudio('right');
                if(ttt.isNameClick==null) {
                    ttt.isNameClick='btnBackPPSGCh';
                    GetListMyChall(function(data){
                        if(data=='erro') return false;
                        GetListYourChall(function(data){
                            if(data=='erro') return false;
                            else
                            {
                                ToanThanToc.Menu.prototype.HideBgPopupBottom();
                                ToanThanToc.Menu.prototype.HideBgPopupTop();
                                ToanThanToc.SinglePlay.prototype.ScoreSG=0;
                                ToanThanToc.SinglePlay.prototype.playSingleId='';
                                ttt.DeleteQuestionAndAnswer();
                                ttt.SetDefaultMoneyAndEXP();
                                SetCssBody('url(assets/single/background/bgok.png) no-repeat center center fixed');
                                ttt.DeletePageSinglePlay();
                                ToanThanToc.game.stage.destroy();
                                ToanThanToc.game.state.start('SingleListChallenges');
                            }
                        });
                    });
                    ttt.isNameClick=null;
                }
            },ToanThanToc.game,0,0,1);

        ttt.btnRePPSGChF=ToanThanToc.game.add.button(220,380,'btnTryPPSGCh',
            function(){
                shareFunction.actionPlayAudio('right');
                if(ttt.isNameClick==null){
                    ttt.isNameClick='btnTryPPSGCh';
                    ToanThanToc.SinglePlay.prototype.ScoreSG=0;
                    ttt.DeleteQuestionAndAnswer();
                    ttt.SetDefaultMoneyAndEXP();
                    ToanThanToc.Menu.prototype.HideBgPopupBottom();
                    ToanThanToc.Menu.prototype.HideBgPopupTop();
                    ttt.CreateArrayShowMoney();
                    ttt.ResetTimer();
                    ToanThanToc.challengeid = ttt.challengeId;
                    ttt.CreateAminationCountDown();
                    ttt.isNameClick=null;
                    ttt.DeletePopupSetting('btnTryPPSGCh');
                }
            },ToanThanToc.game,0,0,1);

        ttt.btnExitPPSGChF=ToanThanToc.game.add.button(375,380,'btnExitPPSGCh',
            function(){
                shareFunction.actionPlayAudio('right');
                if(ttt.isNameClick==null){
                    ttt.isNameClick='btnExitPPSGCh';
                    ToanThanToc.Menu.prototype.HideBgPopupBottom();
                    ToanThanToc.Menu.prototype.HideBgPopupTop();
                    ToanThanToc.SinglePlay.prototype.ScoreSG=0;
                    ToanThanToc.SinglePlay.prototype.playSingleId='';
                    ttt.DeleteQuestionAndAnswer();
                    ttt.SetDefaultMoneyAndEXP();
                    SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
                    ttt.DeletePageSinglePlay();
                    ToanThanToc.game.stage.destroy();
                    ToanThanToc.game.state.start('MenuSingle');
                    ttt.isNameClick=null;
                }
            },ToanThanToc.game,0,0,1);

        ttt.bgWinnerChall.addChild( ttt.btnBackPPSGChW);
        ttt.bgWinnerChall.addChild( ttt.btnExitPPSGChF);
        ttt.bgWinnerChall.addChild( ttt.btnRePPSGChF);
        ttt.isNameClick = null;
    },

    AnimationStarted : function(sprite, animation){
        log('start animation');
        if(ToanThanToc.challengeid!='')
        {
            AcceptChallenge(function(data){
                ToanThanToc.SinglePlay.prototype.challengeId=ToanThanToc.challengeid;
                ToanThanToc.challengeid='';
                if(data=='erro')
                    ToanThanToc.SinglePlay.prototype.playSingleId  = '';
                else
                    ToanThanToc.SinglePlay.prototype.playSingleId  = data.id;
            },ToanThanToc.challengeid);
        }
    },

    AnimationLooped : function(sprite, animation){
        log('ko loop');
        animation.loop=false;
    },

    AnimationStopped : function(sprite, animation){
        ToanThanToc.SinglePlay.prototype.isCount=true;
        log('stop animation');
    },
    challengeId:'',
    playSingleId:'',

    AnimationQuestionBoardStopped :function(){
        if(ToanThanToc.SinglePlay.prototype.ScoreSG<20)
            ToanThanToc.SinglePlay.prototype.ResumeTimer();
        else
            return false;
        ToanThanToc.SinglePlay.prototype.textQuestion.setText(
                ToanThanToc.SinglePlay.prototype.arrayQ[0]+' '+ToanThanToc.SinglePlay.prototype.arrayQ[1]+' '+ToanThanToc.SinglePlay.prototype.arrayQ[2]
        );
        ToanThanToc.SinglePlay.prototype.textAnswer.setText('. . .');
        setTimeout(function(){
            ToanThanToc.SinglePlay.prototype.textQuestion.x=
                ToanThanToc.SinglePlay.prototype.questionBoard.width/2 - ToanThanToc.SinglePlay.prototype.textQuestion.width/2  ;
            ToanThanToc.SinglePlay.prototype.textAnswer.x=
                ToanThanToc.SinglePlay.prototype.questionBoard.width/2 - ToanThanToc.SinglePlay.prototype.textAnswer.width/2  ;
            ToanThanToc.SinglePlay.prototype.SetInputEnable(true);
            log('câu hỏi mới được tạo ra');
            ToanThanToc.SinglePlay.prototype.startTimeQ=parseFloat(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds.toFixed(3));
        },3);
    },

    AnimationQuestionBoard : function(){
        ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
        ToanThanToc.SinglePlay.prototype.SetFrame(0);
        ToanThanToc.SinglePlay.prototype.PauseTimer();
        ToanThanToc.SinglePlay.prototype.animaQuestionBoard.onComplete.add(this.AnimationQuestionBoardStopped, ToanThanToc.game);
        ToanThanToc.SinglePlay.prototype.animaQuestionBoard.play(12, false);
    },
    dapAn:'',
    lanthu:0,
    ActionClickNum:function(item){
        log(item.key);
        if(ToanThanToc.music_touch && SetMusic.touch)
            ToanThanToc.music_touch.play();
        if(item.key== 'numClearSG')
        {
            if(ToanThanToc.SinglePlay.prototype.dapAn!='')
            {
                ToanThanToc.SinglePlay.prototype.dapAn=ToanThanToc.SinglePlay.prototype.dapAn.substring(0,ToanThanToc.SinglePlay.prototype.dapAn.length-1);
                ToanThanToc.SinglePlay.prototype.SetTextAnswer(ToanThanToc.SinglePlay.prototype.dapAn);
                if(ToanThanToc.SinglePlay.prototype.lanthu>0)
                    ToanThanToc.SinglePlay.prototype.lanthu--;
            }
        }
        else
        {
            ToanThanToc.SinglePlay.prototype.dapAn=ToanThanToc.SinglePlay.prototype.dapAn + item.name;
            ToanThanToc.SinglePlay.prototype.SetTextAnswer(ToanThanToc.SinglePlay.prototype.dapAn);
            ToanThanToc.SinglePlay.prototype.CheckTrueFalseAnswer(ToanThanToc.SinglePlay.prototype.dapAn,ToanThanToc.SinglePlay.prototype.lanthu);
            ToanThanToc.SinglePlay.prototype.lanthu++;
        }
    },

    isNameClick:null,

    ActionClickSinglePlay:function(item){
        if(ToanThanToc.SinglePlay.prototype.isNameClick==null)
        {
            if (ToanThanToc.SinglePlay.prototype.tweenOpen1 &&  ToanThanToc.SinglePlay.prototype.tweenOpen1.isRunning) return false;
            log(item.key);
            if(item.key=='btnOkPlaySL'  && SetMusic.touch )
                ToanThanToc.music_popupQuit.play();

            if(item.key=='btnOkPlaySL')
            {
                ToanThanToc.SinglePlay.prototype.isNameClick='btnOkPlaySL';
                ToanThanToc.SinglePlay.prototype.btnOkPlaySG.frame = 1;
                setTimeout(function () {
                    ToanThanToc.SinglePlay.prototype.btnOkPlaySG.frame = 0;
                    ToanThanToc.SinglePlay.prototype.CloseWindow();
                }, 50);
            }
        }
    },

    ActionClickSettingSGP:function(item){
        var tt = ToanThanToc.SinglePlay.prototype;
       /* tt.ResetPointer();*/
        if(ToanThanToc.music_touch && SetMusic.touch && item.key!='btnOff'&& item.key!='offSound'&& item.key!='onSound')
            ToanThanToc.music_touch.play();
        log('ToanThanToc.popupShow= '+ToanThanToc.popupShow);
        if(ToanThanToc.popupShow==0)
        {
            ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
            ToanThanToc.SinglePlay.prototype.SettingSGP.frame=1;
            setTimeout(function(){
                ToanThanToc.SinglePlay.prototype.bgPopupSound =  ToanThanToc.game.add.image(0,0, 'bgPopupOk');
                ToanThanToc.SinglePlay.prototype.bgPopupSound.inputEnabled=true;
                ToanThanToc.SinglePlay.prototype.bgPopupSound.events.onInputDown.add(ToanThanToc.SinglePlay.prototype.ClickOut);
                ToanThanToc.Menu.prototype.BacgroundForPopup();

                ToanThanToc.SinglePlay.prototype.bgPopupSLP =  ToanThanToc.game.add.image(ToanThanToc.game.world.centerX - 394/2 ,ToanThanToc.game.world.centerY -394/2, 'baseSoloPlay');

                ToanThanToc.SinglePlay.prototype.SettingSGP.frame=0;
                //ToanThanToc.SinglePlay.prototype.SettingSGP.visible=false;


                ToanThanToc.SinglePlay.prototype.btnSettingTiepTucSP = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX - 184 +5,ToanThanToc.game.world.centerY - 268 + 89,'btnSettingTiepTucSP',ToanThanToc.SinglePlay.prototype.ActionClickSetting,ToanThanToc.game,0,0,1);
                ToanThanToc.SinglePlay.prototype.btnSettingKhoiDongSP = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX - 305/2,ToanThanToc.game.world.centerY - 4,'btnSettingKhoiDongSP',ToanThanToc.SinglePlay.prototype.ActionClickSetting,ToanThanToc.game,0,0,1);
                ToanThanToc.SinglePlay.prototype.btnSettingTuyChonSP = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX -6,ToanThanToc.game.world.centerY - 267 + 89 ,'btnSettingTuyChonSP',ToanThanToc.SinglePlay.prototype.ActionClickSetting,ToanThanToc.game,0,0,1);

                ToanThanToc.SinglePlay.prototype.btnSoundSP = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX - 184/2,ToanThanToc.game.world.centerY - 188/2 ,'btnSoundSP',ToanThanToc.SinglePlay.prototype.ActionClickSoundSP,ToanThanToc.game);

                tt.tweenOpenTuyChon=ToanThanToc.game.add.tween( ToanThanToc.SinglePlay.prototype.btnSettingTuyChonSP.scale).to( { x: 1, y: 1 }, 5, Phaser.Easing.Elastic.Out, true);
                tt.tweenOpenTiepTuc=ToanThanToc.game.add.tween( ToanThanToc.SinglePlay.prototype.btnSettingTiepTucSP.scale).to( { x: 1, y: 1 }, 5, Phaser.Easing.Elastic.Out, true);
                tt.tweenOpenKhoiDong=ToanThanToc.game.add.tween( ToanThanToc.SinglePlay.prototype.btnSettingKhoiDongSP.scale).to( { x: 1, y: 1 }, 5, Phaser.Easing.Elastic.Out, true);
                tt.tweenOpenSoundSP=ToanThanToc.game.add.tween( ToanThanToc.SinglePlay.prototype.btnSoundSP.scale).to( { x: 1, y: 1 }, 2, Phaser.Easing.Linear.None, true);

                if(ToanThanToc.music_music.paused) ToanThanToc.SinglePlay.prototype.btnSoundSP.frame=1;
                tt.PauseTimer();
                ToanThanToc.popupShow=1;
            },5);
        }
    },

    ActionClickPUEnd:function(item){
    if(ToanThanToc.SinglePlay.prototype.isNameClick==null)
    {
        if(ToanThanToc.music_touch && SetMusic.touch)
            ToanThanToc.music_popupMainAction.play();
        if(item.key=='btnMenuSGP')
        {
            log(' co vao den nhe tuy chon');
            ToanThanToc.SinglePlay.prototype.isNameClick='btnMenuSGP';

            ToanThanToc.SinglePlay.prototype.arrayMoneyShow=[];
            ToanThanToc.SinglePlay.prototype.TimeScroreAtt=[];
            ToanThanToc.SinglePlay.prototype.ScoreSG=0;
            ToanThanToc.SinglePlay.prototype.SetDefaultMoneyAndEXP();

            ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
            ToanThanToc.SinglePlay.prototype.DeletePopupEndGame();
            ToanThanToc.SinglePlay.prototype.DeletePageSinglePlay();
            SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
            ToanThanToc.game.stage.destroy();
            ToanThanToc.game.state.start('MenuSingle');
        }
        else
        {
            log(' reset choi tiep');
            ToanThanToc.SinglePlay.prototype.isNameClick='btnRedoSGP';

            ToanThanToc.SinglePlay.prototype.arrayMoneyShow=[];
            ToanThanToc.SinglePlay.prototype.TimeScroreAtt=[];
            ToanThanToc.SinglePlay.prototype.ScoreSG=0;
            ToanThanToc.SinglePlay.prototype.CreateArrayShowMoney();
            ToanThanToc.SinglePlay.prototype.SetDefaultMoneyAndEXP();

            ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
            ToanThanToc.SinglePlay.prototype.DeletePopupEndGame();
            ToanThanToc.SinglePlay.prototype.ResetTimer();
            ToanThanToc.SinglePlay.prototype.textScore.setText('0/'+ToanThanToc.soloPlayScore.toString());
            ToanThanToc.SinglePlay.prototype.CreateAminationCountDown();
        }
    }

    },

    /* Animation for Combo */

    animaComboStopped:function(){
        ToanThanToc.SinglePlay.prototype.comboSprite.visible=false;
        ToanThanToc.SinglePlay.prototype.numCombo++;
        if(ToanThanToc.SinglePlay.prototype.ScoreSG.toString()!=ToanThanToc.soloPlayScore.toString())
            ToanThanToc.SinglePlay.prototype.SetInputEnable(true);
    },

    AnimationCombo : function(){
        ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
        ToanThanToc.SinglePlay.prototype.SetFrame(0);
        ToanThanToc.SinglePlay.prototype.animaCombo.onComplete.add(this.animaComboStopped, ToanThanToc.game);
        ToanThanToc.SinglePlay.prototype.animaCombo.play(7, false);
    },

    ClickOut:function(){
        ToanThanToc.SinglePlay.prototype.DeletePopupSetting('');
        ToanThanToc.SinglePlay.prototype.ResumeTimer();
    },

    ActionClickSoundSP : function(item){
        if(ToanThanToc.SinglePlay.prototype.isNameClick==null)
        {
            if (ToanThanToc.SinglePlay.prototype.tweenOpenSoundSP &&  ToanThanToc.SinglePlay.prototype.tweenOpenSoundSP.isRunning)
            {
                return false;
            }
            ToanThanToc.SinglePlay.prototype.isNameClick='SoundMSP';
            if( SetMusic.touch)
                ToanThanToc.music_popupMainAction.play();
            log('  ActionClickSoundSP '+item.key);
            if (ToanThanToc.music_music.isPlaying){
                ToanThanToc.SinglePlay.prototype.btnSoundSP.frame = 1;
                SetMusic.music = false;
                SetMusic.touch = false;
                ToanThanToc.music_music.pause();
                ToanThanToc.SinglePlay.prototype.isNameClick=null;
            }
            else{
                ToanThanToc.SinglePlay.prototype.btnSoundSP.frame = 0 ;
                SetMusic.music = true;
                SetMusic.touch = true;
                ToanThanToc.music_music.resume();
                ToanThanToc.SinglePlay.prototype.isNameClick=null;
            }
        }
    },

    ActionClickSetting : function(item){
        if(ToanThanToc.SinglePlay.prototype.isNameClick==null)
        {
            if (ToanThanToc.SinglePlay.prototype.tweenOpenTiepTuc &&  ToanThanToc.SinglePlay.prototype.tweenOpenTiepTuc.isRunning) return false;
            if (ToanThanToc.SinglePlay.prototype.tweenOpenTuyChon &&  ToanThanToc.SinglePlay.prototype.tweenOpenTuyChon.isRunning) return false;
            if (ToanThanToc.SinglePlay.prototype.tweenOpenKhoiDong &&  ToanThanToc.SinglePlay.prototype.tweenOpenKhoiDong.isRunning) return false;
            if (ToanThanToc.SinglePlay.prototype.tweenOpenSoundSP &&  ToanThanToc.SinglePlay.prototype.tweenOpenSoundSP.isRunning) return false;

            ToanThanToc.popupShow=0;
            log(item.key);
            if( SetMusic.touch )
                ToanThanToc.music_popupMainAction.play();
            if(item.key!='btnSettingTiepTucSP')
            {
                if(ToanThanToc.soloPlayScore!=0)
                {
                    ToanThanToc.SinglePlay.prototype.arrayMoneyShow=[];
                    ToanThanToc.SinglePlay.prototype.TimeScroreAtt=[];
                    ToanThanToc.SinglePlay.prototype.ScoreSG=0;
                    ToanThanToc.SinglePlay.prototype.textScore.setText('0/'+ToanThanToc.soloPlayScore.toString());
                }
                else
                ToanThanToc.SinglePlay.prototype.ScoreSG=0;
            }
            if(item.key=='btnSettingTuyChonSP')
            {
                ToanThanToc.SinglePlay.prototype.btnSettingTuyChonSP.frame=1;
                ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
                ToanThanToc.SinglePlay.prototype.SetDefaultMoneyAndEXP();
                ToanThanToc.SinglePlay.prototype.DeletePopupSetting('btnSettingTuyChonSP');
                ToanThanToc.SinglePlay.prototype.DeletePageSinglePlay();
                SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('MenuSingle');
            }
            else if(item.key=='btnSettingTiepTucSP')
            {
                /*ToanThanToc.SinglePlay.prototype.CreateMultiPointer();*/
                log('234234-22');
                ToanThanToc.SinglePlay.prototype.isNameClick='btnSettingTiepTucSP';
                ToanThanToc.SinglePlay.prototype.DeletePopupSetting('');
                ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
                ToanThanToc.SinglePlay.prototype.CreateQuestion();
                ToanThanToc.SinglePlay.prototype.ResumeTimer();

            }
            else if(item.key=='btnSettingKhoiDongSP')
            {
                log('234234-44');
                ToanThanToc.SinglePlay.prototype.isNameClick='btnSettingKhoiDongSP';
                ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
                ToanThanToc.SinglePlay.prototype.SetDefaultMoneyAndEXP();
                ToanThanToc.SinglePlay.prototype.btnSettingKhoiDongSP.frame=1;
                ToanThanToc.SinglePlay.prototype.DeletePopupSetting('abc');
                ToanThanToc.SinglePlay.prototype.CreateArrayShowMoney();
                ToanThanToc.SinglePlay.prototype.ResetTimer();
                ToanThanToc.SinglePlay.prototype.CreateAminationCountDown();
               /* ToanThanToc.SinglePlay.prototype.DeleteQuestion();*/

            }
        }
    },

    ShowTime:function(textTime){
        ToanThanToc.SinglePlay.prototype.secondsPlay =  textTime;
        var arrTime = ToanThanToc.SinglePlay.prototype.secondsPlay.toString().split('.');
        var hour = (parseInt(arrTime[0]/3600)==0)?0:parseInt(arrTime[0]/3600);
        var mi =   (parseInt((arrTime[0]%3600)/60)==0)?0:parseInt((arrTime[0]%3600)/60);
        var sec =  (parseInt((arrTime[0]%3600)%60)==0)?0:parseInt((arrTime[0]%3600)%60);
        var miSec = (arrTime.length==2)? (arrTime[1].length>2)?arrTime[1]: arrTime[1] : 0 ;
        return (
            (((hour*60 + mi).toString().length==1)?'0'+(hour*60 + mi).toString():(hour*60 + mi).toString())
            +':'+((sec.toString().length==1)?'0'+sec.toString():sec.toString())
            +','+miSec.toString()
            );
    },

    /* Them diem khi tra loi dung hoac tra loi sai */

    SetScorePast:function(bollean){
        if(bollean==false)
        {
            log('vao cho them diem= '+bollean);
            /* next question tru diem */
            shareFunction.actionPlayAudio('wrong');
            if(ToanThanToc.SinglePlay.prototype.ScoreSG!=0)
            {
                log('---------- cau sai tru EXP -------------');
                ToanThanToc.Menu.prototype.exp=ToanThanToc.Menu.prototype.exp - ToanThanToc.MenuSingle.prototype.expPerLevel/ToanThanToc.soloPlayScore;
                ToanThanToc.SinglePlay.prototype.exp.setText(ToanThanToc.Menu.prototype.exp.toString());

                ToanThanToc.SinglePlay.prototype.ScoreSG--;
                if(ToanThanToc.soloPlayScore==0)
                    ToanThanToc.SinglePlay.prototype.textScore.setText(ToanThanToc.SinglePlay.prototype.ScoreSG.toString());
                else
                    ToanThanToc.SinglePlay.prototype.textScore.setText(ToanThanToc.SinglePlay.prototype.ScoreSG.toString()+'/'+ToanThanToc.soloPlayScore.toString());
            }
            setTimeout(function(){
                ToanThanToc.SinglePlay.prototype.TimeScroreAtt=[];
                ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
                ToanThanToc.SinglePlay.prototype.CreateQuestion();
            },80);
        }
        else if(bollean=='T')
        {
            /* + diem next question */
            log('vao cho them diem= '+bollean);
            ToanThanToc.SinglePlay.prototype.ScoreSG++;
            log('ToanThanToc.SinglePlay.prototype.ScoreSG= '+ToanThanToc.SinglePlay.prototype.ScoreSG);
            if(ToanThanToc.soloPlayScore==0)
                ToanThanToc.SinglePlay.prototype.textScore.setText(ToanThanToc.SinglePlay.prototype.ScoreSG.toString());
            else
                ToanThanToc.SinglePlay.prototype.textScore.setText(ToanThanToc.SinglePlay.prototype.ScoreSG.toString()+'/'+ToanThanToc.soloPlayScore.toString());
            setTimeout(function(){
                ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
                ToanThanToc.SinglePlay.prototype.TimeScroreAtt.push(
                    parseFloat(
                        parseFloat(
                                ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds.toFixed(3)-ToanThanToc.SinglePlay.prototype.startTimeQ)
                            .toFixed(3))
                );
                ToanThanToc.SinglePlay.prototype.SetEXPAnswerYes();
                ToanThanToc.SinglePlay.prototype.SetMoneyAnswerYes(ToanThanToc.SinglePlay.prototype.ScoreSG);
                ToanThanToc.SinglePlay.prototype.CheckComboMath();
                log('mang thoi gian tra loi');
                ToanThanToc.SinglePlay.prototype.CreateQuestion();
            },30);
        }
    },

    SetInputEnable:function(bl){
        var SG = ToanThanToc.SinglePlay.prototype;
        SG.num0SG.inputEnabled = bl ;
        SG.num1SG.inputEnabled = bl ;
        SG.num2SG.inputEnabled = bl ;
        SG.num3SG.inputEnabled = bl ;
        SG.num4SG.inputEnabled = bl ;
        SG.num5SG.inputEnabled = bl ;
        SG.num6SG.inputEnabled = bl ;
        SG.num7SG.inputEnabled = bl ;
        SG.num8SG.inputEnabled = bl ;
        SG.num9SG.inputEnabled = bl ;
        SG.numMinusSG.inputEnabled = bl ;
        SG.numClearSG.inputEnabled = bl ;
        SG.SettingSGP.inputEnabled = bl ;
    },

    SetTextAnswer:function(text){
        ToanThanToc.SinglePlay.prototype.textAnswer.setText(text);
        setTimeout(function(){
            ToanThanToc.SinglePlay.prototype.textAnswer.x=
                ToanThanToc.SinglePlay.prototype.questionBoard.width/2 - ToanThanToc.SinglePlay.prototype.textAnswer.width/2  ;
        },6);
    },

    SetFrame:function(int){
        var SG = ToanThanToc.SinglePlay.prototype;
        SG.num0SG.frame = int ;
        SG.num1SG.frame = int ;
        SG.num2SG.frame = int ;
        SG.num3SG.frame = int ;
        SG.num4SG.frame = int ;
        SG.num5SG.frame = int ;
        SG.num6SG.frame = int ;
        SG.num7SG.frame = int ;
        SG.num8SG.frame = int ;
        SG.num9SG.frame = int ;
        SG.numMinusSG.frame = int ;
        SG.numClearSG.frame = int ;
    },

    SetDefaultMoneyAndEXP:function(){
        ToanThanToc.SinglePlay.prototype.numCombo=0;
        ToanThanToc.Menu.prototype.exp=0;//ToanThanToc.infoUserMath.exp;
        ToanThanToc.Menu.prototype.einstein=0;//ToanThanToc.infoUserMath.einstein;
        ToanThanToc.SinglePlay.prototype.exp.setText('0');
        ToanThanToc.SinglePlay.prototype.einstein.setText('0');
    },

    /* them EXP answer yes */
    ArrayDrawEXP:[],
    ArrayDrawMoney:[],

    DrawParabol:function(obj,_x,_y){
      /*   A(aExp.x,aExp.y  ) , I(206,79)*/
        /*
         A.x*A.x*a + A.x*b + c = A.y
         I.x*I.x*a + I.x*b + c = I.y
         2*a*I.x + b=0
         (A.x*A.x - I.x*I.x)a + (A.x - I.x)b = A.y - I.y
         b = -2*a*I.x
         (A.x*A.x - I.x*I.x)a + (A.x - I.x)*(-2*a*I.x) = A.y - I.y
         a=( A.y - I.y)/( (A.x*A.x - I.x*I.x) - (A.x - I.x)*2*I.x)
         */
        obj.x=ToanThanToc.game.rnd.integerInRange(5,700);
        obj.y=ToanThanToc.game.rnd.integerInRange(250,650);
        while(Math.abs(obj.x-206) <100)
        {
            obj.x=ToanThanToc.game.rnd.integerInRange(10,700);
            if(Math.abs(obj.x-206) >100)
                break;
        }
        var arrUse=[];
        var arr=[];
        /// bay tu phai qua trai
        if(obj.x>206){

            for(var i = obj.x;i>210 ;i=i-77){
                arr.push(i);
            }
        }
        /// bay tu trai qua phai
        if(obj.x<206){
            for(var i = obj.x;i<199 ;i=i+77){
                arr.push(i);
            }
        }
        var A = {x:obj.x,y:obj.y};
        var I = {x:_x,y:_y};
       /* log(' cac toa do '+I.x+  '  '+I.y+'  '+ A.x +'  '+ A.y );*/
        var aa = parseFloat( (A.y - I.y)/( (A.x*A.x - I.x*I.x) - (A.x - I.x)*2*I.x)).toFixed(5) ;
        var bb=-2*aa*I.x;
        var cc=I.y - I.x*I.x*aa - I.x*bb;
        for( var u=0;u<arr.length;u++ )
        {
            arrUse.push({x:arr[u], y:aa*arr[u]*arr[u] + bb*arr[u] +cc });
        }
        return arrUse;
    },

    timerEXP:null,
    timerEinstein:null,
    SetEXPAnswerYes:function(){
        ToanThanToc.SinglePlay.prototype.aExp.visible=true;
        ToanThanToc.SinglePlay.prototype.timerEXP = ToanThanToc.game.time.create(false);
        ToanThanToc.SinglePlay.prototype.timerEXP.loop(ToanThanToc.timeMoneyEinStein, this.MoveTimeTweenEXPimg, ToanThanToc.game);
        ToanThanToc.SinglePlay.prototype.timerEXP.start();
    },

    /* them Money answer yes */
    TestIndexShowMoney:function(arr,item){
        for(var k=0;k<arr.length;k++)
        {
            if(item==arr[k])
            {
                arr[k]=-11;
                return true;
                break;
            }
        }
        return false;
    },

    SetMoneyAnswerYes:function(score){
        //276,34
        if(ToanThanToc.SinglePlay.prototype.TestIndexShowMoney(ToanThanToc.SinglePlay.prototype.arrayMoneyShow,score)){
            ToanThanToc.SinglePlay.prototype.aEinstein.visible=true;
            ToanThanToc.SinglePlay.prototype.timerEinstein = ToanThanToc.game.time.create(false);
            ToanThanToc.SinglePlay.prototype.timerEinstein.loop(ToanThanToc.timeMoneyEinStein, this.MoveTimeTweenEinstein, ToanThanToc.game);
            ToanThanToc.SinglePlay.prototype.timerEinstein.start();
        }
    },

    CheckTrueFalseAnswer:function(answer,stt){
        log('CheckTrueFalseAnswer');
        var arrAs = (answer.length==1)?answer:answer.split("");
        //log(arrAs);
        //log(ToanThanToc.SinglePlay.prototype.arrDA);
        if(answer.length==1)
        {
            if(ToanThanToc.SinglePlay.prototype.arrDA[0].toString()==arrAs && ToanThanToc.SinglePlay.prototype.arrDA.length!=arrAs.length)
                return true;
            else if(ToanThanToc.SinglePlay.prototype.arrDA[0].toString()==arrAs && ToanThanToc.SinglePlay.prototype.arrDA.length==arrAs.length)
            {
                log('cac cau dung roi');
                ToanThanToc.SinglePlay.prototype.SetScorePast('T');
                return false;
            }
        }
        else{
            log(stt);
            if((ToanThanToc.SinglePlay.prototype.arrDA[stt].toString()==arrAs[stt].toString())&&ToanThanToc.SinglePlay.prototype.arrDA.length!=arrAs.length)
                return true;
            else if((ToanThanToc.SinglePlay.prototype.arrDA[stt].toString()==arrAs[stt].toString())&&ToanThanToc.SinglePlay.prototype.arrDA.length==arrAs.length)
            {
                log('dung nhieu cac so');
                ToanThanToc.SinglePlay.prototype.SetScorePast('T');
                return false;
            }
        }
        ToanThanToc.SinglePlay.prototype.SetScorePast(false);
    },

    /*  kiem tra combo */
    CheckComboMath:function(){
        var singles =ToanThanToc.SinglePlay.prototype;
        log(singles.TimeScroreAtt);
        if( singles.TimeScroreAtt.length>= ToanThanToc.MenuSingle.prototype.excellenceQuestion)
        {
            log('do dai lon hon so cau');
            var l = singles.TimeScroreAtt.length;
            if(singles.TimeScroreAtt[l-1]<ToanThanToc.MenuSingle.prototype.excellenceTime/1000 &&
               singles.TimeScroreAtt[l-2]<ToanThanToc.MenuSingle.prototype.excellenceTime/1000 &&
               singles.TimeScroreAtt[l-3]<ToanThanToc.MenuSingle.prototype.excellenceTime/1000
            )
            {
                ToanThanToc.SinglePlay.prototype.comboSprite.visible=true;
                log('co combo moi hehe co combo moi hehe co combo moi hehe co combo moi hehe');
                singles.TimeScroreAtt=[];
                singles.AnimationCombo();
            }
        }
        if( singles.TimeScroreAtt.length>=3){  singles.TimeScroreAtt=[]; }
    },
    idEXP:0,
    idEinStein:0,

    OnCompleteTweenEXPimg:function(){
        shareFunction.actionPlayAudio('right');
        ToanThanToc.Menu.prototype.exp=ToanThanToc.Menu.prototype.exp + ToanThanToc.MenuSingle.prototype.expPerLevel/ToanThanToc.soloPlayScore;
        ToanThanToc.SinglePlay.prototype.exp.setText(ToanThanToc.Menu.prototype.exp.toString());

        if(ToanThanToc.soloPlayScore!=0)
            if(ToanThanToc.SinglePlay.prototype.OffGameScore()==false)
                return false;

        ToanThanToc.SinglePlay.prototype.aExp.visible=false;
        ToanThanToc.SinglePlay.prototype.aExp.x=206;
        ToanThanToc.SinglePlay.prototype.aExp.y=79;
        if(ToanThanToc.SinglePlay.prototype.ScoreSG.toString()!=ToanThanToc.soloPlayScore.toString())
            ToanThanToc.SinglePlay.prototype.SetInputEnable(true);
        ToanThanToc.SinglePlay.prototype.ArrayDrawEXP=[];
        ToanThanToc.SinglePlay.prototype.ArrayDrawEXP = ToanThanToc.SinglePlay.prototype.DrawParabol(
            ToanThanToc.SinglePlay.prototype.aExp,206,79);
    },

    OnCompleteTweenEinSteinimg:function(){
        shareFunction.actionPlayAudio('right');
        ToanThanToc.Menu.prototype.einstein=  ToanThanToc.Menu.prototype.einstein  + 1;
        ToanThanToc.SinglePlay.prototype.einstein.setText(ToanThanToc.Menu.prototype.einstein.toString());

        ToanThanToc.SinglePlay.prototype.aEinstein.visible=false;
        ToanThanToc.SinglePlay.prototype.aEinstein.x=206;
        ToanThanToc.SinglePlay.prototype.aEinstein.y=13;
        if(ToanThanToc.SinglePlay.prototype.ScoreSG.toString()!=ToanThanToc.soloPlayScore.toString())
            ToanThanToc.SinglePlay.prototype.SetInputEnable(true);
        ToanThanToc.SinglePlay.prototype.ArrayDrawMoney=[];
        ToanThanToc.SinglePlay.prototype.ArrayDrawMoney = ToanThanToc.SinglePlay.prototype.DrawParabol(
            ToanThanToc.SinglePlay.prototype.aEinstein,206,13);
    },

    MoveTimeTweenEXPimg:function(){
        log('123123');
        ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
        if(ToanThanToc.SinglePlay.prototype.idEXP==ToanThanToc.SinglePlay.prototype.ArrayDrawEXP.length) {
            ToanThanToc.SinglePlay.prototype.idEXP=0;
            ToanThanToc.SinglePlay.prototype.TweenEndEXP= ToanThanToc.game.add.tween(ToanThanToc.SinglePlay.prototype.aExp)
                .to({  x:206, y:79 }, ToanThanToc.timeMoneyEinStein,Phaser.Easing.Cubic.Out,true);
            ToanThanToc.SinglePlay.prototype.TweenEndEXP.onComplete.add(ToanThanToc.SinglePlay.prototype.OnCompleteTweenEXPimg);
            ToanThanToc.SinglePlay.prototype.timerEXP.stop();
            ToanThanToc.SinglePlay.prototype.timerEXP.destroy();
            return false;
        }
        ToanThanToc.game.add.tween(ToanThanToc.SinglePlay.prototype.aExp)
            .to({ x: ToanThanToc.SinglePlay.prototype.ArrayDrawEXP[ToanThanToc.SinglePlay.prototype.idEXP].x,
                y:ToanThanToc.SinglePlay.prototype.ArrayDrawEXP[ToanThanToc.SinglePlay.prototype.idEXP].y },
            ToanThanToc.timeMoneyEinStein ,Phaser.Easing.Cubic.Out,true);
        ToanThanToc.SinglePlay.prototype.idEXP++;
    },

    MoveTimeTweenEinstein:function(){
        log('move Einstein');
        ToanThanToc.SinglePlay.prototype.SetInputEnable(false);
        if(ToanThanToc.SinglePlay.prototype.idEinStein==ToanThanToc.SinglePlay.prototype.ArrayDrawMoney.length) {
            ToanThanToc.SinglePlay.prototype.idEinStein=0;
            ToanThanToc.SinglePlay.prototype.TweenEndEinstein= ToanThanToc.game.add.tween(ToanThanToc.SinglePlay.prototype.aEinstein)
                .to({  x:206, y:13 }, ToanThanToc.timeMoneyEinStein,Phaser.Easing.Cubic.Out,true);
            ToanThanToc.SinglePlay.prototype.TweenEndEinstein.onComplete.add(ToanThanToc.SinglePlay.prototype.OnCompleteTweenEinSteinimg);
            ToanThanToc.SinglePlay.prototype.timerEinstein.stop();
            ToanThanToc.SinglePlay.prototype.timerEinstein.destroy();
            return false;
        }
        ToanThanToc.game.add.tween(ToanThanToc.SinglePlay.prototype.aEinstein)
            .to({ x: ToanThanToc.SinglePlay.prototype.ArrayDrawMoney[ToanThanToc.SinglePlay.prototype.idEinStein].x,
                y:ToanThanToc.SinglePlay.prototype.ArrayDrawMoney[ToanThanToc.SinglePlay.prototype.idEinStein].y },
            ToanThanToc.timeMoneyEinStein ,Phaser.Easing.Cubic.Out,true);
        ToanThanToc.SinglePlay.prototype.idEinStein++;
    },

    DeletePopupSetting:function(text){
        if(text=='btnTryPPSGCh'){
            setTimeout(function(){
                ToanThanToc.SinglePlay.prototype.bgPPDelChConfirm.destroy();
                ToanThanToc.SinglePlay.prototype.bgWinnerChall.destroy();
            },10);
            return false;
        }
        ToanThanToc.popupShow=0;
        ToanThanToc.SinglePlay.prototype.bgPopupSound.destroy();
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        ToanThanToc.SinglePlay.prototype.bgPopupSLP.destroy();
        ToanThanToc.SinglePlay.prototype.btnSoundSP.destroy();
        ToanThanToc.SinglePlay.prototype.SetInputEnable(true);
        setTimeout(function(){
            ToanThanToc.SinglePlay.prototype.btnSettingTuyChonSP.destroy();
            ToanThanToc.SinglePlay.prototype.btnSettingTiepTucSP.destroy();
            ToanThanToc.SinglePlay.prototype.btnSettingKhoiDongSP.destroy();
            ToanThanToc.SinglePlay.prototype.SettingSGP.visible=true;
            ToanThanToc.SinglePlay.prototype.isNameClick=null;
            ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
            if(text=='')
                ToanThanToc.SinglePlay.prototype.CreateQuestion();
        },6);

    },

    DeleteQuestionAndAnswer:function(){
        ToanThanToc.SinglePlay.prototype.textQuestion.setText('');
        ToanThanToc.SinglePlay.prototype.textAnswer.setText('');
        ToanThanToc.SinglePlay.prototype.dapAn='';
        ToanThanToc.SinglePlay.prototype.lanthu=0;
    },

    DeletePopupEndGame:function(){
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        setTimeout(function(){
            ToanThanToc.SinglePlay.prototype.bgPPSL.destroy();
            ToanThanToc.SinglePlay.prototype.popupEndGameSGP.destroy();
        },6);
    },

    DeletePageSinglePlay:function(){
        var SG = ToanThanToc.SinglePlay.prototype;
        SG.num0SG.destroy();
        SG.num1SG.destroy();
        SG.num2SG.destroy();
        SG.num3SG.destroy();
        SG.num4SG.destroy();
        SG.num5SG.destroy();
        SG.num6SG.destroy();
        SG.num7SG.destroy();
        SG.num8SG.destroy();
        SG.num9SG.destroy();
        SG.numMinusSG.destroy();
        SG.numClearSG.destroy();
        SG.avatarUserMath.destroy();
        SG.woodBoard.destroy();
        SG.questionBoard.destroy();
        SG.SettingSGP.destroy();
        SG.aEinstein.destroy();
        SG.aExp.destroy();
        SG.comboSprite.destroy();
    },

    CloseWindow : function() {
        ToanThanToc.popupShow=0;
        ToanThanToc.SinglePlay.prototype.bgPPSL.destroy();
        ToanThanToc.SinglePlay.prototype.btnOkPlaySG.destroy();
        ToanThanToc.SinglePlay.prototype.bgPopupSound.destroy();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.SinglePlay.prototype.isNameClick=null;
        ToanThanToc.SinglePlay.prototype.CreateAminationCountDown();
    },

    SendScoreMathSingle:function(ta) {
        var oparation=0;
        var arrPheptinh = [ToanThanToc.plusSolo,ToanThanToc.minusSolo,ToanThanToc.multiSolo,ToanThanToc.divisionSolo];
        if(arrPheptinh[0])
            oparation='1';
        else
            oparation='0';
        if(arrPheptinh[1])
            oparation=oparation+'1';
        else
            oparation=oparation+'0';
        if(arrPheptinh[2])
            oparation=oparation+'1';
        else
            oparation=oparation+'0';
        if(arrPheptinh[3])
            oparation=oparation+'1';
        else
            oparation=oparation+'0';
        log('oparation '+oparation);
        log('timeEndSave '+ToanThanToc.SinglePlay.prototype.timeEndSave);
        if(ToanThanToc.SinglePlay.prototype.playSingleId!='')
        {
            AcceptMatchScore(function(data){
                    if(data=='erro')
                    {
                        ToanThanToc.SinglePlay.prototype.CreatePopupEndGame();
                    }
                    else if(data.success=='WIN'){
                        ToanThanToc.SinglePlay.prototype.CreatePopupWinChallenge();
                    }
                    else if(data.success=='FAIL'){
                        ToanThanToc.SinglePlay.prototype.CreatePopupFailChallenge();
                    }
                }
                ,ToanThanToc.SinglePlay.prototype.playSingleId
                ,(ta=='')?parseInt(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds * 1000):ToanThanToc.PlayerChall[ToanThanToc.challengeIndex].time*2
            );
        }
        else
        {
            var postScorceMathSingle = ToanThanToc.db.query({api: '/math/score/', data:
                {
                    'mode':ToanThanToc.isLevelSolo.toUpperCase(),
                    'operator':oparation,
                    'time': parseInt(ToanThanToc.SinglePlay.prototype.timmer.game.time.events.seconds * 1000),
                    'combo':ToanThanToc.SinglePlay.prototype.numCombo*ToanThanToc.MenuSingle.prototype.excellenceCombo
                },
                    headers : {'x-auth-token': ToanThanToc.MyToken}}
            );
            postScorceMathSingle.success(function(data){
                log('Luu diem thanh cong ok ok ok');
                GetUserMathInfor(function(UserMathInfo){
                    log("callback called UserMathInfor! " + JSON.stringify(UserMathInfo));
                    // success call UserMathInfo
                    ToanThanToc.Menu.prototype.SetInforUser();
                    if(ToanThanToc.Menu.prototype.energy<ToanThanToc.energyConf)
                    {
                        //   show popup die energy
                        ToanThanToc.Menu.prototype.CreatePopupDieEnergy();
                        return false;
                    }
                    ToanThanToc.SinglePlay.prototype.CreatePopupEndGame();
                });
            });
            postScorceMathSingle.error(function(data){
                log('Luu diem ko ok');
                ToanThanToc.SinglePlay.prototype.CreatePopupEndGame();
            });
        }

    }
};

function AcceptChallenge(callback,id){
    ToanThanToc.db.setAtuthToken(ToanThanToc.MyToken);
    var  postAcceptChallenge = ToanThanToc.db.query({api: '/math/acceptchallenge/', data:{challengeid:id},
            headers : {'x-auth-token': ToanThanToc.MyToken}}
    );
    postAcceptChallenge.success(function(data){
        callback(data);
    });
    postAcceptChallenge.error(function(data){
        callback('erro');
    });
}

function AcceptMatchScore(callback,id,times){
    ToanThanToc.db.setAtuthToken(ToanThanToc.MyToken);
    var  postMatchScore = ToanThanToc.db.query({api: '/math/matchscore/', data:{matchid:id,time:times},
            headers : {'x-auth-token': ToanThanToc.MyToken}}
    );
    postMatchScore.success(function(data){
        log('--------- postMatchScore  --------');
        log(data);
        callback(data);
    });
    postMatchScore.error(function(data){
        callback('erro');
    });
}