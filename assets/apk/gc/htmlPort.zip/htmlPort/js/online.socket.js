"use strict";

var Socket = {
    /**
     *
     * @param {Function} callback
     * @returns {*}
     */
    execute:function(callback){
        console.log('call socket');
        SocketNahi.connect(null, callback);
    },
    connect:function(){
            //console.log('=============================connect socket=============================');
            //console.log(ToanThanToc.socket);
            //console.log('namespace '+ToanThanToc.nameSpace);
            /** Listener create room */
            ToanThanToc.socket.on('MATH:ROOM:CREATE', function(dataCreateRoom){

                if(ToanThanToc.nameSpace == 'chooseRoom') {
                    console.log('co room moi tao');
                    ToanThanToc.OnlineRoomChoose.prototype.actionOnClickFreeRoom();
                }
            });

            /** Listener watch room */
            ToanThanToc.socket.on('MATH:ROOM:WATCH', function(dataWatchRoom){
                console.log('data watch room: ');
                console.log(JSON.stringify(dataWatchRoom));
                //console.log("name space "+ToanThanToc.nameSpace);
                //console.log('thoi xong!');
                if(ToanThanToc.nameSpace == 'waitingRoom'){
                    ToanThanToc.dataWatchRoom = dataWatchRoom;
                    ToanThanToc.OnlineRoomWaiting.prototype.watchRoom(dataWatchRoom);
                }else if(ToanThanToc.nameSpace == 'chooseRoom'){
//                    log((dataWatchRoom.players).length);
                    for(var i=0;i<(dataWatchRoom.players).length;i++)
                    {
                        ToanThanToc.dataAvatar.push(
                            [dataWatchRoom.players[i].avatar_url,dataWatchRoom.players[i].id]

                        );

                    }
                    for(var i=0;i<(dataWatchRoom.viewers).length;i++)
                    {

                        ToanThanToc.dataAvatar.push(
                            [dataWatchRoom.viewers[i].avatar_url,dataWatchRoom.viewers[i].id]

                        );

                    }

                    ToanThanToc.nameSpace = 'waitingRoom';
                    ToanThanToc.OnlineRoomWaiting.prototype.dataWaitingRoom = dataWatchRoom;
                    ToanThanToc.game.state.start("OnlineRoomWaiting");
                }
            });

            /** Listener join room */
            ToanThanToc.socket.on('MATH:ROOM:JOIN', function(dataJoinRoom){
                console.log('data join room: ');
                console.log(JSON.stringify(dataJoinRoom));
                //console.log("name space "+ToanThanToc.nameSpace);
                if(ToanThanToc.nameSpace == 'waitingRoom'){
                    ToanThanToc.dataWatchRoom = dataJoinRoom;
                    ToanThanToc.OnlineRoomWaiting.prototype.watchRoom(dataJoinRoom);
                }else if(ToanThanToc.nameSpace == 'play'){
                    for(var i=0;i<(dataJoinRoom.players).length;i++)
                    {
                        ToanThanToc.dataAvatar.push(
                            [dataJoinRoom.players[i].avatar_url,dataJoinRoom.players[i].id]
                        );
                    }
                    for(var i=0;i<(dataJoinRoom.viewers).length;i++)
                    {
                        ToanThanToc.dataAvatar.push(
                            [dataJoinRoom.viewers[i].avatar_url,dataJoinRoom.viewers[i].id]
                        );
                    }
                    ToanThanToc.data = {id: dataJoinRoom.id, password: null};
                    ToanThanToc.nameSpace = 'waitingRoom';
                    ToanThanToc.OnlineRoomWaiting.prototype.dataWaitingRoom = dataJoinRoom;
                    ToanThanToc.game.state.start("OnlineRoomWaiting");
                }
            });

            /** Listener unJoin room */
            ToanThanToc.socket.on('MATH:ROOM:UNJOIN', function(dataUnJoinRoom){
                console.log('unjoin room ');
                console.log(JSON.stringify(dataUnJoinRoom));
                if(ToanThanToc.nameSpace == 'waitingRoom'){
                    ToanThanToc.OnlineRoomWaiting.prototype.watchRoom(dataUnJoinRoom);
                }


            });


            /** Listener leave room */
            ToanThanToc.socket.on('MATH:ROOM:LEAVE', function(dataLeaveRoom){
                console.log('Leave room data ');
                console.log(JSON.stringify(dataLeaveRoom));

                if(ToanThanToc.nameSpace == 'waitingRoom'){
                    ToanThanToc.OnlineRoomWaiting.prototype.watchRoom(dataLeaveRoom);
                }
            });


            /** Listener disable room */
            ToanThanToc.socket.on('MATH:ROOM:DISABLE', function(dataDisableRoom){
                console.log('disable room '+JSON.stringify(dataDisableRoom));
                    if(ToanThanToc.nameSpace == 'waitingRoom'){
                        ToanThanToc.game.stage.destroy();
                        ToanThanToc.game.state.start("OnlineRoomChoose");
                        ToanThanToc.nameSpace = 'chooseRoom';
                    }
            });


            /** Listener start game */
            ToanThanToc.socket.on('MATH:ROOM:START',function(dataNewGame){

                /* If current screen is the detailRoom */
                if(ToanThanToc.nameSpace == 'waitingRoom'){
                    /** Check id user */
//                    if(Socket.checkId(dataNewGame.playboards) == true){ // if user is a player.
                        // Start room playing
                        //console.log('Create room playing');
                        if(dataNewGame){
                            ToanThanToc.dataQuestionTemp = dataNewGame;
                            ToanThanToc.OnlineRoomWaiting.prototype.createNumberCountDown(Socket.checkId(dataNewGame.playboards) );
                        }else{
                            //console.log('Listening new game on screen waitingRoom '+ JSON.stringify(dataNewGame));
                        }
//                    }else{ /** user is a viewer */
//                        // Start user view
//                    //console.log('Create user view');
//                        if(dataNewGame){
//                            ToanThanToc.OnlineUserView.prototype.destroy();
//                            ToanThanToc.game.stage.destroy();
//                            ToanThanToc.dataQuestionTemp = dataNewGame;
//                            ToanThanToc.game.state.start("OnlineUserView");
//                            ToanThanToc.nameSpace = 'userView';
//                        }else{
//                            //console.log('Listening new game on screen waitingRoom '+ JSON.stringify( dataNewGame));
//                        }
//                    }

                }else{

                }
            });


            /** Listener new score */
            ToanThanToc.socket.on('MATH:ROOM:NEWSCORE',function(dataNewScore){
                /* if current screen is the userView */
                if(ToanThanToc.nameSpace == 'userView'){
                    if(dataNewScore){
                        ToanThanToc.OnlineUserView.prototype.userViewUpdateNewScore(dataNewScore);
                    }else{
                        //console.log('Listening new score on screen UserView '+ JSON.stringify(dataNewScore));
                    }
                }else if(ToanThanToc.nameSpace == 'roomPlaying'){ // If screen is the playing.
                    if(dataNewScore){
                        ToanThanToc.OnlinePlayingRoom.prototype.roomPlayingUpdateNewScore(dataNewScore);
                    }else{
                        //console.log('Listening new score screen on RoomPlaying '+ JSON.stringify(dataNewScore));
                    }
                }else{

                }
            });


            /**
            * Listener endgame.
            */
            ToanThanToc.socket.on('MATH:ROOM:FINISHGAME',function(dataEndGame){
                console.log('dataEndGame trigger.');
                console.log(dataEndGame);
                /* if screen userView */
                if(ToanThanToc.nameSpace == 'userView'){
                    if(dataEndGame){
                        ToanThanToc.OnlineUserView.prototype.userViewListenerEndGame(dataEndGame);
                    }else{
                        //console.log('Listening end game screen UserView '+ JSON.stringify(dataEndGame));
                    }
                }else if(ToanThanToc.nameSpace == 'roomPlaying'){ // If screen playing.
                    if(dataEndGame){
                        ToanThanToc.OnlinePlayingRoom.prototype.roomPlayingListenerCloseGame(dataEndGame);
                    }else{
                        //console.log('Listening end game screen RoomPlaying '+ JSON.stringify(dataEndGame));
                    }
                }
            });


            ToanThanToc.socket.on('MATH:ROOM:MISSCORE',function(dataMissScore){
                console.log('dataMissScore trigger.');
                console.log(dataMissScore);
                if(ToanThanToc.nameSpace == 'userView'){
                    if(dataMissScore){
                        ToanThanToc.OnlineUserView.prototype.userViewUpdateNewScore(dataMissScore);
                    }else{
                        //console.log('Listening new score on screen UserView '+ JSON.stringify(dataNewScore));
                    }
                }else if(ToanThanToc.nameSpace == 'roomPlaying'){ // If screen is the playing.
                    if(dataMissScore){
                        ToanThanToc.OnlinePlayingRoom.prototype.roomPlayingUpdateNewScore(dataMissScore);
                    }else{
                        //console.log('Listening new score screen on RoomPlaying '+ JSON.stringify(dataNewScore));
                    }
                }else{

                }
            });

            ToanThanToc.socket.on('MATH:ROOM:RESETROOM',function(dataResetRoom){
                console.log('dataResetRoom');
                console.log(dataResetRoom);
                ToanThanToc.OnlineRoomWaiting.prototype.dataWaitingRoom = dataResetRoom;
            });




            ///** Disconnect. */
            //ToanThanToc.socket.on('disconnect',function(){
            //
            //});

        //});
    },
    /**
     * Check user
     * @param data
     * @returns {boolean}
     */
    checkId:function(data){
        var i = 0;
        for(i;i<data.length;++i){
            var j = 0;
            for(j;j<data[i].players.length;++j){
                if(ToanThanToc.myId == data[i].players[j].id){
                    return true;
                }
            }
        }
        return false;
    },

    getProfile: function(){
        var login = ToanThanToc.db.query({
            api: '/user/me',
            data: {
            },
            headers: {'x-auth-token': xAuthToken}
        });


        login.success(function (data) {
            //console.log('get profile '+ JSON.stringify(data));
            ToanThanToc.myId = data.id;
        });

        login.error(function (data) {
            //log('error + ' + data);
        });

    },

    checkIDResutl:function(data){
        var i=0;
        for(i;i<data.players.length;i++){
            if(ToanThanToc.myId == data.players[i].id){
                return true;
            }
        }
        return false;
    }

};

/**
 * Connect socket.
 */
//Socket.connect();
ToanThanToc.socket = SocketNahi.connect(null, Socket.connect);
