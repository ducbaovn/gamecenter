/**
 * Created by thanhpt from NAHI on 1/10/2015.
 * @Author: tpt2213
 */
ToanThanToc.EndSoloPlay = function(game){

};

ToanThanToc.EndSoloPlay.prototype = {

    tweenOpenPlay:null,

    preload : function() {
        ToanThanToc.popupShow=0;
    },
    create : function() {
        ToanThanToc.game.input.maxPointers = 1;
        ToanThanToc.isEndSolo=false;

        ToanThanToc.EndSoloPlay.prototype.multiBoardFull=ToanThanToc.game.add.sprite(0, ToanThanToc.game.world.centerY - 299/2 ,'multiBoardFull');

        ToanThanToc.EndSoloPlay.prototype.texTimeDesT = ToanThanToc.game.add.bitmapText(
            735,570,'num',
            (ToanThanToc.soloPlayScore!=0)? ToanThanToc.SoloPlay.prototype.secondsPlay:'00:'+ ToanThanToc.soloPlayTime.toString()+',000'
            ,40);
        ToanThanToc.EndSoloPlay.prototype.texTimeDesT.rotation=3.14;

        ToanThanToc.EndSoloPlay.prototype.texTimeDesB = ToanThanToc.game.add.bitmapText(
            65,660,'num',
            (ToanThanToc.soloPlayScore!=0)? ToanThanToc.SoloPlay.prototype.secondsPlay:'00:'+ ToanThanToc.soloPlayTime.toString()+',000'
            ,40);

        /*ToanThanToc.EndSoloPlay.prototype.CreateTimePlay();*/
        ToanThanToc.SoloPlay.prototype.AddThemDiemOTren();
        ToanThanToc.SoloPlay.prototype.AddThemDiemODuoi();
        ToanThanToc.EndSoloPlay.prototype.CreatSettingPopup();
        ToanThanToc.EndSoloPlay.prototype.TestWinLose();

        ToanThanToc.music_win.play();
    },

    miT:null,
    secT:null,
    miSecT:null,
    miB:null,
    secB:null,
    miSecB:null,

    CreateTimePlay:function(){
        var font = 'bold 20px Segoe UI';
        var bb = ToanThanToc.EndSoloPlay.prototype;

/*        ToanThanToc.EndSoloPlay.prototype.bangsoT = ToanThanToc.game.add.image( ToanThanToc.game.world.width - 647,ToanThanToc.game.world.centerY - 283 ,'bgTimeSL');
        ToanThanToc.EndSoloPlay.prototype.bangsoT.rotation=3.14;
        ToanThanToc.EndSoloPlay.prototype.bangsoT.x = ToanThanToc.game.world.width -10;
        ToanThanToc.EndSoloPlay.prototype.bangsoT.y = ToanThanToc.game.world.centerY - 34;

        ToanThanToc.EndSoloPlay.prototype.bangsoB = ToanThanToc.game.add.image( 5,ToanThanToc.game.world.centerY + 283,'bgTimeSL');
        ToanThanToc.EndSoloPlay.prototype.bangsoB.y = ToanThanToc.game.world.centerY + 45 ;*/

        ToanThanToc.SoloPlay.prototype.secondsPlay = ToanThanToc.SoloPlay.prototype.secondsPlay.toFixed(3);
        var arrTime = ToanThanToc.SoloPlay.prototype.secondsPlay.toString().split('.');
        var hour = parseInt(arrTime[0]/3600);
        var mi =   parseInt((arrTime[0]%3600)/60);
        var sec =  parseInt((arrTime[0]%3600)%60);
        var miSec = (arrTime.length==2)? (arrTime[1].length>2)?arrTime[1]: arrTime[1]+'0' : 0 ;

        log(ToanThanToc.SoloPlay.prototype.secondsPlay);


        bb.miT = ToanThanToc.game.add.text(110,23,
                (((hour*60 + mi).toString().length==1)?'0'+(hour*60 + mi).toString():(hour*60 + mi).toString()) + ' '+'  Phút'
            ,{fill:'#ffffff',font:font,align:'center'});
        if(ToanThanToc.soloPlayTime!=0)
            bb.secT = ToanThanToc.game.add.text(110,46, ToanThanToc.soloPlayTime.toString()+ ' '+'  Giây',{fill:'#ffffff',font:font,align:'center'});
        else
            bb.secT = ToanThanToc.game.add.text(110,46, ((sec.toString().length==1)?'0'+sec.toString():sec.toString())+ ' '+'  Giây',{fill:'#ffffff',font:font,align:'center'});

        bb.miSecT = ToanThanToc.game.add.text(110,70,
            (ToanThanToc.soloPlayTime!=0)?'00  mili giây' : miSec.toString()+ ' '+'  mili giây',
            {fill:'#ffffff',font:font,align:'center'});
       /* ToanThanToc.EndSoloPlay.prototype.bangsoT.addChild(bb.miT);
        ToanThanToc.EndSoloPlay.prototype.bangsoT.addChild(bb.secT);
        ToanThanToc.EndSoloPlay.prototype.bangsoT.addChild(bb.miSecT);*/

        bb.miB = ToanThanToc.game.add.text(110,23,
                (((hour*60 + mi).toString().length==1)?'0'+(hour*60 + mi).toString():(hour*60 + mi).toString()) + ' '+'  Phút'
            ,{fill:'#ffffff',font:font,align:'center'});
        if(ToanThanToc.soloPlayTime!=0)
            bb.secB = ToanThanToc.game.add.text(110,46, ToanThanToc.soloPlayTime.toString()+ ' '+'  Giây',{fill:'#ffffff',font:font,align:'center'});
        else
            bb.secB = ToanThanToc.game.add.text(110,46,((sec.toString().length==1)?'0'+sec.toString():sec.toString())+ ' '+'  Giây',{fill:'#ffffff',font:font,align:'center'});

        bb.miSecB = ToanThanToc.game.add.text(110,70,
            (ToanThanToc.soloPlayTime!=0)?'00  mili giây' : miSec.toString()+ ' '+'  mili giây',
            {fill:'#ffffff',font:font,align:'center'});
       /* ToanThanToc.EndSoloPlay.prototype.bangsoB.addChild(bb.miB);
        ToanThanToc.EndSoloPlay.prototype.bangsoB.addChild(bb.secB);
        ToanThanToc.EndSoloPlay.prototype.bangsoB.addChild(bb.miSecB);
*/

    },

    render:function() {
        if(SetMusic.music==true&&ToanThanToc.music_win.isPlaying==false&&
            ToanThanToc.EndSoloPlay.prototype.amThanh==false&&ToanThanToc.music_music.isPlaying==false)
        {
            if(ToanThanToc.music_music.isPlaying==true)
                ToanThanToc.EndSoloPlay.prototype.amThanh = true;
            ToanThanToc.music_music.restart();
        }
    },

    amThanh:false,

    update : function() {

    },

    TestWinLose: function(){
        /// play 1 thang
        if(ToanThanToc.scoreTam1>ToanThanToc.scoreTam2)
        {
            ToanThanToc.EndSoloPlay.prototype.ActionAmi1(ToanThanToc.SoloPlay.prototype.animalNum1+'Win');
            ToanThanToc.EndSoloPlay.prototype.ActionAmi2(ToanThanToc.SoloPlay.prototype.animalNum2+'Lose');
            ToanThanToc.EndSoloPlay.prototype.ActionAmiT('imgWinnerSL');
            ToanThanToc.EndSoloPlay.prototype.ActionAmiB('imgLoserSL');
        }
        /// play 2 thang
        else if(ToanThanToc.scoreTam1<ToanThanToc.scoreTam2)
        {
            ToanThanToc.EndSoloPlay.prototype.ActionAmi1(ToanThanToc.SoloPlay.prototype.animalNum1+'Lose');
            ToanThanToc.EndSoloPlay.prototype.ActionAmi2(ToanThanToc.SoloPlay.prototype.animalNum2+'Win');
            ToanThanToc.EndSoloPlay.prototype.ActionAmiT('imgLoserSL');
            ToanThanToc.EndSoloPlay.prototype.ActionAmiB('imgWinnerSL');
        }
        else if(ToanThanToc.scoreTam1==ToanThanToc.scoreTam2){
            ToanThanToc.EndSoloPlay.prototype.ActionAmi1(ToanThanToc.SoloPlay.prototype.animalNum1+'Tie');
            ToanThanToc.EndSoloPlay.prototype.ActionAmi2(ToanThanToc.SoloPlay.prototype.animalNum2+'Tie');
            ToanThanToc.EndSoloPlay.prototype.ActionAmiT('hoaRoiSL');
            ToanThanToc.EndSoloPlay.prototype.ActionAmiB('hoaRoiSL');
        }
    },

    ActionAmi1 : function(text){
        ToanThanToc.SoloPlay.prototype.animalImage11 = ToanThanToc.game.add.sprite(160, 160,  text);
        ToanThanToc.SoloPlay.prototype.animalImage11.rotation=3.14;
        ToanThanToc.SoloPlay.prototype.animalImage11.animations.add('walk');
        ToanThanToc.SoloPlay.prototype.animalImage11.animations.play('walk', 3, true);

    },
    ActionAmi2 : function(text){
        ToanThanToc.SoloPlay.prototype.animalImage22 = ToanThanToc.game.add.sprite(ToanThanToc.game.world.width -158,ToanThanToc.game.world.height-158,  text);
        ToanThanToc.SoloPlay.prototype.animalImage22.animations.add('walk');
        ToanThanToc.SoloPlay.prototype.animalImage22.animations.play('walk', 3, true);
    },

    ActionAmiT : function(text){
        ToanThanToc.SoloPlay.prototype.animalImage1 = ToanThanToc.game.add.sprite(160, 160,text );
        ToanThanToc.SoloPlay.prototype.animalImage1.rotation=3.14;
        ToanThanToc.SoloPlay.prototype.animalImage1.x = ToanThanToc.game.world.centerX + ToanThanToc.SoloPlay.prototype.animalImage1.width/2;
        ToanThanToc.SoloPlay.prototype.animalImage1.y = ToanThanToc.game.world.height *1/4 + ToanThanToc.SoloPlay.prototype.animalImage1.height/2 ;
        ToanThanToc.SoloPlay.prototype.animalImage1.animations.add('fire');
        ToanThanToc.SoloPlay.prototype.animalImage1.animations.play('fire', 3, true);

    },
    ActionAmiB : function(text){
        ToanThanToc.SoloPlay.prototype.animalImage2 = ToanThanToc.game.add.sprite(ToanThanToc.game.world.width -158,ToanThanToc.game.world.height-158,  text);
        ToanThanToc.SoloPlay.prototype.animalImage2.x = ToanThanToc.game.world.centerX - ToanThanToc.SoloPlay.prototype.animalImage2.width/2;
        ToanThanToc.SoloPlay.prototype.animalImage2.y = ToanThanToc.game.world.height *3/4 - ToanThanToc.SoloPlay.prototype.animalImage2.height/2 ;
        ToanThanToc.SoloPlay.prototype.animalImage2.animations.add('fire');
        ToanThanToc.SoloPlay.prototype.animalImage2.animations.play('fire', 3, true);
    },

    CreatSettingPopup:function(){
        var tt1 =   ToanThanToc.EndSoloPlay.prototype;
            tt1.btSetting = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX - 123/2,ToanThanToc.game.world.centerY - 123/2
            ,'btnSettingESoloPlay'
            ,function(){
               if(ToanThanToc.popupShow==0)
               {
                   ToanThanToc.EndSoloPlay.prototype.bgPopupSound =  ToanThanToc.game.add.image(0,0, 'bgPopupOk');
                   ToanThanToc.Menu.prototype.BacgroundForPopup();
                   if(SetMusic.touch)
                       ToanThanToc.music_touch.play();
                   tt1.bgEndPopupSL =  ToanThanToc.game.add.image(ToanThanToc.game.world.centerX - 382/2,ToanThanToc.game.world.centerY - 380/2,'bgEndPopupSL');
                   var w = tt1.bgEndPopupSL.width;
                   var h = tt1.bgEndPopupSL.height;

                   tt1.bgEndPopupSL.width =tt1.bgEndPopupSL.width - 382;
                   tt1.bgEndPopupSL.height = tt1.bgEndPopupSL.height  -380;
                   tt1.bgEndPopupSL.x=ToanThanToc.game.world.centerX - tt1.bgEndPopupSL.width/2;
                   tt1.bgEndPopupSL.y=ToanThanToc.game.world.centerY - tt1.bgEndPopupSL.height/2;

                   tt1.endQuitSL =ToanThanToc.game.add.button(14,10
                       ,'endQuitSL'
                       ,function(){
                           if (ToanThanToc.EndSoloPlay.prototype.tweenOpenPlay &&  ToanThanToc.EndSoloPlay.prototype.tweenOpenPlay.isRunning) return false;
                           if( SetMusic.touch )
                               ToanThanToc.music_popupMainAction.play();
                           ToanThanToc.EndSoloPlay.prototype.bgPopupSound.destroy();
                           ToanThanToc.Menu.prototype.HideBgPopupTop();
                           ToanThanToc.Menu.prototype.HideBgPopupBottom();
                           ToanThanToc.popupShow=0;
                           tt1.endQuitSL.frame=1;
                           tt1.ResetGame();
                           ToanThanToc.music_win.pause();
                           SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
                           ToanThanToc.game.stage.destroy();
                           ToanThanToc.game.state.start('MenuSolo');
                       },ToanThanToc.game,1,0,0);

                   tt1.endReplaySL =  ToanThanToc.game.add.button(14,ToanThanToc.EndSoloPlay.prototype.endQuitSL.height + 10
                       ,'endReplaySL'
                       ,function(){
                           ToanThanToc.EndSoloPlay.prototype.bgPopupSound.destroy();
                           ToanThanToc.Menu.prototype.HideBgPopupTop();
                           ToanThanToc.Menu.prototype.HideBgPopupBottom();
                           if (ToanThanToc.EndSoloPlay.prototype.tweenOpenPlay &&  ToanThanToc.EndSoloPlay.prototype.tweenOpenPlay.isRunning) return false;
                           if( SetMusic.touch )
                               ToanThanToc.music_popupMainAction.play();
                           ToanThanToc.popupShow=0;
                           tt1.endReplaySL.frame=1;
                           tt1.ResetGame();
                           ToanThanToc.music_win.pause();
                           ToanThanToc.game.stage.destroy();
                           ToanThanToc.isEndSolo=true;
                           ToanThanToc.game.state.start('SoloPlay');
                       }
                       ,ToanThanToc.game,1,0,0);

                   tt1.bgEndPopupSL.addChild(tt1.endQuitSL);
                   tt1.bgEndPopupSL.addChild(tt1.endReplaySL);

                   tt1.tweenOpenPlay = ToanThanToc.game.add.tween( tt1.bgEndPopupSL).to( { width:w, height:h,x:ToanThanToc.game.world.centerX - 382/2,y:ToanThanToc.game.world.centerY  -380/2 }, 5, Phaser.Easing.Bounce.Out, true);
                   ToanThanToc.popupShow=1;
               }
            }
            ,ToanThanToc.game,1,0,0);
    },

    ResetGame:function(){
        var tt1 =   ToanThanToc.EndSoloPlay.prototype;
        ToanThanToc.scoreTam1 = -1;
        ToanThanToc.scoreTam2 = -1;
        ToanThanToc.countNumQuestion=0;
        tt1.btSetting.destroy();
        tt1.multiBoardFull.destroy();
        tt1.bgEndPopupSL.destroy();
        ToanThanToc.scoreT.destroy();
        ToanThanToc.scoreB.destroy();
        if(SetMusic.music && !ToanThanToc.music_music.isPlaying )
        {
            ToanThanToc.music_music.resume();
        }
    }

};