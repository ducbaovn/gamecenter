/**
 * Created with JetBrains PhpStorm.
 * User: chienvd
 * Date: 15/09/14
 * Time: 4:04 PM
 * To change this template use File | Settings | File Templates.
 */
function isMobile(){
    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
//        return 'Mobile';
        return "Desktop";
    }
    return "Desktop";
}
function error(er){
    try{
        if(isMobile() == "Desktop" && console) console.error(er);
    }catch(e){

    }
}
function log(m){
    try{
        if(isMobile() == "Desktop" && console) console.log(m);
    }catch(e){

    }
}
function setVariableFromDevice(str){
    if(ToanThanToc.device && str && str.length > 3){
        var obj = eval(str);
        ToanThanToc.device.parseConfig(obj);
    }
}
var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};

function SetCssBody(url){
    $("html").css({"background": url,"-webkit-background-size": "cover","-moz-background-size": 'cover',"-o-background-size": 'cover',"background-size": 'cover'});
}

function fixBgLoad(){
    if(ToanThanToc.innerWidth>ToanThanToc.innerHeight || ToanThanToc.innerWidth==ToanThanToc.innerHeight )
    {
        $('#waiting').css({'z-index':'-1'});
    }
}