/* TRAN PHAN THANH - tpt2213
*  Thanhpt@nahi.vn
*  Create: 20/12/2014
*  Project: Game Center
*  Boot.js
* */
//-------------------------------------
"use strict";
//-------------------------------------

ToanThanToc.Boot = function (game){
    this.preloadBar = null;
};
ToanThanToc.Boot.prototype = {
    preload: function () {
        ToanThanToc.game.input.maxPointers = 0;
        ToanThanToc.game.load.image('preloaderBackground', 'assets/solo/waitting/bg-line.png');
        ToanThanToc.game.load.image('preloaderBar', 'assets/solo/waitting/ct-line.png');
    },
    create: function () {
        //// doi voi man hinh height lon hon width ta khong can xet 1 thuoc tinh nao chi can
        /**
        * ToanThanToc.game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL; // SHOW_ALL; EXACT_FIT; NO_SCALE
        * ToanThanToc.game.scale.setScreenSize(true);
        * Fix ca the css gameMath top
        * */
        //// doi voi man hinh width lon height phai tinh toan
        /*
         * ToanThanToc.game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL; // SHOW_ALL; EXACT_FIT; NO_SCALE
         * ToanThanToc.game.scale.setScreenSize(true);
        * Fix ca the css gameMath width,height
        * them margin-left vao css
        * ToanThanToc.game.canvas.style.marginLeft=(window.innerWidth/2 - parseInt($("#gameMath canvas").css("width").replace('px',''))/2)+'px';
        * */


        if(ToanThanToc.innerWidth>ToanThanToc.innerHeight || ToanThanToc.innerWidth==ToanThanToc.innerHeight )
        {
            this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL; /* SHOW_ALL; EXACT_FIT; NO_SCALE */
            this.scale.pageAlignHorizontally = true;
            this.scale.pageAlignVertically = true;
            this.scale.forceLandscape = true;
            this.scale.setScreenSize(true);
        }
       else{
            ToanThanToc.game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL; // SHOW_ALL; EXACT_FIT; NO_SCALE
            ToanThanToc.game.scale.setScreenSize(true);
        }

        ToanThanToc.game.state.start('Loader');

    }
};
