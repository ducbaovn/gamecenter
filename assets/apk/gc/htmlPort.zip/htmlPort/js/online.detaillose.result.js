/**
 * Created by TILE on 15/01/05.
 */
"use strict"; // Default style code of JS.



ToanThanToc.OnlineDetailResultLose = function(_game){};
ToanThanToc.OnlineDetailResultLose.prototype={


    /* ---------------- VARIABLE ---------------------- */
    itemGroup : null,
    xPoint : 0,
    yPoint : 0,
    txtSecondResult : null,
    styleTextSecond : {font: "60px segoe ui", fill: "#fff"},
    list : undefined,
    bg:null,
    back:null,
    out:null,
    bg_second:null,
    chargeCreateRoom : null,
    remain : null,
    fontStyle : {font: "bold 50px segoe ui", fill: "#FFF",strokeThickness:2},
    fontStyle1 : {font: "bold 50px segoe ui", fill: "#FFF",strokeThickness:2},
    fontStyle2 : {font: "bold 50px segoe ui", fill: "#FFF",strokeThickness:2},


    /**
     * Data test default.
     * @type {{id: number, stt: number, avatar: string, name: string, level: string, score: number}[]}
     */
    array :
    {
        "name":"2","scoreUpdatedAt":"2015-01-14T02:26:48.863Z","score":12,
        "players":[{"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn","nickname":"nahi1@nahi.vn",
            "avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":2,"score":12}]
    },

    /* ---------------- VARIABLE END ---------------------- */


    /**
    * Load image.
    */
    preload : function(){
        if( ToanThanToc.game.cache.checkImageKey('result_backgroundClose')){
            return;
        }
        ToanThanToc.game.load.spritesheet('result_backgroundClose',
            'assets/online/result/background.png', 800, 1232);
    },

    /**
    * Create UI.
    * @author TILE.
    */
    create : function(data){
        var game=ToanThanToc.OnlineDetailResultLose.prototype;

        game.bg = ToanThanToc.game.add.image(0,0,'result_backgroundClose');

        game.createList(150,200,480,910,'result_backgroundClose');


    },
    createList : function(x,y,w,h,key){
        var game=ToanThanToc.OnlineDetailResultLose.prototype;
        var arrayFreeRoom = {};
        for(var i = 0; i < game.array.players.length;++i){

            var arrayTemp = 0;
            var temp = i+1;
            arrayTemp = [

                { // Level.
                    xBuffer: 130,
                    yBuffer: 60,
                    name: 'Lv.'+game.array.players[i].level,
                    anchor: 0,
                    shadow: '0|0|0|0',
                    property: {font: "bold 35px Segoe UI", fill: "#fff", align: "left"},
                    type: 'text', isShow: 1
                },
                { // Text Name
                    xBuffer: 130,
                    yBuffer: 5,
                    name: game.array.players[i].nickname,
                    anchor: 0,
                    shadow: '0|0|0|0',
                    property: {font: "bold 35px Segoe UI", fill: "#fff", align: "left"},
                    type: 'textmem', isShow: 1
                },
                { // avatar image
                    xBuffer: 0,
                    yBuffer: -3,
                    name: (game.array.players[i] .avatar_url == '') ? 'avatar_default' : game.array.players[i].id,
                    width:111,
                    height:111,
                    property: {},
                    type: 'avatar', isShow: 1
                },
                { // score image
                    xBuffer: -60,
                    yBuffer: 120,
                    name: 'list_line',
                    property: {},
                    type: 'image', isShow: 1
                },
                { // score image
                    xBuffer: 385,
                    yBuffer: 5,
                    name: 'Score',
                    property: {},
                    type: 'image', isShow: 1
                },
                { // Diem
                    xBuffer: 482,
                    yBuffer: 75,
                    name: (game.array.players[i].score=='0')?'0':game.array.players[i].score,
                    strokeThickness: 5,
                    fontSize: 20,
                    fontWeight: 'bold',
                    anchor: 0.5,
                    shadow: '0|0|0|0',
                    property: {font: "bold 40px Segoe UI", fill: "#fff", align: "center"},
                    type: 'text', isShow: 1
                }
            ];
            if(i == 2){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -77,
                        yBuffer: -7,
                        name: '3medals',
                        type: 'avatar',
                        width:74,
                        height:74,
                        isShow: 1
                    }
                );
            }else if(i == 1){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -77,
                        yBuffer: -7,
                        name: '2medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }else if(i == 0){
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -77,
                        yBuffer: 0,
                        name: '1medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }else{
                arrayTemp.push(
                    { // Image sequence number.
                        xBuffer: -75,
                        yBuffer: 10,
                        name: temp + 'medals',
                        type: 'image',
                        isShow: 1
                    }
                );
            }

            if(arrayTemp){
                arrayFreeRoom[Object.keys(arrayFreeRoom).length] = arrayTemp;
            }
        }

        /* Create List */
        game.list = new ListScroll(arrayFreeRoom,x, y, w, h,140,
            'loserScreen',ToanThanToc.OnlineDetailResultLose,null,key);

        game.list.makeList();
        game.back = ToanThanToc.game.add.button(21,21,'result_back',this.backClick,{},0,0,1,0);
        game.out = ToanThanToc.game.add.button(693,21,'result_out',this.closeClick,{},0,0,1,0);
    },






    /**
    * Destroy object
    */
    destroy : function(){
        destroyArray([ToanThanToc.OnlineDetailResultLose.prototype.bg,
            ToanThanToc.OnlineDetailResultLose.prototype.itemGroup,
            ToanThanToc.OnlineDetailResultLose.prototype.txtSecondResult,
            ToanThanToc.OnlineDetailResultLose.prototype.xPoint,
            ToanThanToc.OnlineDetailResultLose.prototype.yPoint,
            ToanThanToc.OnlineDetailResultLose.prototype,
            ToanThanToc.OnlineDetailResultLose.prototype.styleTextSecond,
            ToanThanToc.OnlineDetailResultLose.prototype.bg_second,
            ToanThanToc.OnlineDetailResultLose.prototype.back,
            ToanThanToc.OnlineDetailResultLose.prototype.out]);
    },



    update : function(){
        if( ToanThanToc.OnlineDetailResultLose.prototype.list != null){
            ToanThanToc.OnlineDetailResultLose.prototype.list.update();
        }
    },

    /**
     * Back click.
     */
    backClick : function(){
        //console.log('Back click');
        ToanThanToc.nameSpaceBefore = "OnlineDetailResultWin";
        shareFunction.actionPlayAudio('touch');
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("OnlineMathResult");
        ToanThanToc.nameSpace = 'mathResult';
    },


    /**
     * Close click
     */
    closeClick : function(){
        //log('Close click');
        shareFunction.actionPlayAudio('touch');
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start("OnlineRoomWaiting");
    },
    sortData : function(data){

        /* Sort */
        var k = 0;
        for(k;k<data.length;++k){
            var l = 0;
            for(l;l<data.length-1;++l){
                if( data[l].score < data[l+1].score){
                    // permutations
                    var variableTemp = data[l+1];
                    data[l+1] = data[l];
                    data[l] = variableTemp;
                }
            }

        }

        return data;
    }
}; // End function.








