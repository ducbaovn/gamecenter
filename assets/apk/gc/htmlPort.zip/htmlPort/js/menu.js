/* ThanhPT from NAHI ---
 * @dateCreate 22/12/2014
 * @author tpt2213
 * */
"use strict";
var  SetMusic = {music:true,touch:true};
ToanThanToc.Menu = function (game) {
};

ToanThanToc.Menu.prototype = {
    tweenOpen:null,

    tweenClose:null,

    arrMusicBefore : {music:null,touch:null},

    preload : function() {

    },
    create : function() {
        /*   Phan Menu    */
        /* Get hieght da hinh */
        this.CreatePageMenu();
        ToanThanToc.game.input.maxPointers = 1;
        $('#homeVirtual').show();
    },
    render:function() {
        // ToanThanToc.game.debug.text("Time until event: " + ToanThanToc.game.time.events.duration, 32, 32);
        // render() ;
    },
	SetAudio:function(){
		if(ToanThanToc.music_lose!='lose'||
		ToanThanToc.music_music!='music'||
		ToanThanToc.music_popupMainAction!='popup-main-action'||
		ToanThanToc.music_popupQuit!='popup-quit'||
		ToanThanToc.music_touch!='touch'||
		ToanThanToc.music_win!='win'||
		ToanThanToc.music_wrong!='wrong')
			return false;

		ToanThanToc.music_music = ToanThanToc.game.add.sound(ToanThanToc.music_music, ToanThanToc.cuongDoAmThanh, false);
		ToanThanToc.music_touch = ToanThanToc.game.add.sound(ToanThanToc.music_touch, 1, false);
		ToanThanToc.music_popupQuit = ToanThanToc.game.add.sound(ToanThanToc.music_popupQuit, 1, false);
		ToanThanToc.music_popupMainAction = ToanThanToc.game.add.sound(ToanThanToc.music_popupMainAction, 1, false);
		ToanThanToc.music_wrong = ToanThanToc.game.add.sound(ToanThanToc.music_wrong, 1, false);
		ToanThanToc.music_win = ToanThanToc.game.add.sound(ToanThanToc.music_win, 1, false);
		ToanThanToc.music_lose = ToanThanToc.game.add.sound(ToanThanToc.music_lose, 1, false);
    },
    isSingle:false,
    isDoiKhang:false,
    isOnline:false,
    update : function() {
        if(ToanThanToc.Menu.prototype.isSingle){
            ToanThanToc.Menu.prototype.isSingle=false;
            ToanThanToc.Menu.prototype.DeletePageMenu();
            SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
            ToanThanToc.game.stage.destroy();
            ToanThanToc.Menu.prototype.isclick=null;
            ToanThanToc.game.state.start('MenuSingle');
        }
        else if(ToanThanToc.Menu.prototype.isDoiKhang){
            ToanThanToc.Menu.prototype.isDoiKhang=false;
            ToanThanToc.Menu.prototype.DeletePageMenu();
            SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
            ToanThanToc.game.stage.destroy();
            ToanThanToc.Menu.prototype.isclick=null;
            ToanThanToc.game.state.start("MenuSolo");
        }
        else if(ToanThanToc.Menu.prototype.isOnline){
            ToanThanToc.Menu.prototype.isOnline=false;
            ToanThanToc.Menu.prototype.DeletePageMenu();
            SetCssBody('');
            ToanThanToc.game.stage.destroy();
            ToanThanToc.Menu.prototype.isclick=null;
            ToanThanToc.game.state.start("MenuOnline");
        }
    },

    isll:false,

    CreatePageMenu :function(){
        //ToanThanToc.waiting.visible=false;
        var dm=ToanThanToc.Menu.prototype;

        dm.logoNahi =ToanThanToc.game.add.sprite(16,16,'logoNAHI');
        dm.logoVNM =ToanThanToc.game.add.sprite(707,16,'logoVnm');
		
		ToanThanToc.Menu.prototype.SetAudio();

        ToanThanToc.Menu.prototype.btnSingle = ToanThanToc.game.add.button(164, 428, 'btnSingle', null, ToanThanToc.game,0,0,1);
        ToanThanToc.Menu.prototype.btnSingle.events.onInputDown.add(this.ActionOnClick);


        ToanThanToc.Menu.prototype.btnMulti = ToanThanToc.game.add.button(164, 587, 'btnMulti', null, ToanThanToc.game,0,0,1);
        ToanThanToc.Menu.prototype.btnMulti.events.onInputDown.add(this.ActionOnClick);
        ToanThanToc.Menu.prototype.btnOnline = ToanThanToc.game.add.button(164, 745, 'btnOnline', null, ToanThanToc.game,0,0,1);
        ToanThanToc.Menu.prototype.btnOnline.events.onInputDown.add(this.ActionOnClick);

        ToanThanToc.Menu.prototype.btnSound = ToanThanToc.game.add.button(173, 923, 'btnSound', this.ActionOnClick, ToanThanToc.game,0,0,1);
        ToanThanToc.Menu.prototype.btnTutorial = ToanThanToc.game.add.button(294, 923, 'btnTutorial', null, ToanThanToc.game,0,0,1);
        ToanThanToc.Menu.prototype.btnTutorial.events.onInputDown.add(this.ActionOnClick);
        ToanThanToc.Menu.prototype.btnItemBag = ToanThanToc.game.add.button(544, 923, 'btnItemBag', null, ToanThanToc.game,0,0,1);
        ToanThanToc.Menu.prototype.btnItemBag.events.onInputDown.add(this.ActionOnClick);

        log('fadeBackgound');
        setTimeout(function(){
            if(SetMusic.music==true&&ToanThanToc.music_music.isPlaying==false)
                ToanThanToc.music_music.play('',0,1,true);
        },50);
    },
    /*  create popup */
    CreatePopupSound : function(){

        ToanThanToc.Menu.prototype.bgPopupSound =  ToanThanToc.game.add.image(0,0, 'bgPopupOk');
        ToanThanToc.Menu.prototype.bgPopupSound.inputEnabled=true;
        ToanThanToc.Menu.prototype.bgPopupSound.events.onInputDown.add(this.ClickOut);

        ToanThanToc.menu_bgPopup = ToanThanToc.game.add.image(415,635, 'bgPopup');
        ToanThanToc.menu_bgPopup.anchor.set(0.5);
        ToanThanToc.menu_bgPopup.width =ToanThanToc.menu_bgPopup.width - 415;
        ToanThanToc.menu_bgPopup.height =  ToanThanToc.menu_bgPopup.height - 635;

        ToanThanToc.menu_btnClose = ToanThanToc.game.add.button(215, -185, 'btnOff', this.ActionOnClickPopup, ToanThanToc.game);
        ToanThanToc.menu_btnXacNhan = ToanThanToc.game.add.button(-99, 65, 'btnXacNhan', this.ActionOnClickPopup, ToanThanToc.game);
        ToanThanToc.menu_chkNhacNen = ToanThanToc.game.add.button(85, -112, 'CheckNhacNen', this.ActionOnClickPopup, ToanThanToc.game);
        if(SetMusic.music)
            ToanThanToc.menu_chkNhacNen.frame=1;
        else
            ToanThanToc.menu_chkNhacNen.frame=0;
        ToanThanToc.menu_chkNhacHieuUng = ToanThanToc.game.add.button(85, -30, 'CheckHieuUng', this.ActionOnClickPopup, ToanThanToc.game);
        if(SetMusic.touch)
            ToanThanToc.menu_chkNhacHieuUng.frame=1;
        else
            ToanThanToc.menu_chkNhacHieuUng.frame=0;

        this.arrMusicBefore.music=SetMusic.music;
        this.arrMusicBefore.touch=SetMusic.touch;

        ToanThanToc.menu_bgPopup.addChild( ToanThanToc.menu_btnClose);
        ToanThanToc.menu_bgPopup.addChild( ToanThanToc.menu_btnXacNhan);
        ToanThanToc.menu_bgPopup.addChild( ToanThanToc.menu_chkNhacNen);
        ToanThanToc.menu_bgPopup.addChild( ToanThanToc.menu_chkNhacHieuUng);

        ToanThanToc.Menu.prototype.SetInputButtonFalse();

        ToanThanToc.Menu.prototype.tweenOpen = ToanThanToc.game.add.tween( ToanThanToc.menu_bgPopup.scale).to( { x: 1, y: 1 }, 2, Phaser.Easing.Linear.None, true);
        ToanThanToc.popupShow = true;
    },

    CreatePopupDieEnergy:function(){
        var _that =ToanThanToc.Menu.prototype;
        _that.bgPpDieEng =  ToanThanToc.game.add.image(0,0, 'bgPopupOk');
        _that.bgPpDieEng.inputEnabled=true;
        _that.bgPpDieEng.events.onInputDown.add(this.ClickOutPuDieEng);

        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ToanThanToc.Menu.prototype.SetInputButtonFalse();

        _that.menuBgPopupEng = ToanThanToc.game.add.image(ToanThanToc.game.world.centerX-631/2 ,ToanThanToc.game.world.centerY-445/2, 'bgPPEnergy');


        _that.menuBtnClEng = ToanThanToc.game.add.button(350, 300, 'thoatEnergy', this.ActionOnClickPopup, ToanThanToc.game);
        _that.menuBtnShopEng = ToanThanToc.game.add.button(145, 300, 'vatPhamEnergy', this.ActionOnClickPopup, ToanThanToc.game);

        _that.menuBgPopupEng.addChild( _that.menuBtnClEng);
        _that.menuBgPopupEng.addChild(_that.menuBtnShopEng);
    },

    SetInputButtonFalse : function(){
        if(ToanThanToc.game.state.current=='Menu'){
            var a = ToanThanToc.Menu.prototype;
            a.btnSingle.inputEnabled = false;
            a.btnMulti.inputEnabled = false;
            a.btnOnline.inputEnabled = false;
            a.btnSound.inputEnabled = false;
            a.btnTutorial.inputEnabled = false;
            a.btnItemBag.inputEnabled = false;
            ToanThanToc.Menu.prototype.isclick = null;
        }
    },

    SetInputButtonTrue : function(){
        if(ToanThanToc.game.state.current=='Menu'){
            var a = ToanThanToc.Menu.prototype;
            a.btnSingle.inputEnabled=true;
            a.btnMulti.inputEnabled=true;
            a.btnOnline.inputEnabled=true;
            a.btnSound.inputEnabled=false;
            a.btnTutorial.inputEnabled=true;
            a.btnItemBag.inputEnabled=true;
            ToanThanToc.Menu.prototype.isclick=null;
        }
    },

    SetInforUser:function(){
       /* //avatar_url: ""
        cleverExp: 3
        dob: "1970-01-01T00:00:00.000Z"
        //einstein: 9
        email: "smart01@gmail.com"
        energy: 450
        exactExp: 0
        //exp: 780
        fullname: "t33"
        id: "54b674c94467e6c080ccaa6b"
        langExp: 0
        level: 2
        levelExp: 1900
        logicExp: 6
        naturalExp: 6
        nickname: "t33"
        onlineStatus: "OFFLINE"
        rubyMoney: 0
        socialExp: 6
        socketId: "82GoRyFPxX-BKPan8u2Z"
        starMoney: 0
        token: "0bd74728ad826eeed8c4608f92512eb476b0d57db0b0fa12e97750b185a099ec"
        tokenExpireAt: "2015-01-23T14:10:18.311Z"*/
        ToanThanToc.Menu.prototype.avatarUrl=ToanThanToc.infoUserMath.avatar_url;
        ToanThanToc.Menu.prototype.einstein=0;//ToanThanToc.infoUserMath.einstein;
        ToanThanToc.Menu.prototype.exp=0;//ToanThanToc.infoUserMath.exp;
        ToanThanToc.Menu.prototype.id=ToanThanToc.infoUserMath.id;
        ToanThanToc.Menu.prototype.energy=ToanThanToc.infoUserMath.energy;
        if(ToanThanToc.Menu.prototype.energy<ToanThanToc.energyConf)
        {
            /* show popup die energy */
            if(ToanThanToc.game.state.current!='SinglePlay')
            {
                ToanThanToc.Menu.prototype.CreatePopupDieEnergy();
                return false;
            }
        }
    },

    isclick:null,

    ActionOnClick : function(item){
        var that = this;
        /* Set audio */
        if(ToanThanToc.Menu.prototype.isclick==null)
        {
            log(item.key);
            if(ToanThanToc.music_touch && SetMusic.touch && item.key!='btnOff'&& item.key!='btnXacNhan')
                ToanThanToc.music_touch.play();
            if(item.key=='btnOff'  && SetMusic.touch )
                ToanThanToc.music_popupQuit.play();
            if(item.key=='btnXacNhan' && SetMusic.touch )
                ToanThanToc.music_popupMainAction.play();
            /* Action Click */
            if(item.key=='btnSingle')
            {
                ToanThanToc.Menu.prototype.isclick='btnSingle';
                /*  Get Config Game  */
               /* if(ToanThanToc.configMath!=''&& ToanThanToc.infoUserMath!='')
                {
                    ToanThanToc.Menu.prototype.isSingle=true;
                    return false;
                }
                else*/
                {
                    GetConfigMath( function(data) {
                        ///log("callback called ConfigMath! " + JSON.stringify(config));
                        /* Get Infor user Game */
                        if(data=='error')
                        {
                            ToanThanToc.Menu.prototype.isclick=null;
                            log('dech vao');
                            return false;
                        }
                        GetUserMathInfor(function(data){
                            //log("callback called UserMathInfor! " + JSON.stringify(UserMathInfo));
                            /* success call Game */
                            if(data=='error')
                            {
                                ToanThanToc.Menu.prototype.isclick=null;
                                log('dech vao');
                                return false;
                            }
                            ToanThanToc.Menu.prototype.SetInforUser();
                            if(ToanThanToc.Menu.prototype.energy>=ToanThanToc.energyConf)
                                ToanThanToc.Menu.prototype.isSingle=true;
                            else
                            {
                                /* show popup die energy */
                                ToanThanToc.Menu.prototype.CreatePopupDieEnergy();
                            }
                        });
                    });
                    return false;
                }
            }
            else if(item.key=='btnMulti')
            {
                ToanThanToc.Menu.prototype.isclick='btnMulti';
                ToanThanToc.Menu.prototype.isDoiKhang=true;
            }
            else if(item.key=='btnOnline')
            {
                ToanThanToc.Menu.prototype.isclick='btnOnline';
                ToanThanToc.Menu.prototype.isOnline=true;

            }
            else if(item.key=='btnSound')
            {
                ToanThanToc.Menu.prototype.btnSound.inputEnabled=false;
                ToanThanToc.Menu.prototype.isclick='btnSound';
                if(ToanThanToc.popupShow) return false;

                ToanThanToc.Menu.prototype.BacgroundForPopup();
                ToanThanToc.Menu.prototype.CreatePopupSound();
            }
            else if(item.key=='btnTutorial')
            {

            }
            else if(item.key=='btnItemBag')
            {

            }
        }
    },
    btnSingle:null,
    btnOnline:null,
    btnMulti:null,
    btnSound:null,
    btnTutorial:null,
    btnItemBag:null,
    logoNahi:null,
    logoVNM:null,
    DeletePageMenu:function(){
        ToanThanToc.Menu.prototype.btnSingle.destroy();
        ToanThanToc.Menu.prototype.btnOnline.destroy();
        ToanThanToc.Menu.prototype.btnMulti.destroy();

        ToanThanToc.Menu.prototype.btnSound.destroy();
        ToanThanToc.Menu.prototype.btnTutorial.destroy();
        ToanThanToc.Menu.prototype.btnItemBag.destroy();
        ToanThanToc.Menu.prototype.logoNahi.destroy();
        ToanThanToc.Menu.prototype.logoVNM.destroy();
    },

    BacgroundForPopup:function(){
        if(ToanThanToc.innerWidth>ToanThanToc.innerHeight || ToanThanToc.innerWidth==ToanThanToc.innerHeight)
        {
            ToanThanToc.Menu.prototype.ShowBgPopupTopL();
            ToanThanToc.Menu.prototype.ShowBgPopupBottomR();
        }
        else
        {
            ToanThanToc.Menu.prototype.ShowBgPopupTop();
            ToanThanToc.Menu.prototype.ShowBgPopupBottom();
        }
    },

    ShowBgPopupTop:function(){
        var  hig= (ToanThanToc.heighPerFect==0)?0:parseFloat(ToanThanToc.heighPerFect/2 );
        $('#bgpopupTop').css({
            width: '100%',
            height: hig ,
            top:'0px',
            left:'0px',
            display: 'block'
        });
    },

    ShowBgPopupBottom:function(){
        var x =(ToanThanToc.heighPerFect==0)?0:parseFloat(ToanThanToc.heighPerFect/2 );
        var y = parseInt($("#gameMath canvas").css("height").replace('px',''));
        $('#bgpopupBottom').css({
            width: '100%',
            height: (ToanThanToc.innerHeight - x - y).toString() +'px' ,
            top: (x + y).toString() + 'px',
            left:'0px',
            display: 'block'
        });
    },

    ShowBgPopupTopL:function(){
        $('#bgpopupTop').css({
            width: (window.innerWidth/2 - parseInt($("#gameMath canvas").css("width").replace('px',''))/2).toString()+'px',
            height: ToanThanToc.innerHeight ,
            top:'0px',
            left:'0px',
            display: 'block'
        });
    },

    ShowBgPopupBottomR:function(){
        var x =(ToanThanToc.heighPerFect==0)?0:parseFloat(ToanThanToc.heighPerFect/2 -3);
        var y = parseInt($("#gameMath canvas").css("height").replace('px',''));
        $('#bgpopupBottom').css({
            width:  (window.innerWidth/2 - parseInt($("#gameMath canvas").css("width").replace('px',''))/2).toString()+'px',
            height:  ToanThanToc.innerHeight ,
            top:'0px',
            left:(window.innerWidth/2 + parseInt($("#gameMath canvas").css("width").replace('px',''))/2).toString()+'px',
            display: 'block'
        });
    },

    HideBgPopupTop:function(){
        $('#bgpopupTop').hide();
    },

    HideBgPopupBottom:function(){
        $('#bgpopupBottom').hide();
    },

    ActionOnClickPopup:function(item){
        //// popup
        if ( ToanThanToc.Menu.prototype.tweenClose &&  ToanThanToc.Menu.prototype.tweenClose.isRunning)return false;

        if ( ToanThanToc.Menu.prototype.tweenOpen &&  ToanThanToc.Menu.prototype.tweenOpen.isRunning) return false;

        if(ToanThanToc.music_touch && SetMusic.touch && item.key!='btnOff'&& item.key!='btnXacNhan')
            ToanThanToc.music_touch.play();
        if(item.key=='btnOff'  && SetMusic.touch )
            ToanThanToc.music_popupQuit.play();
        if(item.key=='btnXacNhan' && SetMusic.touch )
            ToanThanToc.music_popupMainAction.play();

        if(item.key=='btnOff') {
            ToanThanToc.Menu.prototype.isclick='btnOff';
            ToanThanToc.menu_btnClose.frame = 1;
            setTimeout(function () {
                ToanThanToc.menu_btnClose.frame = 0;

                if(ToanThanToc.Menu.prototype.arrMusicBefore.music)
                {
                    if(ToanThanToc.music_music.paused)
                        ToanThanToc.music_music.resume();
                }
                else if(!ToanThanToc.Menu.prototype.arrMusicBefore.music)
                {
                    if(ToanThanToc.music_music.isPlaying)
                        ToanThanToc.music_music.pause();
                }
                SetMusic.music = ToanThanToc.Menu.prototype.arrMusicBefore.music;
                SetMusic.touch = ToanThanToc.Menu.prototype.arrMusicBefore.touch;
                ToanThanToc.Menu.prototype.CloseWindow();
                ToanThanToc.Menu.prototype.SetInputButtonTrue();

            }, 50);
        }
        else if(item.key=='btnXacNhan'){
            ToanThanToc.Menu.prototype.isclick='btnXacNhan';
            ToanThanToc.menu_btnXacNhan.frame = 1;
            setTimeout(function () {
                ToanThanToc.menu_btnXacNhan.frame = 0;
                ToanThanToc.Menu.prototype.arrMusicBefore.music=SetMusic.music;
                ToanThanToc.Menu.prototype.arrMusicBefore.touch=SetMusic.touch;
                ToanThanToc.Menu.prototype.CloseWindow();
                ToanThanToc.Menu.prototype.SetInputButtonTrue();
            }, 50);
        }
        else if(item.key=='CheckNhacNen'){
            ToanThanToc.Menu.prototype.isclick=null;
            if(SetMusic.music)
            {
                ToanThanToc.menu_chkNhacNen.frame = 0;
                SetMusic.music = false;
                ToanThanToc.music_music.pause();
            }
            else if(!SetMusic.music)
            {
                ToanThanToc.menu_chkNhacNen.frame = 1;
                SetMusic.music = true;
                ToanThanToc.music_music.resume();
            }
        }
        else if(item.key=='CheckHieuUng'){
            log('co vap sao eu thay gi');
            ToanThanToc.Menu.prototype.isclick=null;
            if(SetMusic.touch)
            {
                ToanThanToc.menu_chkNhacHieuUng.frame = 0;
                SetMusic.touch = false;
            }
            else if(!SetMusic.touch)
            {
                ToanThanToc.menu_chkNhacHieuUng.frame = 1;
                SetMusic.touch = true;
            }
        }
        else if(item.key=='thoatEnergy'){
           ToanThanToc.Menu.prototype.ClickOutPuDieEng();
        }
        else if(item.key=='vatPhamEnergy'){
            log('chua co vat pham');
        }
    },

    CloseWindow : function() {
        ToanThanToc.Menu.prototype.tweenClose = ToanThanToc.game.add.tween(ToanThanToc.menu_bgPopup.scale).to( { x: 0, y: 0 }, 5, Phaser.Easing.Quadratic.In, true);
        ToanThanToc.Menu.prototype.tweenClose.onComplete.add(ToanThanToc.Menu.prototype.OnCompleteTweenClose);
    },
    ClickOut:function(){
        setTimeout(function () {
            ToanThanToc.menu_btnClose.frame = 0;

            if(ToanThanToc.Menu.prototype.arrMusicBefore.music)
            {
                if(ToanThanToc.music_music.paused)
                    ToanThanToc.music_music.resume();
            }
            else if(!ToanThanToc.Menu.prototype.arrMusicBefore.music)
            {
                if(ToanThanToc.music_music.isPlaying)
                    ToanThanToc.music_music.pause();
            }
            SetMusic.music = ToanThanToc.Menu.prototype.arrMusicBefore.music;
            SetMusic.touch = ToanThanToc.Menu.prototype.arrMusicBefore.touch;
            ToanThanToc.Menu.prototype.CloseWindow();
            ToanThanToc.Menu.prototype.SetInputButtonTrue();

        }, 50);
    },
    ClickOutPuDieEng:function(){
        var _that =ToanThanToc.Menu.prototype;
        _that.menuBtnClEng.destroy();
        _that.menuBtnShopEng.destroy();
        _that.menuBgPopupEng.destroy();
        _that.bgPpDieEng.destroy();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.SetInputButtonTrue();
        if(ToanThanToc.game.state.current!='Menu')
        {
            if(ToanThanToc.game.state.current=='SinglePlay')
            {
                SetCssBody('url(assets/solo/background/background.png) no-repeat center center fixed');
                ToanThanToc.SinglePlay.prototype.arrayMoneyShow=[];
                ToanThanToc.SinglePlay.prototype.TimeScroreAtt=[];
                ToanThanToc.SinglePlay.prototype.ScoreSG=0;
                ToanThanToc.SinglePlay.prototype.SetDefaultMoneyAndEXP();

                ToanThanToc.SinglePlay.prototype.DeleteQuestionAndAnswer();
                ToanThanToc.SinglePlay.prototype.DeletePageSinglePlay();
                ToanThanToc.Menu.prototype.isclick=null;
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('Menu');
                return false;
            }
        }
    },
    OnCompleteTweenClose : function(){
        ToanThanToc.menu_bgPopup.destroy();
        if(ToanThanToc.menu_btnClose!=null) ToanThanToc.menu_btnClose.destroy();
        ToanThanToc.menu_btnXacNhan.destroy();
        ToanThanToc.menu_chkNhacNen.destroy();
        ToanThanToc.menu_chkNhacHieuUng.destroy();
        ToanThanToc.Menu.prototype.bgPopupSound.destroy();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.btnSound.inputEnabled=true;
        ToanThanToc.popupShow = false;
        //SetCssBody('url(../assets/background/background.png) no-repeat center center fixed #000');
    }
};
