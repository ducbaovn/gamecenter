/**
 * @author       Roca Chien <chienvd@nahi.vn>
 * @copyright    2014 NAHI JSC.
 * @license      {@link http://www.nahi.vn/vn/gioi-thieu-ve-nahi.html}
 */

/**
 * This is the data model. The Game can get any request from server via APIs,
 * This drive must be encode any url to get API.
 *
 * @class Database
 * @constructor
 * @param {object} [config=null] - The default config object or null.
 */

var Database = function(config){
    /**
     * @property {object} config - The ToanThanToc.Database config object.
     */
    if(config) this.parseConfig(config);

    /**
     * @property {number} timeOut - The time out to waiting connection with the server. Default: 60 second
     */
    this.timeOut = 60;

    this.isSSL = false;

    this.domain = '103.19.220.139';

    this.method = "POST";

    this.header = {};

    this.headers = null;

    this.result = [];
};
Database.prototype = {
    parseConfig: function (config) {

        this.config = config;

        if (typeof config['isSSL'] === 'undefined')
        {
            this.isSSL = false;
        }

        if (config['domain'])
        {
            this.domain = config['domain'];
        }

        if (config['method'])
        {
            this.method = config['method'];
        }

        if (config['headers'])
        {
            this.headers = config['headers'];
        }
    },
    parseHeader: function () {
        if(ToanThanToc.device){
            this.header.xAuthToken = ToanThanToc.device.xAuthToken;

            this.header.deviceID = ToanThanToc.device.deviceID;

            this.header.platform = ToanThanToc.device.platform;

            this.headers = {'x-auth-token': this.header.xAuthToken, 'deviceid': this.header.deviceID, 'platform': this.header.platform};
        }
    },

    setAtuthToken: function(token){
        console.log("==================== setAtuthToken ============================");
        console.log(token);
        ToanThanToc.db.headers['x-auth-token'] = token;
    },

    /**
     * This is query data,
     *
     * @query
     * @param {object} [input = {api: "/path/method", data: {}, headers:{}}]
     */
    query:function(input){
        if(!input || !input.api) {
            console.log("Check your input data");
            return false;
        }

        var data = (input.data) ? input.data : {};
        var headers = (input.headers) ? input.headers : this.headers;
        var method = (!input.method) ? this.method : input.method;
        var timeOut = this.timeOut * 1000;
        var server = ((this.isSSL) ? "https://" : "http://") + this.domain;

        this.result = $.ajax({
            method: method,
            url: server + input.api,
            data: data,
            dataType: "json",
            async: true,
            crossDomain: true,
            timeout: timeOut,
            headers: headers,
            statusCode: {
                403: function(){
                    ToanThanToc.Error.author();
                }
            },
            error: function(xhr, status, error) {
                console.log('Database: ' + xhr.responseText);
                console.log(status);
            }
        });

        return this.result;
    },
    close:function(){
        delete this.result;
    }
};