/**
 * Created by duyln on 12/9/2014.
 */
var users = [],userBefore=null;
var newChatAPI = null;
var worldScroll,privateScroll,listScroll;
var loginKey = null;

var Chat = {

    checkResize: false,

    zoomIn: true,

    arrSmile60: [{key:':a',url:'assets/chat/smiles/60x60/Smiley_cuoilon_v1.gif'},
        {key:':b',url:'assets/chat/smiles/60x60/Smiley_buon_v1.gif'},
        {key:':c',url:'assets/chat/smiles/60x60/Smiley_buonngu_v1.gif'},
        {key:':d',url:'assets/chat/smiles/60x60/Smiley_chui_v1.gif'},
        {key:':e',url:'assets/chat/smiles/60x60/Smiley_dangyeu_v1.gif'},
        {key:':f',url:'assets/chat/smiles/60x60/Smiley_ngacnhien_v1.gif'},
        {key:':g',url:'assets/chat/smiles/60x60/Smiley_quyettam_v1.gif'},
        {key:':h',url:'assets/chat/smiles/60x60/Smiley_themthuong_v1.gif'},
        {key:':i',url:'assets/chat/smiles/60x60/Smiley_khoc_v1.gif'},
        {key:':k',url:'assets/chat/smiles/60x60/Smiley_matdo_v1.gif'},

        {key:':l',url:'assets/chat/smiles/60x60/Smiley_buonnon_v1.gif'},
        {key:':m',url:'assets/chat/smiles/60x60/Smiley_hoamat_v1.gif'},
        {key:':n',url:'assets/chat/smiles/60x60/Smiley_khohieu_v1.gif'},
        {key:':o',url:'assets/chat/smiles/60x60/Smiley_khongchiu_v1.gif'},
        {key:':p',url:'assets/chat/smiles/60x60/Smiley_khongquantam_v1-17.gif'},
        {key:':q',url:'assets/chat/smiles/60x60/Smiley_khongquantam_v1-36.gif'},
        {key:':r',url:'assets/chat/smiles/60x60/Smiley_khoqua_v1.gif'},
        {key:':s',url:'assets/chat/smiles/60x60/Smiley_leuleu_v1.gif'},
        {key:':t',url:'assets/chat/smiles/60x60/Smiley_matngau_v1.gif'},
        {key:':u',url:'assets/chat/smiles/60x60/Smiley_dauhang_v1.gif'},

        {key:':x',url:'assets/chat/smiles/60x60/Smiley_metmoi_v1.gif'},
        {key:':y',url:'assets/chat/smiles/60x60/Smiley_music_v1.gif'},
        {key:':z',url:'assets/chat/smiles/60x60/Smiley_ngoaymui_v1.gif'},
        {key:':1',url:'assets/chat/smiles/60x60/Smiley_nhamhiem_v1.gif'},
        {key:':2',url:'assets/chat/smiles/60x60/Smiley_ninja_v1.gif'},
        {key:':3',url:'assets/chat/smiles/60x60/Smiley_onao_v1.gif'},
        {key:':4',url:'assets/chat/smiles/60x60/Smiley_soluon_v1.gif'},
        {key:':5',url:'assets/chat/smiles/60x60/Smiley_taolaymay_v1.gif'},
        {key:':6',url:'assets/chat/smiles/60x60/Smiley_cammom_v1.gif'},
        {key:':7',url:'assets/chat/smiles/60x60/Smiley_covu_v1.gif'},

        {key:':8',url:'assets/chat/smiles/60x60/Smiley_thuakhongphuc_v1.gif'},
        {key:':9',url:'assets/chat/smiles/60x60/Smiley_tucgian_v1.gif'},
        {key:':{',url:'assets/chat/smiles/60x60/Smiley_uongbia_v1.gif'},
        {key:':}',url:'assets/chat/smiles/60x60/Smiley_yeu_v1.gif'},
        {key:':[',url:'assets/chat/smiles/60x60/Smiley_devil_v1.gif'}

    ],
    arrSmileLS: [{key:':a',url:'assets/chat/smiles-20-01/60x60/ls-taolaymay-v01-60x60.gif'},
        {key:':b',url:'assets/chat/smiles/1.gif'},
        {key:':c',url:'assets/chat/smiles/2.gif'},
        {key:':d',url:'assets/chat/smiles/3.gif'},
        {key:':e',url:'assets/chat/smiles/4.gif'},
        {key:':f',url:'assets/chat/smiles/5.gif'},
        {key:':g',url:'assets/chat/smiles/6.gif'},
        {key:':h',url:'assets/chat/smiles/7.gif'},
        {key:':i',url:'assets/chat/smiles/8.gif'},
        {key:':k',url:'assets/chat/smiles/9.gif'}
    ],

    arrHistoryChat: [{nickName:'smart01',status: 'Online',avatarUrl:'assets/chat/avatar_default.png'},
                    {nickName:'linhduy',status: 'Offline',avatarUrl:'assets/chat/avatar_default.png'},
                    {nickName:'MrGame',status: 'Online',avatarUrl:'assets/chat/avatar_default.png'}],

    textChatWorldSize: 250,

    textChatPrivateSize: 1000,

    isShow: false,


    //////////////////// function ///////////////////////

    /**
     * prepare connect API for start
     **/
    init: function(domain){
        Chat.resizeLoginContent();
        Chat.resizeChatContent();
        if(Chat.start(domain)==false){
            console.log('start fail >>>>> call login');
            $('#login') .show();
        }
    },


    /**
    * prepare connect API for start
    **/
    config:function(_domain,_callback){

        console.log('config connect APi');
        Chat.EnableScrollBar();
        console.log('newchatAPI');
        console.log(newChatAPI);
        var localStorage;
        //newChatAPI = localData.get('newChatAPI');
        newChatAPI = null;
        if(newChatAPI!=null) {
            console.log('newchatAPI have data');
            return _callback.call(this);
        }
        localStorage = localData.get('Account');
        if(localStorage==null){
            console.log('localdata null');
            return false;
        }
        newChatAPI = new chatAPI();
        console.log('create newchatAPI');
        console.log(newChatAPI);
        localData.set('newChatAPI',newChatAPI);
        newChatAPI.config(_domain,localStorage,newChatAPI.connectAPI);
        //localData.set('newChatAPI',newChatAPI);
        console.log('success config');
        if(!_callback){
            return;
        }
        return _callback.call(this);

        //newChatAPI.connectAPI;


    },

    /**
     * prepare UI for start
     **/
    configUI: function () {
        console.log('config UI');
        this.checkResize = true;
        $('#chat').show(0, function () {
            Chat.resizeChatContent();
            if ($("#world").css("display") == "block") {
                Chat.showWorld();
            }
            else if ($("#listHistoryChat").css("display") == "block") {
                Chat.showList();
            }
            else if ($("#private").css("display") == "block") {
                Chat.showPrivate();
            }
        });
        setTimeout(function () {
            Chat.updateScroll(worldScroll);
        },1000);
        Chat.isShow = true;
    },

    /**
    * start Chat
    * */
    start: function(_domain){
        if(this.config(_domain, this.configUI )==false){
            return false;
        }
    },

    /**
     * close Chat
     * */
    close: function(){
        /*$('#chat').hide();
        $('#bgZoom').hide();
        $('#homeVirtual').show();*/
        window.history.back();
        this.checkResize = false;
        Chat.isShow = false;
    },

    /**
     * send chat
     * */
    send: function() {
        var textSize;
        if ($("#world").css("display") == "block"){textSize = Chat.textChatWorldSize}
        if ($("#private").css("display") == "block"){textSize = Chat.textChatPrivateSize}
        if($(".chat-text").val()!='' && $(".chat-text").val().length <= textSize) {
            if ($("#private").css("display") == "block") {
                newChatAPI.post('/chat/private', {token: newChatAPI.profile.token, message:$(".chat-text").val(),userid:newChatAPI.userOnchat.attr('user_id')},newChatAPI.callbacksendPrivate);
            }
            else if ($("#world").css("display") == "block"){
                console.log('khi nhan enter');
                newChatAPI.post('/room/' + newChatAPI.kenhthegioi + '/chat', {token: newChatAPI.profile.token, message: $(".chat-text").val()},newChatAPI.callbacksendPublic);
            }
            //$(".chat-text-virtual").val("");
            //$(".chat-text").val("");
            //$(".chat-text-virtual").blur();

            //$(".chat-text").prop("readonly",true);
            //$(".chat-text-virtual").prop("readonly",true);
            //setTimeout(function(){
            //    //$(".chat-text").prop("readonly",false);
            //    //$(".chat-text").focus();
            //    $(".chat-text-virtual").prop("readonly",false);
            //    $(".chat-text-virtual").focus();
            //}, 3000);

        }

    },


    /**
     * show chat
     * */
    showChat: function(user,message,date,type){

        var html=null;

        var margintop = "30px";
        if(userBefore == newChatAPI.profile.nickname && userBefore == user.nickname) {
            margintop = "10px";
        }

        /// ======== xu ly time ================
        var chatTime = Chat.formatTime(date);

        /// ======== xu ly messages ============
        var messages2 = Chat.messagesHandler(message);
        if(user.nickname == newChatAPI.profile.nickname){
            /*html =  '<div class="rowMe">' +
                        '<div style="float: right; width: 100%">' +
                            '<div class="chatTime">'+ chatTime +'</div>' +
                        '</div>' +
                        '<div class="message">' + messages2 + '</div>' +
                    '</div>';*/
            if(user.avatar_url==''){
                html =  '<div class="rowMe" style="margin-top:' + margintop  +'">'+
                            '<div class="rowMeLine">' +
                                '<div>' +
                                    '<div class="chatTime">'+ chatTime +'</div>' +
                                '</div>' +
                                '<div class="message">' + messages2 + '</div>' +
                            '</div>' +
                            '<div class="avatar" style="background: url(assets/chat/avatar_default.png); background-size: 100%"></div>'+ // src="../assets/avatarNone.jpg"
                        '</div>';
            }
            else {
                html =  '<div class="rowMe" style="margin-top:' + margintop  +'">'+
                            '<div class="rowMeLine">' +
                                '<div>' +
                                    '<div class="chatTime">'+ chatTime +'</div>' +
                                '</div>' +
                                '<div class="message">' + messages2 + '</div>' +
                            '</div>' +
                            '<div class="avatar" style="background: url('+ user.avatar_url +'); background-size: 100%"></div>'+
                        '</div>';
            }

        }
        else{
            //////// ========= xu ly avatar =======
            if(user.avatar_url==''){
                html =  '<div class="rowFriend" style="margin-top:' + margintop  +'">'+
                            '<div class="avatar" style="background: url(assets/chat/avatar_default.png); background-size: 100%"></div>'+ // src="../assets/avatarNone.jpg"
                            '<div class="rowFriendLine">' +
                                    '<div>' +
                                        '<div class="nickName" user_name="' +  user.nickname + '" user_id="' + user.id +'">' + user.nickname + '</div>' +
                                        '<div class="chatTime">'+ chatTime +'</div>' +
                                    '</div>' +
                                    //'<a href="#" class="nickName" onclick="$("#bg-click-user").fadeIn();">'+ user.nickname + '</a>'+
                                '<div class="message">' + messages2 + '</div>' +
                            '</div>' +
                        '</div>';
            }
            else {
                html =  '<div class="rowFriend" style="margin-top:' + margintop  +'">'+
                            '<div class="avatar" style="background: url('+ user.avatar_url +'); background-size: 100%"></div>'+
                            '<div class="rowFriendLine">' +
                                '<div>' +
                                    '<div class="nickName" user_name="' +  user.nickname + '" user_id="' + user.id +'">' + user.nickname + '</div>' +
                                    '<div class="chatTime">'+ chatTime +'</div>' +
                                '</div>' +
                                    //'<a href="#" class="nickName" onclick="">'+ user.nickname + '</a>'+
                                '<div class="message">' + messages2 + '</div>' +
                            '</div>' +
                        '</div>';
            }
        }

        // ============= xu ly chat (world, private, group) =========
        if(type=='world') {
            $("#worldScroll").append(html);
            Chat.updateScroll(worldScroll);

        }
        else if(type=='private'){
            $("#privateScroll").append(html);
            Chat.updateScroll(privateScroll);
        }
        else if(type=='group'){
            $("#groupScroll").append(html);
        }


        userBefore = user.nickname;
    },


    /**
     * show user after search
     * */
    listSearch: function(){
        var key = $(".find-friend").val();
        if($.trim(key) == '') {$(".friend-area").fadeOut(200); return;}
        if(key.length > 2) {
            var searchUser = Chat.findUserWithName(key);
            var html = '<div class="friend-area" style="display: block;">';
            for (var i = 0; i < searchUser.length; i++) {
                html += '<div class="row">';
                html += '<a class="select-user" user_id="' + searchUser[i]['id'] + '" href="javascript: void(0);"><div class="username"  >' + searchUser[i]['name'] + '</div></a>';
                html += '</div>';
            }
            html += '</div>';
            $(".friend-area").fadeOut(20, function () {
                $(".friend-area").replaceWith(html);
                $(".friend-area").ready(function () {
                    $(".friend-area").mCustomScrollbar({
                        axis: "y",
                        scrollButtons: {enable: true},
                        theme: "3d",
                        scrollbarPosition: "outside"
                    });
                    $(".select-user").click(function () {
                        $("#scroll1").html("");
                        newChatAPI.userOnchat = $(this);
                        Chat.showPrivateChat();
                        newChatAPI.post('/chat/messages', {token: newChatAPI.profile.token, userid: newChatAPI.userOnchat.attr('user_id'), limit: 20}, newChatAPI.callbackGetMessagesPrivate);
                        $(".find-friend").val("");
                        $(".friend-area").hide();
                        newChatAPI.GetUser(newChatAPI.userOnchat.html());
                    });
                });
            });
        }
    },

    /**
     * sort users after search
     * */
    sortRank: function(field){
        users.sort(function(a,b){return b[field] - a[field]});
    },

    /**
     * find user with name
     * */
    findUserWithName: function(text){
        var ar = [];
        text = text.toLowerCase();
        newChatAPI.GetUser(text);
        for(var i = 0; i < users.length; i++) {
            if((users[i].nickname.toLowerCase().search(text) > -1)){
                var obj = { "id": users[i].id ,"name": users[i].nickname};
                ar.push(obj)
            }
        }
        return ar;
    },

    /**
     * show world Tab
     * */
    showWorld: function(){
        $("#world").show();
        $("#private").hide();
        $("#group").hide();
        $("#listHistoryChat").hide();
        $("#btn-back").hide();
        $('.find-friend').show();
        $(".chat-text").show();
        $("#btn-send").show();
        //Chat.fixPopupSmiles();
        Chat.updateScroll(worldScroll);
    },

    /**
     * show private Tab
     * */
    showPrivate: function(){
        $("#private").show();
        $("#world").hide();
        $("#group").hide();
        $("#listHistoryChat").hide();
        $(".find-friend").hide();
        $("#btn-back").show();
        $(".chat-text").show();
        $("#btn-send").show();
        Chat.fixPopupSmiles();
        Chat.updateScroll(privateScroll);
    },

    /**
     * show list history tab
     * */
    showList: function(){
        $("#listHistoryChat").show();
        $("#private").hide();
        $("#group").hide();
        $("#world").hide();
        $(".find-friend").show();
        $("#btn-back").hide();
        $(".chat-text").hide();
        $("#btn-send").hide();
        Chat.showListHistory();
    },

    /**
     * show Group >>> no use
     * */
    showGroup: function(){
        $("#private").hide();
        $("#group").show();
        $("#world").hide();
        //Chat.updateScroll();
    },

    /**
     * fix UI when show smiles store
     * */
    fixPopupSmiles: function() {
        if($('#bg').css('display')=='block'){
            $(".chat-area").css({"height": "594px"});
            $(".wrap-area").css({"height": "580px"});
            $("#chat-container").css({"height": "880px"});
            $(".chat-text").css({"top": "725px"});
            $("#btn-send").css({"top":"723px"});
        }
        else{
            $(".chat-area").css({"height": "894px"});
            $(".wrap-area").css({"height": "880px"});
            $("#chat-container").css({"height": "1180.8px"});
            $(".chat-text").css({"top": "1026px"});
            $("#btn-send").css({"top":"1025px"});
        }
        Chat.updateScroll(privateScroll);
        Chat.updateScroll(worldScroll);
    },

    /**
     * prepare ready function for DOM
     * */
    ReadyFunction: function(){
        $("#btn-send").click(function () {
            Chat.send();
        });
        //$(".chat-text").keypress(function(event) {
        //    var keycode = (event.keyCode ? event.keyCode : event.which);
        //
        //    if(keycode == '13') {
        //        Chat.send();
        //    }
        //});
        //$(".chat-text-virtual").keypress(function(event) {
        //    var keycode = (event.keyCode ? event.keyCode : event.which);
        //    log($(this).val());
        //    $('.chat-text').val($('.chat-text-virtual').val());
        //    if(keycode == '13') {
        //        Chat.send();
        //    }
        //});

        $(".chat-text").focus(function(event) {
            $(".friend-area").hide();
            //$("#greyOutPage").show();
            $(".chat-text").hide(0, function () {
                $('.chat-text-virtual').val($('.chat-text').val());
                //Chat.fixPosChatTextFocus();
                $(".chat-area").css({"padding-top": "175px", 'padding-bottom':'49px'});
                $('.chat-text-virtual').show(0, function () {
                    $('.greyBgr').show(0, function () {
                        $('.chat-text-virtual').focus();
                    });
                });
            });
            //if ($("#bg").css("display") == "block") {}
            //else{
            //}
        });
        $(".chat-text-virtual").focus(function(event) {
            if ($("#world").css("display") == "block"){
                $(".chat-text-virtual").prop("maxlength",Chat.textChatWorldSize);
            }
            if ($("#private").css("display") == "block"){
                $(".chat-text-virtual").prop({"maxlength":Chat.textChatPrivateSize});
            }
            $("#bg-click-user").fadeOut();
            $("#btn-send").hide();
        });
        $(".chat-text-virtual").on('keyup',function(event) {
            $(this).css({'height':'auto','overflow-y':'hidden'}).height(this.scrollHeight);
            $('.chat-text').val($('.chat-text-virtual').val());
            if(event.keyCode == 13) {
                Chat.send();
                Chat.chatTextVirtualBlur();
                $(this).css({'height':'74'});
            }
        });
        $(".chat-text-virtual").blur(function(event) {
            //$("#btn-send").css({"top": "1025px"});
            $(".chat-text-virtual").hide(0, function () {
                $(".greyBgr").hide();
                $(".chat-area").css({"padding-top": "90px", 'padding-bottom':'120px'});
                $(".chat-text").show(0, function () {
                    Chat.updateScroll(worldScroll);
                    Chat.updateScroll(privateScroll);

                });
                $("#btn-send").show();
            });

        });
        $(".world").click(function(){
            Chat.showWorld();
            $(".w1").attr("src", $(".w1").attr("src").replace("4.", "1."));
            $(".w2").attr("src", $(".w2").attr("src").replace("4.", "2."));
            $(".w3").attr("src", $(".w3").attr("src").replace("4.", "3."));

            $(".w3-1").attr("src", $(".w3-1").attr("src").replace("5.", "4."));
            $(".w2-1").attr("src", $(".w2-1").attr("src").replace("2.", "4."));
            $(".w1-1").attr("src", $(".w1-1").attr("src").replace("3.", "4."));

            $(".textThegioi").css({color: "#314c50","font-weight": "bold"});
            $(".textMat").css({color: "#fff","font-weight": "normal"});
            $(".chat-text").val("");
        });
        $(".private").click(function(){
            //Chat.showPrivate();
            Chat.showList();
            //Chat.showArr();
            //$(this).attr("src", $(this).attr("src").replace("off.", "on."));
            $(".w1").attr("src", $(".w1").attr("src").replace("1.", "4."));
            $(".w2").attr("src", $(".w2").attr("src").replace("2.", "4."));
            $(".w3").attr("src", $(".w3").attr("src").replace("3.", "4."));

            $(".w3-1").attr("src", $(".w3-1").attr("src").replace("4.", "5."));
            $(".w2-1").attr("src", $(".w2-1").attr("src").replace("4.", "2."));
            $(".w1-1").attr("src", $(".w1-1").attr("src").replace("4.", "3."));

            $(".textThegioi").css({color: "#fff","font-weight": "normal"});
            $(".textMat").css({color: "#314c50","font-weight": "bold"});
            $(".friend-area").hide()
        });
        $(".group").click(function(){
            Chat.showGroup();
            $(this).attr("src", $(this).attr("src").replace("off.", "on."));
            $(".private").attr("src", $(".private").attr("src").replace("on.", "off."));
            $(".world").attr("src", $(".world").attr("src").replace("on.", "off."));
        });
        $(".icon1").click(function(){
            console.log('icon1 click');
            if($('#bg').css('display')=='block') {
                $(this).attr("src", $(this).attr("src").replace("on.", "off."));
                $("#bg").hide();
            }
            else{
                $(this).attr("src", $(this).attr("src").replace("off.", "on."));
                $("#bg").show();
            }
            Chat.fixPopupSmiles();
        });

        $(".find-friend").focus(function(){ //bat su kien focus
            $(".friend-area").fadeOut();
            $("#bg-click-user").fadeOut();
        });
        $(".find-friend").blur(function(){ // bat su kien unfocus
            //$(".friend-area").hide();
        });
        $(".find-friend").keyup(function(){ // bat su kien bam ban phim
            Chat.sortRank();
            Chat.listSearch();
        });
        $(".chat-mat").click(function(){
            if($(this).attr('key')=='privatechat') {
                Chat.showPrivateChat();
                newChatAPI.post('/chat/messages', {token: newChatAPI.profile.token, userid: newChatAPI.userOnchat.attr('user_id'), limit: 20}, newChatAPI.callbackGetMessagesPrivate);
                $("#bg-click-user").fadeOut();
                $(".friend-area").hide();
            }
        });
        $(".chat-mat").blur(function () {
            //$("#bg-click-user").fadeOut();
            console.log('abc');
        });
        $(".zoomIn").click(function(){
            Chat.close();
        });
        $(".Smiles").click(function(){
            $(".chat-text-virtual").val($(".chat-text-virtual").val() + $(this).attr('key'));
            $(".chat-text").val($(".chat-text").val() + $(this).attr('key'));
            $("#bg-click-user").fadeOut();
        });
        $(".btnSmilesCtrl1").click(function(){
            $(".chat-text").val(Chat.RemoveIcon($(".chat-text").val()));
        });
        $(".btnSmilesCtrl2").click(function(){
            $("#bg").hide();
            $(".icon1").attr("src", $(".icon1").attr("src").replace("on.", "off."));
            Chat.fixPopupSmiles();
        });
        var jssor_slider2 = new $JssorSlider$("bgSmiles");
        $('#btn-back').click(function(){
            console.log('btn back');
            Chat.showList();
        });
        $('#chat-container').on('click','.nickName', function(e) {
            if($('#private').css('display')=='block'){
                return
            }
            $("#bg-click-user").fadeIn();
            document.getElementById("name").innerText = $(this).attr('user_name');
            newChatAPI.userOnchat = $(e.currentTarget);//.attr('user_id');
        });
        $('#listHistoryChat').on('click','.nickNameList', function(e) {
            $('#privateScroll').html('');
            newChatAPI.post('/chat/messages', {token: newChatAPI.profile.token, userid: $(this).attr('user_id'), limit: 20}, newChatAPI.callbackGetMessagesPrivate);
            Chat.showPrivate();
            newChatAPI.userOnchat = $(e.currentTarget);
        });
        $('#greyOutPage').on('click', function () {
            $("#bg-click-user").fadeOut();
        });

        $('#facebook').on('click', function () {
            try{
                Android.startActivityLogin();
            }
            catch (e){

            }
        });

    },

    /**
     * Add smiles to array
     * */
    AddSmile: function(smile,pos){
        Chat.arrSmileSS[pos] = smile;
    },

    /**
     * remove smiles from string
     * */
    RemoveIcon: function (_str) {
        var res = _str.substr(_str.lastIndexOf(":"));
        for(var i=0;i<Chat.arrSmile60.length;i++){
            if(res == Chat.arrSmile60[i].key){
                return _str.slice(0,_str.lastIndexOf(res));
            }
        }
        return _str;
    },
    CheckStr: function(_str) {
        var str1 = null;
        while (_str.length > 0 && _str != str1) {
            str1 = _str;
            _str = Chat.RemoveIcon(_str);
        }
        if (_str == '') {
            return 0;
        }
        else{
            return 1;
        }
    },

    /**
     * Enable scroll bar
     * */
    EnableScrollBar: function () {
        console.log("=================== Chat.EnableScrollBar ============================");
        worldScroll = new IScroll('#worldWrap',{ mouseWheel: true, tap: true, click: true, momentum: true });
        privateScroll = new IScroll('#privateWrap', { mouseWheel: true, tap: true, click: true });
        listScroll = new IScroll('#listHistoryChatWrap', { mouseWheel: true, tap: true, click: true });
    },

    /**
     * Update scroll bar
     * */
    updateScroll: function(_myScroll){
        //$(".chat-area").mCustomScrollbar('update');
        //$(".chat-area").mCustomScrollbar("scrollTo", "bottom");
        _myScroll.refresh();
        _myScroll.scrollTo(0, _myScroll.maxScrollY, 1200);

        //return _callback.call(this);
        //if(_callback==null) {
        //    return;
        //}
        //_myScroll.on('scrollEnd',_callback);

    },

    /**
     * set value history chat to local storage
     * */
    addLocalStorage: function(){
        if(localData.get('historyChat')!=null) {
            return;
        }
        var ar = [];
        localData.set('historyChat', ar);
    },

    /**
     * show list history chat
     * */
    showListHistory: function(){
        $('#listScroll').html('');
        var html,color,url,data,avatar,sender, i,len,messages;
        data = localData.get('historyChat');
        if(data == null){ return }
        console.log(data);
        console.log(data.length);
        for(i= 0,len=data.length;i<len;i++) {
            sender = data[i].sender;
            console.log(data[i].message);
            ///////========= xu ly item =======
            if(sender.onlineStatus=='ONLINE'){
                url = 'assets/chat/status-online.png';
            }
            else {
                url = 'assets/chat/status-offline.png';
            };
            if(sender.avatar_url==''){
                avatar = 'assets/chat/avatar_default.png';
            }
            else{
                avatar = sender.avatar_url;
            }
            console.log(avatar);

            messages = Chat.messagesHandler(data[i].message);
            html = '<div>' +
                        '<div class="rowList">' +
                            '<div class="avatarList" style="background: url(' + avatar + '); background-size: 100%"></div>' +
                            '<div class="detailList">' +
                                '<div class="nickNameList" user_id="' + sender.id + '">' + sender.nickname + '</div>' +
                                '<div class="status">' + messages + '</div>' +
                            '</div>' +
                            '<div class="statusImage" style="background: url('+ url +') no-repeat top; background-size: 100%"></div>' +
                        '</div>' +
                        '<div class="line" style="background: url(assets/chat/line.png)"></div>'+
                    '</div>';
            $("#listScroll").append(html);
            Chat.updateScroll(listScroll);
        }
    },

    /**
     * show private chat
     * */
    showPrivateChat: function () {
        $('#privateScroll').html('');
        Chat.showPrivate();
        $(".w1").attr("src", $(".w1").attr("src").replace("1.", "4."));
        $(".w2").attr("src", $(".w2").attr("src").replace("2.", "4."));
        $(".w3").attr("src", $(".w3").attr("src").replace("3.", "4."));

        $(".w3-1").attr("src", $(".w3-1").attr("src").replace("4.", "5."));
        $(".w2-1").attr("src", $(".w2-1").attr("src").replace("4.", "2."));
        $(".w1-1").attr("src", $(".w1-1").attr("src").replace("4.", "3."));

        $(".textThegioi").css({color: "#fff","font-weight": "normal"});
        $(".textMat").css({color: "#314c50","font-weight": "bold"});
        $(".chat-text").val("");
        $(".friend-area").hide();
    },

    /**
     * check sender on value in local storage
     * */
    checkObject: function (objFa,objCh) {
        console.log('objFa');
        console.log(objFa);
        console.log('objCh');
        console.log(objCh);
        var i,len,senderFa,senderCh;
        senderCh = objCh.sender;
        console.log('senderCh');
        console.log(senderCh);
        for(i=0,len=objFa.length;i<len;i++){
            senderFa = objFa[i].sender;
            console.log('sender');
            console.log(senderFa);
            if(senderFa.id == senderCh.id) {
                console.log('cung nguoi gui');
                localData.removeItemTo('historyChat',i)
                break;
            }
            else {
                console.log('khac nguoi gui');
            }
        }
    },

    /**
     * format layout message
     * */
    messagesHandler: function(messages){
        if (messages.split('<').length > 0) {
            messages = messages.replace(/</g, "&lt;");
        }
        if (messages.split('>').length > 0) {
            messages = messages.replace(/>/g, "&gt;");
        }

        if (messages.split(':a').length > 1) {
            messages = messages.replace(/:a/g, "<img class='smiles60' src='" + Chat.arrSmile60[0].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':b').length > 0) {
            messages = messages.replace(/:b/g, "<img class='smiles60' src='" + Chat.arrSmile60[1].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':c').length > 0) {
            messages = messages.replace(/:c/g, "<img class='smiles60' src='" + Chat.arrSmile60[2].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':d').length > 0) {
            messages = messages.replace(/:d/g, "<img class='smiles60' src='" + Chat.arrSmile60[3].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':e').length > 0) {
            messages = messages.replace(/:e/g, "<img class='smiles60' src='" + Chat.arrSmile60[4].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':f').length > 0) {
            messages = messages.replace(/:f/g, "<img class='smiles60' src='" + Chat.arrSmile60[5].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':g').length > 0) {
            messages = messages.replace(/:g/g, "<img class='smiles60' src='" + Chat.arrSmile60[6].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':h').length > 0) {
            messages = messages.replace(/:h/g, "<img class='smiles60' src='" + Chat.arrSmile60[7].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':i').length > 0) {
            messages = messages.replace(/:i/g, "<img class='smiles60' src='" + Chat.arrSmile60[8].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':k').length > 0) {
            messages = messages.replace(/:k/g, "<img class='smiles60' src='" + Chat.arrSmile60[9].url + "'/ align='absmiddle'>");
        }
///////////////////////////////////////////////////////
        if (messages.split(':l').length > 0) {
            messages = messages.replace(/:l/g, "<img class='smiles60' src='" + Chat.arrSmile60[10].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':m').length > 0) {
            messages = messages.replace(/:m/g, "<img class='smiles60' src='" + Chat.arrSmile60[11].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':n').length > 0) {
            messages = messages.replace(/:n/g, "<img class='smiles60' src='" + Chat.arrSmile60[12].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':o').length > 0) {
            messages = messages.replace(/:o/g, "<img class='smiles60' src='" + Chat.arrSmile60[13].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':p').length > 0) {
            messages = messages.replace(/:p/g, "<img class='smiles60' src='" + Chat.arrSmile60[14].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':q').length > 0) {
            messages = messages.replace(/:q/g, "<img class='smiles60' src='" + Chat.arrSmile60[15].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':r').length > 0) {
            messages = messages.replace(/:r/g, "<img class='smiles60' src='" + Chat.arrSmile60[16].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':s').length > 0) {
            messages = messages.replace(/:s/g, "<img class='smiles60' src='" + Chat.arrSmile60[17].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':t').length > 0) {
            messages = messages.replace(/:t/g, "<img class='smiles60' src='" + Chat.arrSmile60[18].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':u').length > 0) {
            messages = messages.replace(/:u/g, "<img class='smiles60' src='" + Chat.arrSmile60[19].url + "'/ align='absmiddle'>");
        }
//////////////////////////////////////////////
        if (messages.split(':x').length > 0) {
            messages = messages.replace(/:x/g, "<img class='smiles60' src='" + Chat.arrSmile60[20].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':y').length > 0) {
            messages = messages.replace(/:y/g, "<img class='smiles60' src='" + Chat.arrSmile60[21].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':z').length > 0) {
            messages = messages.replace(/:z/g, "<img class='smiles60' src='" + Chat.arrSmile60[22].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':1').length > 0) {
            messages = messages.replace(/:1/g, "<img class='smiles60' src='" + Chat.arrSmile60[23].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':2').length > 0) {
            messages = messages.replace(/:2/g, "<img class='smiles60' src='" + Chat.arrSmile60[24].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':3').length > 0) {
            messages = messages.replace(/:3/g, "<img class='smiles60' src='" + Chat.arrSmile60[25].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':4').length > 0) {
            messages = messages.replace(/:4/g, "<img class='smiles60' src='" + Chat.arrSmile60[26].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':5').length > 0) {
            messages = messages.replace(/:5/g, "<img class='smiles60' src='" + Chat.arrSmile60[27].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':6').length > 0) {
            messages = messages.replace(/:6/g, "<img class='smiles60' src='" + Chat.arrSmile60[28].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':7').length > 0) {
            messages = messages.replace(/:7/g, "<img class='smiles60' src='" + Chat.arrSmile60[29].url + "'/ align='absmiddle'>");
        }
//////////////////////////////////////////////////////
        if (messages.split(':8').length > 0) {
            messages = messages.replace(/:8/g, "<img class='smiles60' src='" + Chat.arrSmile60[30].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':9').length > 0) {
            messages = messages.replace(/:9/g, "<img class='smiles60' src='" + Chat.arrSmile60[31].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':{').length > 0) {
            messages = messages.replace(/:{/g, "<img class='smiles60' src='" + Chat.arrSmile60[32].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':}').length > 0) {
            messages = messages.replace(/:}/g, "<img class='smiles60' src='" + Chat.arrSmile60[33].url + "'/ align='absmiddle'>");
        }
        if (messages.split(':[').length > 0) {
            messages = messages.replace(/:\[/g, "<img class='smiles60' src='" + Chat.arrSmile60[34].url + "'/ align='absmiddle'>");
        }


        /*if(Chat.CheckStr(messages)==1) {
            if (messages.split(':a').length > 1) {
                messages = messages.replace(/:a/g, "<img class='smiles60' src='" + Chat.arrSmile60[0].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':b').length > 0) {
                messages = messages.replace(/:b/g, "<img class='smiles60' src='" + Chat.arrSmile60[1].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':c').length > 0) {
                messages = messages.replace(/:c/g, "<img class='smiles60' src='" + Chat.arrSmile60[2].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':d').length > 0) {
                messages = messages.replace(/:d/g, "<img class='smiles60' src='" + Chat.arrSmile60[3].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':e').length > 0) {
                messages = messages.replace(/:e/g, "<img class='smiles60' src='" + Chat.arrSmile60[4].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':f').length > 0) {
                messages = messages.replace(/:f/g, "<img class='smiles60' src='" + Chat.arrSmile60[5].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':g').length > 0) {
                messages = messages.replace(/:g/g, "<img class='smiles60' src='" + Chat.arrSmile60[6].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':h').length > 0) {
                messages = messages.replace(/:h/g, "<img class='smiles60' src='" + Chat.arrSmile60[7].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':i').length > 0) {
                messages = messages.replace(/:i/g, "<img class='smiles60' src='" + Chat.arrSmile60[8].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':k').length > 0) {
                messages = messages.replace(/:k/g, "<img class='smiles60' src='" + Chat.arrSmile60[9].url + "'/ align='absmiddle'>");
            }
            *//*if (messages.split(':l').length > 0) {
                messages = messages.replace(/:l/g, "<img class='smiles60' src='" + Chat.arrSmile60[10].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':m').length > 0) {
                messages = messages.replace(/:m/g, "<img class='smiles60' src='" + Chat.arrSmile60[11].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':n').length > 0) {
                messages = messages.replace(/:n/g, "<img class='smiles60' src='" + Chat.arrSmile60[12].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':o').length > 0) {
                messages = messages.replace(/:o/g, "<img class='smiles60' src='" + Chat.arrSmile60[13].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':p').length > 0) {
                messages = messages.replace(/:p/g, "<img class='smiles60' src='" + Chat.arrSmile60[14].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':1').length > 0) {
                messages = messages.replace(/:1/g, "<img class='smiles60' src='" + Chat.arrSmile60[15].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':2').length > 0) {
                messages = messages.replace(/:2/g, "<img class='smiles60' src='" + Chat.arrSmileSS[16].url + "'/ align='absmiddle'>");
            }*//*
        }
        else if(Chat.CheckStr(messages)==0){
            if (messages.split(':a').length > 1) {
                messages = messages.replace(/:a/g, "<img class='smilesLS' src='" + Chat.arrSmile60[0].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':b').length > 0) {
                messages = messages.replace(/:b/g, "<img class='smilesLS' src='" + Chat.arrSmile60[1].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':c').length > 0) {
                messages = messages.replace(/:c/g, "<img class='smilesLS' src='" + Chat.arrSmile60[2].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':d').length > 0) {
                messages = messages.replace(/:d/g, "<img class='smilesLS' src='" + Chat.arrSmile60[3].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':e').length > 0) {
                messages = messages.replace(/:e/g, "<img class='smilesLS' src='" + Chat.arrSmile60[4].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':f').length > 0) {
                messages = messages.replace(/:f/g, "<img class='smilesLS' src='" + Chat.arrSmile60[5].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':g').length > 0) {
                messages = messages.replace(/:g/g, "<img class='smilesLS' src='" + Chat.arrSmile60[6].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':h').length > 0) {
                messages = messages.replace(/:h/g, "<img class='smilesLS' src='" + Chat.arrSmile60[7].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':i').length > 0) {
                messages = messages.replace(/:i/g, "<img class='smilesLS' src='" + Chat.arrSmile60[8].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':k').length > 0) {
                messages = messages.replace(/:k/g, "<img class='smilesLS' src='" + Chat.arrSmile60[9].url + "'/ align='absmiddle'>");
            }
            *//*if (messages.split(':l').length > 0) {
                messages = messages.replace(/:l/g, "<img class='smilesLS' src='" + Chat.arrSmile60[10].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':m').length > 0) {
                messages = messages.replace(/:m/g, "<img class='smilesLS' src='" + Chat.arrSmile60[11].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':n').length > 0) {
                messages = messages.replace(/:n/g, "<img class='smilesLS' src='" + Chat.arrSmile60[12].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':o').length > 0) {
                messages = messages.replace(/:o/g, "<img class='smilesLS' src='" + Chat.arrSmile60[13].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':p').length > 0) {
                messages = messages.replace(/:p/g, "<img class='smilesLS' src='" + Chat.arrSmile60[14].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':1').length > 0) {
                messages = messages.replace(/:1/g, "<img class='smilesLS' src='" + Chat.arrSmile60[15].url + "'/ align='absmiddle'>");
            }
            if (messages.split(':2').length > 0) {
                messages = messages.replace(/:2/g, "<img class='smilesLS' src='" + Chat.arrSmile60[16].url + "'/ align='absmiddle'>");
            }*//*
        }*/
        return messages;
    },

    /**
     * resize chat contain
     * */
    resizeChatContent: function () {
        var widthDefault = 800;
        var heightDefault = 1230;
        var widthDevice = window.innerWidth;
        var heightDevice = window.innerHeight;
        var scaleWidth = widthDevice / widthDefault;
        var scaleHeight = heightDevice / heightDefault;
        var zoomChat = (scaleHeight > scaleWidth) ? scaleWidth : scaleHeight;
        //var widthContent = $("#content > canvas").width();
        //var heightContent = $("#content > canvas").height();
        //var leftChat = (widthDevice-widthContent)/2;
        //var topChat = (heightDevice - heightContent)/2;

        var widthChatContain = $("#chat").width();
        var heightChatContain = $("#chat").height();
        var leftChat = (widthDevice - widthChatContain)/2;
        var topChat = (heightDevice - heightChatContain)/2;

        console.log("chat-container width");
        console.log($("#chat-container").width());
        jQuery(document).ready(function ($) {
            $('#chat').css({
                '-webkit-transform' : 'scale('+zoomChat+')',
                '-moz-transform' : 'scale('+zoomChat+')',
                '-ms-transform' : 'scale('+zoomChat+')',
                '-o-transform' : 'scale('+zoomChat+')',
                'transform' : 'scale('+zoomChat+')'
            });

            $('#bgZoom').css({'height': window.innerHeight, 'width': window.innerWidth})
            console.log('window.innerHeight' + window.innerHeight);
            console.log($(document).height());
            //if(zoomChat!=1) {
            $("#chat").css({
                left: leftChat + "px",
                top: topChat + "px"
            });

            //}
        });
    },
    resizeLoginContent: function () {

        var widthDefault = 800;
        var heightDefault = 1230;
        var widthDevice = window.innerWidth;
        var heightDevice = window.innerHeight;
        var scaleWidth = widthDevice / widthDefault;
        var scaleHeight = heightDevice / heightDefault;
        var zoom = (scaleHeight > scaleWidth) ? scaleWidth : scaleHeight;
        var widthLoginContain = $("#login").width();
        var heightLoginContain = $("#login").height();
        var leftLogin = (widthDevice - widthLoginContain)/2;
        var topLogin = (heightDevice - heightLoginContain)/2;

        jQuery(document).ready(function ($) {
            $('#login').css({
                '-webkit-transform' : 'scale('+zoom+')',
                '-moz-transform' : 'scale('+zoom+')',
                '-ms-transform' : 'scale('+zoom+')',
                '-o-transform' : 'scale('+zoom+')',
                'transform' : 'scale('+zoom+')'
            });
        });

        $("#login").css({
            left: leftLogin + "px",
            top: topLogin + "px"
        });

    },

    /**
     * fix position chat text on focus
     * */
    fixPosChatTextFocus: function(){
        $(".chat-area").css({"padding-top": "175px", 'padding-bottom':'49px'});
        //$(".wrap-area").css({'height':'810px'});
    },

    /**
     * get virtual keyboard height >>>> not use
     * */
    keyboardHeight: function(){
        var sx = document.body.scrollLeft, sy = document.body.scrollTop;
        var naturalHeight = window.innerHeight;
        window.scrollTo(sx, document.body.scrollHeight);
        var keyboardHeight = naturalHeight - window.innerHeight;
        window.scrollTo(sx, sy);
        return keyboardHeight;
    },

    /**
     * chat text virtual on blur >>>> Java use
     * */
    chatTextVirtualBlur: function() {
        console.log('chatTextVirtualBlur');
        if($(".chat-text-virtual").is(":focus")){
            console.log('chatTextVirtualBlur if($(".chat-text-virtual").is(":focus")){ ');
            $(".chat-text-virtual").blur();
        }
    },


    /**
     * format time
     * */
    formatTime: function(date){
        var dataTime, h , m;
        dataTime =  new Date(date);

        h = (dataTime.getHours()+11)%12+1;
        h = (h<10) ? ("0" + h) : (h);

        m = dataTime.getMinutes();
        m = (m<10) ? ("0" + m) : (m);

        var timeFormat = h + ':' + m;
        timeFormat += (dataTime.getHours()>=12)? ' PM' : ' AM';
        return timeFormat;
    },

    login : function(){
        var tonkenFacebook = null;
        /*alert('----------------- checkAndroidToken --------------------');*/
        try{
            tonkenFacebook = Android.getTokenFacebook('tokenFacebook');
        }catch (e)
        {
            ActionLogin(null);
            return false;
        }
        ActionLogin(null);
    },

    exitLogin: function(){
        if(loginKey==null) {
            Chat.close();
        }else{
            $('#loginNahi').fadeOut(function () {
                $('#nahi').fadeIn();
                $('#facebook').fadeIn();
            });
        }

    }

};

$(window).resize(function() {
    Chat.resizeChatContent();
    Chat.resizeLoginContent();
});
$(document).ready(function(){
    Chat.ReadyFunction();
});
//$(window).load(function() {
//    //Chat.start();
//    Chat.EnableScrollBar();
//});

function ActionLogin(text){
    /*    alert('login ');*/
    var  dbLogin = new Database();
    /*    alert(text);*/
    if(text==null)
    {
        /* login khong dung facebook */
        /*        alert('----------------- login dung web --------------------');*/
        var valueLogin = dbLogin.query({api: '/auth/login/', data: {
            'email':$('#email').val(),
            'password':$('#password').val(),
            'package':'123123',
            'deviceid':'123123',
            'timeout':'300000'
        },headers : {'x-nahi-token': 'apikeytest'}});

        valueLogin.success(function(data){
            localData.set('Account',data);
            $('#login').hide();
            if(localData.get('gamelanding') == 'boot'){
                window.history.back();
            }
            else if(localData.get('gamelanding')=='toanthantoc') {
                Chat.start(domainAPI);
            }
        });
        valueLogin.error(function(data){
           log('login fail');

        });
        return true;
    }
    else
    {
        /* login dung facebook */
        /*        alert('----------------- login dung facebook --------------------');*/
        var valueLoginFaceBook = dbLogin.query({api: '/auth/loginfb', data: {
            'access_token': text,
            'package':'123123',
            'deviceid':'123123',
            'timeout':'300000'
        },
            headers : {'x-nahi-token': 'apikeytest'}});
        valueLoginFaceBook.success(function(data,status){
            localData.set('Account',data);
            $('#login').hide();
            if(localData.get('gamelanding') == 'boot'){
                window.history.back();
            }
            else if(localData.get('gamelanding')=='toanthantoc') {
                Chat.start(domainAPI);
            }
        });
        valueLoginFaceBook.error(function(xhr, status, error){
            log('login fail');
        });
        if(valueLoginFaceBook.readyState==1 && valueLoginFaceBook.responseText==undefined)
        {
            //this.createPopup('Hệ thống sự số, mời bạn quay lại sau');
        }

        return true;
    }
}