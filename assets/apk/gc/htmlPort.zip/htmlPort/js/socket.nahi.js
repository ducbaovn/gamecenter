var SocketNahi = {
    socket: null,
    //domain: domainAPI,
    connect: function(domain,cb){

        if(domain == undefined){
            domain = domainAPI;
        }
        var that = this;
        if(!that.socket){
            that.socket = io.connect(domain);
            that.socket.on('connect', function(){
                console.log('----------------------Connected---------------------');
                console.log(that.socket);
                cb(that.socket);
            });
        }else{
            if(that.socket && !that.socket.socket.connected){
                that.socket.reconnect;
                that.socket.on('connect', function(){
                    cb(that.socket);
                });
            }else{
                cb(that.socket);
            }
        }
        return that.socket;
    }
};

//
//function processSocket(socket){
//    socket.post('/////',function(){
//
//    });
//};
//SocketNahi.domain = 'aaaaa';
//SocketNahi.connect(processSocket);