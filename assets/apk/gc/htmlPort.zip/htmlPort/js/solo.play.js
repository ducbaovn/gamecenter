/**
 * Created by thanhpt fron Nahi on 12/22/2014.
 * @author: tpt2213
 */

ToanThanToc.SoloPlay = function (game) {
};

ToanThanToc.SoloPlay.prototype = {
    /* pop up */
    tweenOpen1:null,
    tweenClose1:null,

    popupBgNo:null,
    btnClose:null,
    btnOffSound:null,
    btnOnSound:null,
    bgPopupSound:null,

    /* count Down */
    countDownImg:null,
    countDown:null,
    isCount:false,

    btnSettingSoloPlay:null,
    btnSettingTuyChonSP:null,
    btnSettingTiepTucSP:null,
    btnSettingKhoiDongSP:null,
    btnSoundSP:null,

    /* animation animal */

    animalImage1:null,
    animalImage2:null,
    animalNum1:null,
    animalNum2:null,
    arrayAnimal:['anmiSloloLion','anmiSloloMonkey','anmiSloloGiraffe','anmiSloloOwl','anmiSloloRabbit'],

    /* Question */
    topQuestionT:null,
    topOptionT1:null,
    topOptionT2:null,
    topOptionT3:null,

    topQuestionB:null,
    topOptionB1:null,
    topOptionB2:null,
    topOptionB3:null,

    topTextQuestionT:null,
    topTextOptionT1:null,
    topTextOptionT2:null,
    topTextOptionT3:null,

    topTextQuestionB:null,
    topTextOptionB1:null,
    topTextOptionB2:null,
    topTextOptionB3:null,

    backgroundScorceT:null,
    backgroundScorceB:null,

    timmer:null,

    secondsPlay:null,

    preload : function() {
        ToanThanToc.popupShow=0;
    },

    create : function() {

        /*hide button home chat*/
        $('#homeVirtual').hide();

        /*   Phan MenuSoloMenuSolo    */
        var solo1=ToanThanToc.SoloPlay.prototype;

        ToanThanToc.SoloPlay.prototype.multiBoardFull=ToanThanToc.game.add.sprite(0, ToanThanToc.game.world.centerY - 299/2 ,'multiBoardFull');

        if(ToanThanToc.isEndSolo==false)
            solo1.CreatePopup();
        else
            solo1.CreateAminationCountDown();
        ToanThanToc.SoloPlay.prototype.CreateNewTime();

        log('ToanThanToc.soloPlayScore== '+ToanThanToc.soloPlayScore);
        log('ToanThanToc.soloPlayTime== '+ToanThanToc.soloPlayTime);
        ToanThanToc.SoloPlay.prototype.texTimeDesT = ToanThanToc.game.add.bitmapText(
            735,570,'num', '00:00,000',40);
        ToanThanToc.SoloPlay.prototype.texTimeDesT.rotation=3.14;

        ToanThanToc.SoloPlay.prototype.texTimeDesB = ToanThanToc.game.add.bitmapText(
            65,660,'num', '00:00,000',40);
        ToanThanToc.SoloPlay.prototype.texTimeDesT.visible=false;
        ToanThanToc.SoloPlay.prototype.texTimeDesB.visible=false;
    },

    CreateMultiPointer:function(){
        ToanThanToc.game.input.maxPointers = 10;
        ToanThanToc.game.input.multiplier = 10;
        ToanThanToc.game.input.pointer3=new Phaser.Pointer(ToanThanToc.game,3);
        ToanThanToc.game.input.pointer4=new Phaser.Pointer(ToanThanToc.game,4);
        ToanThanToc.game.input.pointer5=new Phaser.Pointer(ToanThanToc.game,5);
        ToanThanToc.game.input.pointer6=new Phaser.Pointer(ToanThanToc.game,6);
        ToanThanToc.game.input.pointer7=new Phaser.Pointer(ToanThanToc.game,7);
        ToanThanToc.game.input.pointer8=new Phaser.Pointer(ToanThanToc.game,8);
        ToanThanToc.game.input.pointer9=new Phaser.Pointer(ToanThanToc.game,9);
        ToanThanToc.game.input.pointer10=new Phaser.Pointer(ToanThanToc.game,10);

        ToanThanToc.game.input.pointers=[
            ToanThanToc.game.input.pointer1,
            ToanThanToc.game.input.pointer2,
            ToanThanToc.game.input.pointer3,
            ToanThanToc.game.input.pointer4,
            ToanThanToc.game.input.pointer5,
            ToanThanToc.game.input.pointer6,
            ToanThanToc.game.input.pointer7,
            ToanThanToc.game.input.pointer8,
            ToanThanToc.game.input.pointer9,
            ToanThanToc.game.input.pointer10
        ];
    },

    ResetPointer:function(){
        ToanThanToc.game.input.maxPointers = 1;
        ToanThanToc.game.input.multiplier = 1;
        ToanThanToc.game.input.pointer3=null;
        ToanThanToc.game.input.pointer4=null;
        ToanThanToc.game.input.pointer5=null;
        ToanThanToc.game.input.pointer6=null;
        ToanThanToc.game.input.pointer7=null;
        ToanThanToc.game.input.pointer8=null;
        ToanThanToc.game.input.pointer9=null;
        ToanThanToc.game.input.pointer10=null;

        ToanThanToc.game.input.pointers=[
            ToanThanToc.game.input.pointer1,
            ToanThanToc.game.input.pointer2
        ];
    },

    CreateNewTime:function(){
        ToanThanToc.SoloPlay.prototype.timmer = new Phaser.Time(ToanThanToc.game);
        ToanThanToc.SoloPlay.prototype.ResetTimer();
    },

    PauseTimer:function(){
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events.pause();
    },

    ResetTimer : function(){
        if(ToanThanToc.SoloPlay.prototype.texTimeDesT!=undefined)
        {
            ToanThanToc.SoloPlay.prototype.texTimeDesT.visible=false; ToanThanToc.SoloPlay.prototype.texTimeDesT.setText('00:00,000');
        }
        if(ToanThanToc.SoloPlay.prototype.texTimeDesB!=undefined) {
            ToanThanToc.SoloPlay.prototype.texTimeDesB.visible = false;ToanThanToc.SoloPlay.prototype.texTimeDesB.setText('00:00,000');
        }
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events.pause();
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events.nextTick=0;
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events._pauseStarted=0;
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events._pauseTotal=0;
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events._started=0;
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events._now=0;
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events.timeCap=0;
    },

    ResumeTimer:function(){
       // if(ToanThanToc.soloPlayTime!=0)
        {
            ToanThanToc.SoloPlay.prototype.texTimeDesT.visible=true;
            ToanThanToc.SoloPlay.prototype.texTimeDesB.visible=true;
        }
        ToanThanToc.SoloPlay.prototype.timmer.game.time.events.resume();
    },

    ShowTime:function(textTime){
        ToanThanToc.SoloPlay.prototype.okok = parseFloat(ToanThanToc.soloPlayTime - textTime).toFixed(3);
        var arrTime = ToanThanToc.SoloPlay.prototype.okok.toString().split('.');
        var hour = (parseInt(arrTime[0]/3600)==0)?0:parseInt(arrTime[0]/3600);
        var mi =   (parseInt((arrTime[0]%3600)/60)==0)?0:parseInt((arrTime[0]%3600)/60);
        var sec =  (parseInt((arrTime[0]%3600)%60)==0)?0:parseInt((arrTime[0]%3600)%60);
        var miSec = (arrTime.length==2)? (arrTime[1].length>2)?arrTime[1]: arrTime[1] : 0 ;
        return (
            (((hour*60 + mi).toString().length==1)?'0'+(hour*60 + mi).toString():(hour*60 + mi).toString())
            +':'+((sec.toString().length==1)?'0'+sec.toString():sec.toString())
            +','+miSec.toString()
            );
    },
    ShowTimeTo:function(textTime){
        ToanThanToc.SoloPlay.prototype.okokTo = parseFloat(textTime).toFixed(3);
        var arrTime = ToanThanToc.SoloPlay.prototype.okokTo.toString().split('.');
        var hour = (parseInt(arrTime[0]/3600)==0)?0:parseInt(arrTime[0]/3600);
        var mi =   (parseInt((arrTime[0]%3600)/60)==0)?0:parseInt((arrTime[0]%3600)/60);
        var sec =  (parseInt((arrTime[0]%3600)%60)==0)?0:parseInt((arrTime[0]%3600)%60);
        var miSec = (arrTime.length==2)? (arrTime[1].length>2)?arrTime[1]: arrTime[1] : 0 ;
        return (
            (((hour*60 + mi).toString().length==1)?'0'+(hour*60 + mi).toString():(hour*60 + mi).toString())
            +':'+((sec.toString().length==1)?'0'+sec.toString():sec.toString())
            +','+miSec.toString()
            );
    },

    render:function() {
//       ToanThanToc.game.debug.text('Time until event time now: ' +  ToanThanToc.SoloPlay.prototype.timmer.game.time.now, 32, 32);
//       ToanThanToc.game.debug.text('event seconds: ' +  ToanThanToc.SoloPlay.prototype.timmer.game.time.events.seconds, 32, 64);
        if(ToanThanToc.soloPlayTime!=0)
        {
            ToanThanToc.SoloPlay.prototype.texTimeDesT.setText(
                ToanThanToc.SoloPlay.prototype.ShowTime (parseFloat(ToanThanToc.SoloPlay.prototype.timmer.game.time.events.seconds).toFixed(3))
            );
            ToanThanToc.SoloPlay.prototype.texTimeDesB.setText(
                ToanThanToc.SoloPlay.prototype.ShowTime (parseFloat(ToanThanToc.SoloPlay.prototype.timmer.game.time.events.seconds).toFixed(3))
            );
        }
        else
        {
            ToanThanToc.SoloPlay.prototype.texTimeDesT.setText(
                ToanThanToc.SoloPlay.prototype.ShowTimeTo (parseFloat(ToanThanToc.SoloPlay.prototype.timmer.game.time.events.seconds).toFixed(3))
            );
            ToanThanToc.SoloPlay.prototype.texTimeDesB.setText(
                ToanThanToc.SoloPlay.prototype.ShowTimeTo (parseFloat(ToanThanToc.SoloPlay.prototype.timmer.game.time.events.seconds).toFixed(3))
            );
        }
        if(ToanThanToc.soloPlayTime!=0)
            if(parseInt(ToanThanToc.SoloPlay.prototype.timmer.game.time.events.seconds)>=ToanThanToc.soloPlayTime)
                if(ToanThanToc.SoloPlay.prototype.OffGameTime()==false)
                    return false;
    },

    update : function() {
        if(ToanThanToc.SoloPlay.prototype.isCount)
        {
            ToanThanToc.SoloPlay.prototype.countDownImg.destroy();
            ToanThanToc.SoloPlay.prototype.isCount=false;
            delete (ToanThanToc.SoloPlay.prototype.countDown);
            ToanThanToc.SoloPlay.prototype.isNameClick=null;
            ToanThanToc.SoloPlay.prototype.ResumeTimer();
            this.CreatePageMenuSolo();
        }
    },

    /* Get name From array animation */
    GetNameAnimation:function(name){
        for(var t =0;t<ToanThanToc.SoloPlay.prototype.arrayAnimal.length;t++ )
        {
            if(name == t)
                return ToanThanToc.SoloPlay.prototype.arrayAnimal[name];
        }
    },

    CreatePopup:function(){
        log(ToanThanToc.game.world.height);
        log(ToanThanToc.game.world.centerY);

        ToanThanToc.SoloPlay.prototype.bgPPSL =  ToanThanToc.game.add.image(0,0, 'bgPopupOk');
        ToanThanToc.SoloPlay.prototype.bgPPSL.inputEnabled=true;
        ToanThanToc.SoloPlay.prototype.bgPPSL.events.onInputDown.add(ToanThanToc.SoloPlay.prototype.CloseWindow);
        ToanThanToc.Menu.prototype.BacgroundForPopup();

        ToanThanToc.SoloPlay.prototype.bgPopupSound  = ToanThanToc.game.add.image(ToanThanToc.game.world.centerX - 631/2 ,ToanThanToc.game.world.centerY - 445/2-35  , 'bgSLPopupSound');

        var w = ToanThanToc.SoloPlay.prototype.bgPopupSound.width;
        var h = ToanThanToc.SoloPlay.prototype.bgPopupSound.height;

        ToanThanToc.SoloPlay.prototype.bgPopupSound.width =ToanThanToc.SoloPlay.prototype.bgPopupSound.width - 630;
        ToanThanToc.SoloPlay.prototype.bgPopupSound.height = ToanThanToc.SoloPlay.prototype.bgPopupSound.height  -395;
        ToanThanToc.SoloPlay.prototype.bgPopupSound.x=ToanThanToc.game.world.centerX - ToanThanToc.SoloPlay.prototype.bgPopupSound.width/2;
        ToanThanToc.SoloPlay.prototype.bgPopupSound.y=ToanThanToc.game.world.centerY - ToanThanToc.SoloPlay.prototype.bgPopupSound.height/2;

        ToanThanToc.SoloPlay.prototype.btnOkPlaySL = ToanThanToc.game.add.button(215, 287, 'btnOkPlaySL', this.ActionClickSoloPlay, ToanThanToc.game);
        //ToanThanToc.SoloPlay.prototype.btnClose = ToanThanToc.game.add.button(525, 15, 'btnOff', this.ActionClickSoloPlay, ToanThanToc.game);
        //ToanThanToc.SoloPlay.prototype.btnOnSound = ToanThanToc.game.add.button(125, 230, 'onSound', this.ActionClickSoloPlay, ToanThanToc.game);
        //ToanThanToc.SoloPlay.prototype.btnOffSound = ToanThanToc.game.add.button(350, 230, 'offSound', this.ActionClickSoloPlay, ToanThanToc.game);

        ToanThanToc.SoloPlay.prototype.bgPopupSound.addChild(ToanThanToc.SoloPlay.prototype.btnOkPlaySL);
//        ToanThanToc.SoloPlay.prototype.bgPopupSound.addChild(ToanThanToc.SoloPlay.prototype.btnOffSound);
//        ToanThanToc.SoloPlay.prototype.bgPopupSound.addChild(ToanThanToc.SoloPlay.prototype.btnOnSound);
        ToanThanToc.SoloPlay.prototype.tweenOpen1 = ToanThanToc.game.add.tween( ToanThanToc.SoloPlay.prototype.bgPopupSound).to( { width:w, height:h,x:ToanThanToc.game.world.centerX - 631/2 ,y:ToanThanToc.game.world.centerY - 445/2-35  }, 5, Phaser.Easing.Sinusoidal.Out, true);
        ToanThanToc.popupShow = true;
    },

    CreateAminationCountDown:function(){
         ToanThanToc.SoloPlay.prototype.countDownImg = ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-185 , ToanThanToc.game.world.centerY-185  , 'countDown');
         ToanThanToc.SoloPlay.prototype.countDown =   ToanThanToc.SoloPlay.prototype.countDownImg.animations.add('walk');

         ToanThanToc.SoloPlay.prototype.countDown.onStart.add( this.AnimationStarted, ToanThanToc.game);
         ToanThanToc.SoloPlay.prototype.countDown.onLoop.add(this.AnimationLooped, ToanThanToc.game);
         ToanThanToc.SoloPlay.prototype.countDown.onComplete.add(this.AnimationStopped, ToanThanToc.game);

         /// true se co loop
         ToanThanToc.SoloPlay.prototype.countDown.play(3, false);
    },

    CreateAminationAnimalAndQ:function(){
        ToanThanToc.SoloPlay.prototype.CreateAminationAnimal();
        ToanThanToc.SoloPlay.prototype.CreatePageQuestion();
    },

    CreateAminationAnimal:function(){
        ToanThanToc.SoloPlay.prototype.animalNum1 = ToanThanToc.game.rnd.integerInRange(1,5);
        ToanThanToc.SoloPlay.prototype.animalNum2 = ToanThanToc.game.rnd.integerInRange(1,5);
        while(ToanThanToc.SoloPlay.prototype.animalNum1==ToanThanToc.SoloPlay.prototype.animalNum2)
        {
            ToanThanToc.SoloPlay.prototype.animalNum1 = ToanThanToc.game.rnd.integerInRange(1,5);
            ToanThanToc.SoloPlay.prototype.animalNum2 = ToanThanToc.game.rnd.integerInRange(1,5);
            if(ToanThanToc.SoloPlay.prototype.animalNum1!=ToanThanToc.SoloPlay.prototype.animalNum2)
                break;
        }

        log('animal1= '+ToanThanToc.SoloPlay.prototype.animalNum1);
        log('animal2= '+ToanThanToc.SoloPlay.prototype.animalNum2);

        ToanThanToc.SoloPlay.prototype.animalNum1 = ToanThanToc.SoloPlay.prototype.GetNameAnimation(ToanThanToc.SoloPlay.prototype.animalNum1-1);
        ToanThanToc.SoloPlay.prototype.animalNum2 = ToanThanToc.SoloPlay.prototype.GetNameAnimation(ToanThanToc.SoloPlay.prototype.animalNum2-1);

        ToanThanToc.SoloPlay.prototype.animalImage1 = ToanThanToc.game.add.sprite(250, 158,  ToanThanToc.SoloPlay.prototype.animalNum1+ 'Right');
        ToanThanToc.SoloPlay.prototype.animalImage1.rotation=3.14;
        ToanThanToc.SoloPlay.prototype.animalImage1.animations.add('walk');
        ToanThanToc.SoloPlay.prototype.animalImage1.animations.play('walk', 3, true);

        ToanThanToc.SoloPlay.prototype.animalImage2 = ToanThanToc.game.add.sprite(ToanThanToc.game.world.width -230,ToanThanToc.game.world.height-158  ,  ToanThanToc.SoloPlay.prototype.animalNum2+ 'Right');
        ToanThanToc.SoloPlay.prototype.animalImage2.animations.add('walk');
        ToanThanToc.SoloPlay.prototype.animalImage2.animations.play('walk', 3, true);
    },

    CountPhepTinh:function(){
        var i=0;
        var tam = true;
        if(tam==ToanThanToc.plusSolo)
            i++;
        if(tam==ToanThanToc.minusSolo)
            i++;
        if(tam==ToanThanToc.multiSolo)
            i++;
        if(tam==ToanThanToc.divisionSolo)
            i++;

        return i;

    },

    CreatePhepTinh:function(){
        var arrPheptinh = [ToanThanToc.plusSolo,ToanThanToc.minusSolo,ToanThanToc.multiSolo,ToanThanToc.divisionSolo];
        var arrPheptinhChon = [];
        var idPhepTinh=null;
       /* chi 1 phep tinh */
       if(ToanThanToc.SoloPlay.prototype.CountPhepTinh()==1)
       {
           if(ToanThanToc.plusSolo)
               return '+';
           else if(ToanThanToc.minusSolo)
               return '-';
           else if(ToanThanToc.multiSolo)
               return 'x';
           else if(ToanThanToc.divisionSolo)
               return ':';
       }
       else
       {
            for(var i=0;i<arrPheptinh.length;i++)
            {
                if(arrPheptinh[i]==true)
                {
                    if(i==0)
                        arrPheptinhChon.push('+');
                    else if(i==1)
                        arrPheptinhChon.push('-');
                    else if(i==2)
                        arrPheptinhChon.push('x');
                    else if(i==3)
                        arrPheptinhChon.push(':');
                }
            }
            if(arrPheptinhChon.length==2){
               idPhepTinh = ToanThanToc.game.rnd.integerInRange(0,1);
            }
            else if(arrPheptinhChon.length==3){
                idPhepTinh = ToanThanToc.game.rnd.integerInRange(0,2);
            }
            else if(arrPheptinhChon.length==4){
                idPhepTinh = ToanThanToc.game.rnd.integerInRange(0,3);
            }
                return arrPheptinhChon[idPhepTinh];
       }
    },

    arrU:[],

    RandomNumberB: function( a) {
        var res = 1;

        ToanThanToc.SoloPlay.prototype.arrU = ToanThanToc.SoloPlay.prototype.GetArrayDivisor(a);
        log('arrU= '+ ToanThanToc.SoloPlay.prototype.arrU.length);
        var index =  ToanThanToc.game.rnd.integerInRange(0,ToanThanToc.SoloPlay.prototype.arrU.length-1);
        log('index '+index);
        res = ToanThanToc.SoloPlay.prototype.arrU[index];
        while (res > 99 || (ToanThanToc.SoloPlay.prototype.arrU.length-1 > 2 && (res == 1 || res == a))) {
            index =  ToanThanToc.game.rnd.integerInRange(0,ToanThanToc.SoloPlay.prototype.arrU.length-1);
            res = ToanThanToc.SoloPlay.prototype.arrU[index];
        }
        return res;
    },

    GetArrayDivisor: function (n) {
        var x = n;
        var arrDivisor = [];
        arrDivisor.push(1);
        arrDivisor.push(n);
        for (var i = 2; i <= x - 1; i++) {
            if (n % i == 0) {
                arrDivisor.push(i);
                arrDivisor.push(n / i);
                x = (n / i) - 1;
            }
        }
        log("arrDivisor: " + arrDivisor);
        return arrDivisor;
    },

    RandomQuestion: function(operation){
        var a = 0;
        var b = 0;
        var result = 0;

        var MIN_MODE = 0;
        var MIN_MODE_PRE = 0;
        var MAX_MODE = 9;
        var MAX_MODE_B = 9;
        if (ToanThanToc.isLevelSolo=='EASY') {
            MIN_MODE_PRE = 0;
            MIN_MODE = 0;
            MAX_MODE = 9;
            MAX_MODE_B = 9;
        } else if (ToanThanToc.isLevelSolo=='MEDIUM') {
            MIN_MODE_PRE = 10;
            MIN_MODE = 0;
            MAX_MODE = 99;
            MAX_MODE_B = 99;
        } else if (ToanThanToc.isLevelSolo=='HARD') {
            MIN_MODE_PRE = 100;
            MIN_MODE = 0;
            MAX_MODE = 999;
            MAX_MODE_B = 99;
        }

        a = ToanThanToc.game.rnd.integerInRange(MIN_MODE_PRE, MAX_MODE);

        if (operation=='+') {
            b = ToanThanToc.game.rnd.integerInRange(MIN_MODE, MAX_MODE_B);
            result = a + b;
        } else if (operation=='-') {
            b = ToanThanToc.game.rnd.integerInRange(MIN_MODE, MAX_MODE_B);
            result = a - b;
        } else if (operation=='x') {
            b = ToanThanToc.game.rnd.integerInRange(MIN_MODE, MAX_MODE_B);
            result = a * b;
        } else {
            if (ToanThanToc.isLevelSolo=='EASY'&& a == 0)
                a = ToanThanToc.game.rnd.integerInRange(1, MAX_MODE);
            b = ToanThanToc.SoloPlay.prototype.RandomNumberB(a);
            result = a / b;
        }
        var arrDe = [];
        arrDe.push(a);
        arrDe.push(operation);
        arrDe.push(b);
        arrDe.push(result);
        return arrDe;
    },

    /* Them diem */
    AddThemDiemOTren: function(){
        ToanThanToc.scoreT = ToanThanToc.game.add.bitmapText(ToanThanToc.game.world.centerX ,-700,'num',
            (ToanThanToc.soloPlayScore!=0)?ToanThanToc.scoreTam1.toString()+'/'+ToanThanToc.soloPlayScore.toString():ToanThanToc.scoreTam1.toString(),
            (ToanThanToc.soloPlayScore!=0)? 40 :50
        );
        ToanThanToc.scoreT.rotation=3.14;
        ToanThanToc.scoreT.x = (ToanThanToc.soloPlayScore==0)?ToanThanToc.game.world.centerX-ToanThanToc.scoreT.width -150
            :ToanThanToc.game.world.centerX + ToanThanToc.scoreT.width -250;
        ToanThanToc.scoreT.y = (ToanThanToc.soloPlayScore==0)? ToanThanToc.game.world.centerY - ToanThanToc.scoreT.height -1
            :ToanThanToc.game.world.centerY - ToanThanToc.scoreT.height -10;
        ToanThanToc.SoloPlay.prototype.traLoiSaiT=null;
    },

    /* Them diem */
    AddThemDiemODuoi: function(){
        ToanThanToc.scoreB = ToanThanToc.game.add.bitmapText(ToanThanToc.game.world.centerX, -700,'num',
            (ToanThanToc.soloPlayScore!=0)?ToanThanToc.scoreTam2.toString()+'/'+ToanThanToc.soloPlayScore.toString():ToanThanToc.scoreTam2.toString(),
            (ToanThanToc.soloPlayScore!=0)? 40 :50
        );
        ToanThanToc.scoreB.x = (ToanThanToc.soloPlayScore==0)? ToanThanToc.game.world.centerX + ToanThanToc.scoreB.width + 150
            :ToanThanToc.game.world.centerX + ToanThanToc.scoreB.width +75;
        ToanThanToc.scoreB.y =  (ToanThanToc.soloPlayScore==0)? ToanThanToc.game.world.centerY + ToanThanToc.scoreB.height  +4
            : ToanThanToc.game.world.centerY + ToanThanToc.scoreB.height +10;
        ToanThanToc.SoloPlay.prototype.traLoiSaiB=null;
    },

    CreatePageQuestion: function(){
        log('khoi dong lai co vao CreatePageQuestion');

        ToanThanToc.SoloPlay.prototype.CreateQuestion();

        //<editor-fold desc="tao play 1">
        var Solo = ToanThanToc.SoloPlay.prototype;

        Solo.topQuestionT = ToanThanToc.game.add.image(ToanThanToc.game.world.centerX + 616/2,ToanThanToc.game.world.centerY - 170/3-98,'topQuestionSL1');
        Solo.topQuestionT.rotation=3.14;

        Solo.topOptionT1 = ToanThanToc.game.add.button( -10, 190,'topOptionT1',null,ToanThanToc.game);
        Solo.topOptionT1.events.onInputDown.add(Solo.ActionClickOption);
        Solo.topOptionT2 = ToanThanToc.game.add.button(215,190,'topOptionT2',null,ToanThanToc.game);
        Solo.topOptionT2.events.onInputDown.add(Solo.ActionClickOption);
        Solo.topOptionT3 = ToanThanToc.game.add.button(440,190,'topOptionT3',null,ToanThanToc.game);
        Solo.topOptionT3.events.onInputDown.add(Solo.ActionClickOption);

        Solo.topTextQuestionT = ToanThanToc.game.add.bitmapText(-700,-700,'numBoard',Solo.arrayQ[0].toString() + ' ' +Solo.arrayQ[1].toString() +' '+Solo.arrayQ[2].toString(),80);
        Solo.topTextOptionT1 = ToanThanToc.game.add.bitmapText(-700,-700,'numOption',Solo.arrayA1[0].toString(),46);
        Solo.topOptionT1.name = (Solo.arrayA1[0]==0)?'0':Solo.arrayA1[0];
        Solo.topTextOptionT2 = ToanThanToc.game.add.bitmapText(-700,-700,'numOption',Solo.arrayA1[1].toString(),46);
        Solo.topOptionT2.name = (Solo.arrayA1[1]==0)?'0':Solo.arrayA1[1];
        Solo.topTextOptionT3 = ToanThanToc.game.add.bitmapText(-700,-700,'numOption',Solo.arrayA1[2].toString(),46);
        Solo.topOptionT3.name = (Solo.arrayA1[2]==0)?'0':Solo.arrayA1[2];

        Solo.topQuestionT.addChild(Solo.topOptionT1);
        Solo.topQuestionT.addChild(Solo.topOptionT2);
        Solo.topQuestionT.addChild(Solo.topOptionT3);
        Solo.topQuestionT.addChild(Solo.topTextQuestionT);
        Solo.topQuestionT.addChild(Solo.topTextOptionT1);
        Solo.topQuestionT.addChild(Solo.topTextOptionT2);
        Solo.topQuestionT.addChild(Solo.topTextOptionT3);

        Solo.topTextQuestionT.x= Solo.topQuestionT.width/2 - Solo.topTextQuestionT.width/2;
        Solo.topTextQuestionT.y= Solo.topQuestionT.height/2 - Solo.topTextQuestionT.height/2 +11;
        Solo.topTextOptionT1.x= -17 + Solo.topOptionT1.width/2 -Solo.topTextOptionT1.width/2 ;
        Solo.topTextOptionT1.y= 185+Solo.topOptionT1.height/4 +14;
        Solo.topTextOptionT2.x= 208 + Solo.topOptionT2.width/2 -Solo.topTextOptionT2.width/2;
        Solo.topTextOptionT2.y= 185+Solo.topOptionT2.height/4 +14;
        Solo.topTextOptionT3.x= 433 + Solo.topOptionT3.width/2 -Solo.topTextOptionT3.width/2;
        Solo.topTextOptionT3.y= 185+Solo.topOptionT3.height/4 +14;

        var xT = Solo.topQuestionT.x;
        Solo.topQuestionT.x = 1430;

        ToanThanToc.SoloPlay.prototype.tweenTQ = ToanThanToc.game.add.tween(Solo.topQuestionT).to( { x:  xT }, ToanThanToc.timePlayDelay,  Phaser.Easing.Exponential.Out, true);

        if(ToanThanToc.scoreTam1==-1)
        {
            ToanThanToc.scoreTam1 = (ToanThanToc.scoreTam1==-1)?ToanThanToc.scoreTam1=0:ToanThanToc.scoreTam1;
            ToanThanToc.SoloPlay.prototype.AddThemDiemOTren();
        }

        // </editor-fold>

        //<editor-fold desc="tao play 2">
        /*     luaDao1 =  dapAn-ToanThanToc.game.rnd.integerInRange(dASai1,dASai2);luaDao2 =  dapAn+ToanThanToc.game.rnd.integerInRange(dASai1,dASai2);
         while(luaDao1==luaDao2||luaDao1==dapAn||luaDao2==dapAn)
         {
         luaDao1 =  dapAn-ToanThanToc.game.rnd.integerInRange(20-dASai1,20+dASai2);
         luaDao2 =  dapAn+ToanThanToc.game.rnd.integerInRange(20-dASai1,20+dASai2);
         if(luaDao1!=luaDao2&&luaDao1!=dapAn&&luaDao2!=dapAn)
         break;
         }*/


        Solo.topQuestionB = ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX- 616/2 +7 ,ToanThanToc.game.world.centerY+40 + 125,'topQuestionSL1');

        Solo.topOptionB1 = ToanThanToc.game.add.button( -10,185,'topOptionB1',null,ToanThanToc.game);
        Solo.topOptionB1.events.onInputDown.add(Solo.ActionClickOption);
        Solo.topOptionB2 = ToanThanToc.game.add.button(215,185,'topOptionB2',null,ToanThanToc.game);
        Solo.topOptionB2.events.onInputDown.add(Solo.ActionClickOption);
        Solo.topOptionB3 = ToanThanToc.game.add.button(440,185,'topOptionB3',null,ToanThanToc.game);
        Solo.topOptionB3.events.onInputDown.add(Solo.ActionClickOption);

        Solo.topTextQuestionB = ToanThanToc.game.add.bitmapText(-700,-700,'numBoard',Solo.arrayQ[0].toString() + ' ' +Solo.arrayQ[1].toString() +' '+Solo.arrayQ[2].toString(),80);
        Solo.topTextOptionB1 = ToanThanToc.game.add.bitmapText(-700,-700,'numOption',Solo.arrayA2[0].toString(),46);
        Solo.topOptionB1.name = (Solo.arrayA2[0]==0)?'0':Solo.arrayA2[0];
        Solo.topTextOptionB2 = ToanThanToc.game.add.bitmapText(-700,-700,'numOption',Solo.arrayA2[1].toString(),46);
        Solo.topOptionB2.name = (Solo.arrayA2[1]==0)?'0':Solo.arrayA2[1];
        Solo.topTextOptionB3 = ToanThanToc.game.add.bitmapText(-700,-700,'numOption',Solo.arrayA2[2].toString(),46);
        Solo.topOptionB3.name = (Solo.arrayA2[2]==0)?'0':Solo.arrayA2[2];



        Solo.topQuestionB.addChild(Solo.topOptionB1);
        Solo.topQuestionB.addChild(Solo.topOptionB2);
        Solo.topQuestionB.addChild(Solo.topOptionB3);
        Solo.topQuestionB.addChild(Solo.topTextQuestionB);
        Solo.topQuestionB.addChild(Solo.topTextOptionB1);
        Solo.topQuestionB.addChild(Solo.topTextOptionB2);
        Solo.topQuestionB.addChild(Solo.topTextOptionB3);


        Solo.topTextQuestionB.x= Solo.topQuestionB.width/2 - Solo.topTextQuestionB.width/2  ;
        Solo.topTextQuestionB.y= Solo.topQuestionB.height/2 - Solo.topTextQuestionB.height/2 +11;

        Solo.topTextOptionB1.x= -18 + Solo.topOptionB1.width/2 -Solo.topTextOptionB1.width/2 ;
        Solo.topTextOptionB1.y= 180 + Solo.topOptionB1.height/4 + 14;

        Solo.topTextOptionB2.x= 205 + Solo.topOptionB2.width/2 -Solo.topTextOptionB2.width/2;
        Solo.topTextOptionB2.y= 180 + Solo.topOptionB2.height/4 + 14 ;

        Solo.topTextOptionB3.x= 433 + Solo.topOptionB3.width/2 -Solo.topTextOptionB3.width/2;
        Solo.topTextOptionB3.y= 180 + Solo.topOptionB3.height/4 + 14 ;
        log('ToanThanToc.scoreTam2 = '+ToanThanToc.scoreTam2);
        log('ToanThanToc.scoreTam1 = '+ToanThanToc.scoreTam1);

        var xB = Solo.topQuestionB.x;
        Solo.topQuestionB.x = -600;

        ToanThanToc.SoloPlay.prototype.tweenBQ= ToanThanToc.game.add.tween(Solo.topQuestionB).to( { x:  xB }, ToanThanToc.timePlayDelay,  Phaser.Easing.Exponential.Out, true);

        if(ToanThanToc.scoreTam2==-1) {
            ToanThanToc.scoreTam2 = (ToanThanToc.scoreTam2==-1)?ToanThanToc.scoreTam2=0:ToanThanToc.scoreTam2;
            ToanThanToc.SoloPlay.prototype.AddThemDiemODuoi();
        }
        // </editor-fold>

        /* create button dap an */

        ToanThanToc.SoloPlay.prototype.traLoiDung=null;
        ToanThanToc.SoloPlay.prototype.traLoiSaiT=null;
        ToanThanToc.SoloPlay.prototype.traLoiSaiB=null;
    },

    CreateQuestion:function(){
        if(ToanThanToc.game.input.pointer3==null)
        {
            ToanThanToc.SoloPlay.prototype.CreateMultiPointer();
            log('CreateMultiPointer');
        }

        ToanThanToc.answer=null;
        var dASai1=null;
        var dASai2=null;

        var phepTinh1 = ToanThanToc.SoloPlay.prototype.CreatePhepTinh();
        var arrayDe = ToanThanToc.SoloPlay.prototype.RandomQuestion(phepTinh1);

        var num1 = arrayDe[0];
        var num2 = arrayDe[2];

        var dapAn = arrayDe[3],idDAn1,idDAn2,idDAn3;
        ToanThanToc.answer = dapAn;
        var dapAn11 = dapAn;
        /* random dap an sai  */
        if(ToanThanToc.isLevelSolo=='EASY'){
            dASai1 = 8;
            dASai2 = 13;
        }
        else if(ToanThanToc.isLevelSolo=='MEDIUM'){
            dASai1 = 8;
            dASai2 = 13;
        }
        else if(ToanThanToc.isLevelSolo=='HARD'){
            dASai1 = 8;
            dASai2 = 13;
        }

        var luaDao1 =  dapAn-ToanThanToc.game.rnd.integerInRange(dASai1,dASai2),luaDao2 =  dapAn+ToanThanToc.game.rnd.integerInRange(dASai1,dASai2);
        while(luaDao1==dapAn||luaDao1==luaDao2||luaDao2==dapAn)
        {
            luaDao1 =  dapAn-ToanThanToc.game.rnd.integerInRange(dASai1,dASai2);
            luaDao2 =  dapAn+ToanThanToc.game.rnd.integerInRange(dASai1,dASai2);
            if(luaDao1!=dapAn&&luaDao1!=luaDao2&&luaDao2!=dapAn)
                break;
        }
        var arrDA = [luaDao1,dapAn,luaDao2]; log('arrDA1== '+arrDA);
        idDAn1 = ToanThanToc.game.rnd.integerInRange(0,2);
        idDAn2 = ToanThanToc.game.rnd.integerInRange(0,2);
        while(idDAn2==idDAn1) {
            idDAn2 = ToanThanToc.game.rnd.integerInRange(0,2); if(idDAn2!=idDAn1) break;
        }
        idDAn3 = ToanThanToc.game.rnd.integerInRange(0,2);
        while(idDAn3==idDAn1||idDAn3==idDAn2) {
            idDAn3 = ToanThanToc.game.rnd.integerInRange(0,2); if(idDAn3!=idDAn1&&idDAn3!=idDAn2) break;
        }
        log('gt1 = '+idDAn1 +' gt2 = '+idDAn2+' gt3 = '+idDAn3);
        ToanThanToc.SoloPlay.prototype.arrayA1=[];
        ToanThanToc.SoloPlay.prototype.arrayA1.push(arrDA[idDAn3]);
        ToanThanToc.SoloPlay.prototype.arrayA1.push(arrDA[idDAn2]);
        ToanThanToc.SoloPlay.prototype.arrayA1.push(arrDA[idDAn1]);


        arrDA = [dapAn11,luaDao2,luaDao1];log('arrDA2== '+arrDA);
        idDAn1 = ToanThanToc.game.rnd.integerInRange(0,2);
        idDAn2 = ToanThanToc.game.rnd.integerInRange(0,2);
        while(idDAn2==idDAn1) {
            idDAn2 = ToanThanToc.game.rnd.integerInRange(0,2); if(idDAn2!=idDAn1) break;
        }
        idDAn3 = ToanThanToc.game.rnd.integerInRange(0,2);
        while(idDAn3==idDAn1||idDAn3==idDAn2) {
            idDAn3 = ToanThanToc.game.rnd.integerInRange(0,2); if(idDAn3!=idDAn1&&idDAn3!=idDAn2) break;
        }
        log('gt1 = '+idDAn1 +' gt2 = '+idDAn2+' gt3 = '+idDAn3);
        ToanThanToc.SoloPlay.prototype.arrayA2=[];
        ToanThanToc.SoloPlay.prototype.arrayA2.push(arrDA[idDAn1]);
        ToanThanToc.SoloPlay.prototype.arrayA2.push(arrDA[idDAn2]);
        ToanThanToc.SoloPlay.prototype.arrayA2.push(arrDA[idDAn3]);

        ToanThanToc.SoloPlay.prototype.arrayQ=[];
        ToanThanToc.SoloPlay.prototype.arrayQ.push(num1);
        ToanThanToc.SoloPlay.prototype.arrayQ.push(phepTinh1);
        ToanThanToc.SoloPlay.prototype.arrayQ.push(num2);

    },

    SetFrame:function(item){
        var Solo = ToanThanToc.SoloPlay.prototype;
        Solo.topQuestionT.frame=item;
        Solo.topOptionT1.frame=item;
        Solo.topOptionT2.frame=item;
        Solo.topOptionT3.frame=item;
        Solo.topQuestionB.frame=item;
        Solo.topOptionB1.frame=item;
        Solo.topOptionB2.frame=item;
        Solo.topOptionB3.frame=item;
    },

    ShowQuestion:function(){
        log('show question');
        if(ToanThanToc.soloPlayTime!=0)
            if(parseInt(ToanThanToc.SoloPlay.prototype.timmer.game.time.events.seconds)>=ToanThanToc.soloPlayTime)
                if(ToanThanToc.SoloPlay.prototype.OffGameTime()==false)
                    return false;

        if(ToanThanToc.soloPlayScore!=0)
            if(ToanThanToc.SoloPlay.prototype.OffGameScore()==false)
                return false;
        ToanThanToc.SoloPlay.prototype.SetFrame(0);
        if(ToanThanToc.scoreTam1==-1&&ToanThanToc.scoreTam2==-1)
            ToanThanToc.SoloPlay.prototype.CreateAminationAnimal();
        ToanThanToc.SoloPlay.prototype.CreateQuestion();

        var Solo = ToanThanToc.SoloPlay.prototype;
        Solo.topTextQuestionT.setText(Solo.arrayQ[0].toString() + ' ' +Solo.arrayQ[1].toString() +' '+Solo.arrayQ[2].toString());
        Solo.topTextOptionT1.setText(Solo.arrayA1[0].toString());
        Solo.topOptionT1.name = (Solo.arrayA1[0]==0)?'0':Solo.arrayA1[0];
        Solo.topTextOptionT2.setText(Solo.arrayA1[1].toString());
        Solo.topOptionT2.name = (Solo.arrayA1[1]==0)?'0':Solo.arrayA1[1];
        Solo.topTextOptionT3.setText(Solo.arrayA1[2].toString());
        Solo.topOptionT3.name = (Solo.arrayA1[2]==0)?'0':Solo.arrayA1[2];

        log('Solo.topQuestionT.x = '+Solo.topQuestionT.x);
        Solo.topQuestionT.x = 1430;
        ToanThanToc.SoloPlay.prototype.tweenTQ = ToanThanToc.game.add.tween(Solo.topQuestionT).to( { x:  708  }, ToanThanToc.timePlayDelay,  Phaser.Easing.Exponential.Out, true);
        setTimeout(function(){
            Solo.topTextQuestionT.x= Solo.topQuestionT.width/2 - Solo.topTextQuestionT.width/2;
            Solo.topTextQuestionT.y= Solo.topQuestionT.height/2 - Solo.topTextQuestionT.height/2 +11;
            Solo.topTextOptionT1.x= -17 + Solo.topOptionT1.width/2 -Solo.topTextOptionT1.width/2 ;
            Solo.topTextOptionT1.y= 185+Solo.topOptionT1.height/4 + 14;
            Solo.topTextOptionT2.x= 208 + Solo.topOptionT2.width/2 -Solo.topTextOptionT2.width/2;
            Solo.topTextOptionT2.y= 185+Solo.topOptionT2.height/4 + 14;
            Solo.topTextOptionT3.x= 433 + Solo.topOptionT3.width/2 -Solo.topTextOptionT3.width/2;
            Solo.topTextOptionT3.y= 185+Solo.topOptionT3.height/4 + 14;
            if(ToanThanToc.scoreTam1==-1)
            {
                ToanThanToc.scoreTam1 = (ToanThanToc.scoreTam1==-1)?ToanThanToc.scoreTam1=0:ToanThanToc.scoreTam1;
                ToanThanToc.SoloPlay.prototype.AddThemDiemOTren();
            }
        },ToanThanToc.timePlayDelay-20);

        Solo.topTextQuestionB.setText(Solo.arrayQ[0].toString() + ' ' +Solo.arrayQ[1].toString() +' '+Solo.arrayQ[2].toString());
        Solo.topTextOptionB1.setText(Solo.arrayA2[0].toString());
        Solo.topOptionB1.name = (Solo.arrayA2[0]==0)?'0':Solo.arrayA2[0];
        Solo.topTextOptionB2.setText(Solo.arrayA2[1].toString());
        Solo.topOptionB2.name = (Solo.arrayA2[1]==0)?'0':Solo.arrayA2[1];
        Solo.topTextOptionB3.setText(Solo.arrayA2[2].toString());
        Solo.topOptionB3.name = (Solo.arrayA2[2]==0)?'0':Solo.arrayA2[2];

        log('Solo.topQuestionB.x = '+Solo.topQuestionB.x);
        Solo.topQuestionB.x = -600;
        ToanThanToc.SoloPlay.prototype.tweenBQ= ToanThanToc.game.add.tween(Solo.topQuestionB).to( { x:  99}, ToanThanToc.timePlayDelay,  Phaser.Easing.Exponential.Out, true);
        setTimeout(function(){
            Solo.topTextQuestionB.x= Solo.topQuestionB.width/2 - Solo.topTextQuestionB.width/2  ;
            Solo.topTextQuestionB.y= Solo.topQuestionB.height/2 - Solo.topTextQuestionB.height/2 +11;
            Solo.topTextOptionB1.x= -18 + Solo.topOptionB1.width/2 -Solo.topTextOptionB1.width/2 ;
            Solo.topTextOptionB1.y= 180 + Solo.topOptionB1.height/4 + 14;
            Solo.topTextOptionB2.x= 205 + Solo.topOptionB2.width/2 -Solo.topTextOptionB2.width/2;
            Solo.topTextOptionB2.y= 180 + Solo.topOptionB2.height/4 + 14 ;
            Solo.topTextOptionB3.x= 430 + Solo.topOptionB3.width/2 -Solo.topTextOptionB3.width/2;
            Solo.topTextOptionB3.y= 180 + Solo.topOptionB3.height/4 + 14 ;
            if(ToanThanToc.scoreTam2==-1) {
                ToanThanToc.scoreTam2 = (ToanThanToc.scoreTam2==-1)?ToanThanToc.scoreTam2=0:ToanThanToc.scoreTam2;
                ToanThanToc.SoloPlay.prototype.AddThemDiemODuoi();
            }

            /* create button dap an */

            ToanThanToc.SoloPlay.prototype.traLoiDung=null;
            ToanThanToc.SoloPlay.prototype.traLoiSaiT=null;
            ToanThanToc.SoloPlay.prototype.traLoiSaiB=null;
        },ToanThanToc.timePlayDelay-20);
    },

    OffGameScore:function(){
        if(ToanThanToc.scoreTam1==(ToanThanToc.numQuestion-1)&&ToanThanToc.scoreTam1!=ToanThanToc.scoreTam2 || ToanThanToc.scoreTam2==(ToanThanToc.numQuestion-1)&&ToanThanToc.scoreTam1!=ToanThanToc.scoreTam2)
        {
            ToanThanToc.SoloPlay.prototype.secondsPlay=ToanThanToc.SoloPlay.prototype.texTimeDesT._text;
            ToanThanToc.SoloPlay.prototype.PauseTimer();
            /* Neu thoi gian khong co thi off */
            ToanThanToc.SoloPlay.prototype.ResetTimer();
            ToanThanToc.SoloPlay.prototype.DeleteQuestion();
            ToanThanToc.SoloPlay.prototype.ResetPointer();
            ToanThanToc.game.stage.destroy();
            ToanThanToc.game.state.start('EndSoloPlay');
            return false;
        }
    },

    OffGameTime:function(){
        ToanThanToc.SoloPlay.prototype.secondsPlay=ToanThanToc.SoloPlay.prototype.texTimeDesT._text;
        ToanThanToc.SoloPlay.prototype.PauseTimer();
        /* Neu thoi gian khong co thi off */
        ToanThanToc.SoloPlay.prototype.ResetTimer();
        ToanThanToc.SoloPlay.prototype.DeleteQuestion();
        ToanThanToc.SoloPlay.prototype.ResetPointer();
        ToanThanToc.game.stage.destroy();
        ToanThanToc.game.state.start('EndSoloPlay');
        return false;
    },

    CreatePageMenuSolo: function(){
        if(ToanThanToc.soloPlayTime!=0)
            if(parseInt(ToanThanToc.SoloPlay.prototype.timmer.game.time.events.seconds)>=ToanThanToc.soloPlayTime)
                if(ToanThanToc.SoloPlay.prototype.OffGameTime()==false)
                    return false;

        if(ToanThanToc.soloPlayScore!=0)
            if(ToanThanToc.SoloPlay.prototype.OffGameScore()==false)
                return false;

        if(ToanThanToc.scoreTam1==-1&&ToanThanToc.scoreTam2==-1)
            ToanThanToc.SoloPlay.prototype.CreateAminationAnimalAndQ();
        else
            ToanThanToc.SoloPlay.prototype.ShowQuestion();
        ToanThanToc.SoloPlay.prototype.btnSettingSoloPlay = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX - 123/2,ToanThanToc.game.world.centerY - 123/2  ,'btnSettingESoloPlay',this.ActionClickSettingSoloPlay,ToanThanToc.game);
        log('ToanThanToc.countNumQuestion== '+ToanThanToc.countNumQuestion);
    },

    CreateNewQuestion : function(item){
        log('CreateNewQuestion CreateNewQuestion CreateNewQuestion');
        ToanThanToc.SoloPlay.prototype.DeleteTween();
        ToanThanToc.SoloPlay.prototype.ShowQuestion();
    },

    AnimationStarted : function(sprite, animation){
        log('start animation');
    },

    AnimationLooped : function(sprite, animation){
        log('ko loop');
        animation.loop=false;
    },

    AnimationStopped : function(sprite, animation){
        ToanThanToc.SoloPlay.prototype.isCount=true;
        log('stop animation');
    },

    isNameClick:null,

    ActionClickSoloPlay : function(item){
        if(ToanThanToc.SoloPlay.prototype.isNameClick==null)
        {
            if (ToanThanToc.SoloPlay.prototype.tweenOpen1 &&  ToanThanToc.SoloPlay.prototype.tweenOpen1.isRunning) return false;

            if (ToanThanToc.SoloPlay.prototype.tweenClose1 &&  ToanThanToc.SoloPlay.prototype.tweenClose1.isRunning) return false;
            log(item.key);
/*            if(ToanThanToc.music_touch && SetMusic.touch && item.key!='btnOkPlaySL'&& item.key!='offSound'&& item.key!='onSound')
                ToanThanToc.music_touch.play();*/
            if(item.key=='btnOkPlaySL'  && SetMusic.touch )
                ToanThanToc.music_popupQuit.play();
          /*  if(item.key=='offSound' && SetMusic.touch )
                ToanThanToc.music_popupMainAction.play();
            if(item.key=='onSound' && SetMusic.touch )
                ToanThanToc.music_popupMainAction.play();*/


            if(item.key=='btnOkPlaySL')
            {
                ToanThanToc.SoloPlay.prototype.isNameClick='btnOkPlaySL';
                ToanThanToc.SoloPlay.prototype.btnOkPlaySL.frame = 1;
                setTimeout(function () {
                    ToanThanToc.SoloPlay.prototype.btnOkPlaySL.frame = 0;
                    ToanThanToc.SoloPlay.prototype.CloseWindow();
                }, 50);
            }
            /*if(item.key=='btnOff')
            {
                ToanThanToc.SoloPlay.prototype.isNameClick='btnOff';
                ToanThanToc.SoloPlay.prototype.btnClose.frame = 1;
                setTimeout(function () {
                    ToanThanToc.SoloPlay.prototype.btnClose.frame = 0;
                    ToanThanToc.SoloPlay.prototype.CloseWindow();
                }, 50);
            }
            else if(item.key=='offSound')
            {
                ToanThanToc.SoloPlay.prototype.isNameClick='offSound';
                ToanThanToc.SoloPlay.prototype.btnOffSound.frame = 1;
                setTimeout(function () {
                    ToanThanToc.SoloPlay.prototype.btnOffSound.frame = 0;
                    SetMusic.music = false;
                    SetMusic.touch = false;
                    if (ToanThanToc.music_music.isPlaying)
                        ToanThanToc.music_music.pause();
                    ToanThanToc.SoloPlay.prototype.CloseWindow();
                },50);
            }
            else if(item.key=='onSound')
            {
                ToanThanToc.SoloPlay.prototype.isNameClick='offSound';
                ToanThanToc.SoloPlay.prototype.btnOnSound.frame = 1;
                setTimeout(function () {
                    ToanThanToc.SoloPlay.prototype.btnOnSound.frame = 0;
                    SetMusic.music = true;
                    SetMusic.touch=true;
                    if(ToanThanToc.music_music.paused)
                        ToanThanToc.music_music.resume();
                    ToanThanToc.SoloPlay.prototype.CloseWindow();
                },50);
            }*/
        }
    },

    tweenOpenTuyChon:null,
    tweenCloseTuyChon:null,
    tweenOpenTiepTuc:null,
    tweenCloseTiepTuc:null,
    tweenOpenKhoiDong:null,
    tweenCloseKhoiDong:null,
    tweenOpenSoundSP:null,
    tweenCloseSoundSP:null,

    ActionClickSettingSoloPlay : function(item){

        log('aaaaasssssssssssssssssssssssssssssssssssa');
        var tt = ToanThanToc.SoloPlay.prototype;
        tt.ResetPointer();
        if(ToanThanToc.music_touch && SetMusic.touch && item.key!='btnOff'&& item.key!='offSound'&& item.key!='onSound')
            ToanThanToc.music_touch.play();
        if(ToanThanToc.popupShow==0)
        {
            ToanThanToc.SoloPlay.prototype.SetInputFalseUser1(false);
            ToanThanToc.SoloPlay.prototype.SetInputFalseUser2(false);

            ToanThanToc.SoloPlay.prototype.btnSettingSoloPlay.frame=1;
            setTimeout(function(){
                ToanThanToc.SoloPlay.prototype.bgPopupSound =  ToanThanToc.game.add.image(0,0, 'bgPopupOk');
                ToanThanToc.SoloPlay.prototype.bgPopupSound.inputEnabled=true;
                ToanThanToc.SoloPlay.prototype.bgPopupSound.events.onInputDown.add(ToanThanToc.SoloPlay.prototype.ClickOut);
                ToanThanToc.Menu.prototype.BacgroundForPopup();

                ToanThanToc.SoloPlay.prototype.bgPopupSLP =  ToanThanToc.game.add.image(ToanThanToc.game.world.centerX - 394/2 ,ToanThanToc.game.world.centerY -394/2, 'baseSoloPlay');

                ToanThanToc.SoloPlay.prototype.btnSettingSoloPlay.frame=0;
                ToanThanToc.SoloPlay.prototype.btnSettingSoloPlay.visible=false;


                ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX - 184 +5,ToanThanToc.game.world.centerY - 268 + 89,'btnSettingTiepTucSP',ToanThanToc.SoloPlay.prototype.ActionClickSetting,ToanThanToc.game,0,0,1);
                ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX - 305/2,ToanThanToc.game.world.centerY - 4,'btnSettingKhoiDongSP',ToanThanToc.SoloPlay.prototype.ActionClickSetting,ToanThanToc.game,0,0,1);
                ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX -6,ToanThanToc.game.world.centerY - 267 + 89 ,'btnSettingTuyChonSP',ToanThanToc.SoloPlay.prototype.ActionClickSetting,ToanThanToc.game,0,0,1);

                ToanThanToc.SoloPlay.prototype.btnSoundSP = ToanThanToc.game.add.button(ToanThanToc.game.world.centerX - 184/2,ToanThanToc.game.world.centerY - 188/2 ,'btnSoundSP',ToanThanToc.SoloPlay.prototype.ActionClickSoundSP,ToanThanToc.game);

/*                ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP.scale.x=0.5;
                ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP.scale.y=0.5;
                ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP.scale.x=0.5;
                ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP.scale.y=0.5;
                ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP.scale.x=0.5;
                ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP.scale.y=0.5;
                ToanThanToc.SoloPlay.prototype.btnSoundSP.scale.x=0.5;
                ToanThanToc.SoloPlay.prototype.btnSoundSP.scale.y=0.5;*/

                tt.tweenOpenTuyChon=ToanThanToc.game.add.tween( ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP.scale).to( { x: 1, y: 1 }, 5, Phaser.Easing.Elastic.Out, true);
                tt.tweenOpenTiepTuc=ToanThanToc.game.add.tween( ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP.scale).to( { x: 1, y: 1 }, 5, Phaser.Easing.Elastic.Out, true);
                tt.tweenOpenKhoiDong=ToanThanToc.game.add.tween( ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP.scale).to( { x: 1, y: 1 }, 5, Phaser.Easing.Elastic.Out, true);
                tt.tweenOpenSoundSP=ToanThanToc.game.add.tween( ToanThanToc.SoloPlay.prototype.btnSoundSP.scale).to( { x: 1, y: 1 }, 2, Phaser.Easing.Linear.None, true);

                if(ToanThanToc.music_music.paused) ToanThanToc.SoloPlay.prototype.btnSoundSP.frame=1;
                tt.PauseTimer();
                ToanThanToc.popupShow=1;
            },5);
        }
    },

    ClickOut:function(){
        ToanThanToc.popupShow=0;
        ToanThanToc.SoloPlay.prototype.DeleteSettingSoloPlay();
        setTimeout(function(){
            ToanThanToc.SoloPlay.prototype.bgPopupSound.destroy();
            ToanThanToc.Menu.prototype.HideBgPopupBottom();
            ToanThanToc.Menu.prototype.HideBgPopupTop();
            ToanThanToc.SoloPlay.prototype.bgPopupSLP.destroy();
            ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP.destroy();
            ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP.destroy();
            ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP.destroy();
            ToanThanToc.SoloPlay.prototype.btnSoundSP.destroy();
            ToanThanToc.SoloPlay.prototype.SetInputFalseUser1(true);
            ToanThanToc.SoloPlay.prototype.SetInputFalseUser2(true);
            ToanThanToc.SoloPlay.prototype.btnSettingSoloPlay.visible=true;
            ToanThanToc.SoloPlay.prototype.isNameClick=null;
            ToanThanToc.SoloPlay.prototype.ResumeTimer();
        },6);
    },

    DeletePopUpSettingSPL : function(){
        ToanThanToc.SoloPlay.prototype.bgPopupSound.destroy();
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        ToanThanToc.SoloPlay.prototype.bgPopupSLP.destroy();
        ToanThanToc.SoloPlay.prototype.btnSoundSP.destroy();
        setTimeout(function(){
            ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP.destroy();
            ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP.destroy();
            ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP.destroy();
        },6);

    },

    ActionClickSetting : function(item){
        if(ToanThanToc.SoloPlay.prototype.isNameClick==null)
        {
            if (ToanThanToc.SoloPlay.prototype.tweenOpenTiepTuc &&  ToanThanToc.SoloPlay.prototype.tweenOpenTiepTuc.isRunning) return false;
            if (ToanThanToc.SoloPlay.prototype.tweenCloseTiepTuc &&  ToanThanToc.SoloPlay.prototype.tweenCloseTiepTuc.isRunning) return false;

            if (ToanThanToc.SoloPlay.prototype.tweenOpenTuyChon &&  ToanThanToc.SoloPlay.prototype.tweenOpenTuyChon.isRunning) return false;
            if (ToanThanToc.SoloPlay.prototype.tweenCloseTuyChon &&  ToanThanToc.SoloPlay.prototype.tweenCloseTuyChon.isRunning) return false;

            if (ToanThanToc.SoloPlay.prototype.tweenOpenKhoiDong &&  ToanThanToc.SoloPlay.prototype.tweenOpenKhoiDong.isRunning) return false;
            if (ToanThanToc.SoloPlay.prototype.tweenCloseKhoiDong &&  ToanThanToc.SoloPlay.prototype.tweenCloseKhoiDong.isRunning) return false;

            if (ToanThanToc.SoloPlay.prototype.tweenOpenSoundSP &&  ToanThanToc.SoloPlay.prototype.tweenOpenSoundSP.isRunning) return false;
            if (ToanThanToc.SoloPlay.prototype.tweenCloseSoundSP &&  ToanThanToc.SoloPlay.prototype.tweenCloseSoundSP.isRunning) return false;

            ToanThanToc.popupShow=0;
            log(item.key);
            if( SetMusic.touch )
                ToanThanToc.music_popupMainAction.play();
            if(item.key!='btnSettingTiepTucSP')
            {
                ToanThanToc.scoreT.destroy();
                ToanThanToc.scoreB.destroy();
                ToanThanToc.countNumQuestion=0;
                ToanThanToc.scoreTam1=-1;
                ToanThanToc.scoreTam2=-1;
            }
            if(item.key=='btnSettingTuyChonSP')
            {
                log('234234');
                ToanThanToc.SoloPlay.prototype.isNameClick='btnSettingTuyChonSP';
                //ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP.frame=1;
                ToanThanToc.SoloPlay.prototype.DeleteAnimationAnimal();
                SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
                ToanThanToc.SoloPlay.prototype.DeletePopUpSettingSPL();
                // ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP.frame=0;
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('MenuSolo');

            }
            else if(item.key=='btnSettingTiepTucSP')
            {
                ToanThanToc.SoloPlay.prototype.CreateMultiPointer();
                log('234234-22');
                ToanThanToc.SoloPlay.prototype.isNameClick='btnSettingTiepTucSP';
                ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP.frame=1;
                ToanThanToc.SoloPlay.prototype.DeleteSettingSoloPlay();
                setTimeout(function(){
                    ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP.frame=0;
                    ToanThanToc.SoloPlay.prototype.DeletePopUpSettingSPL();
                    ToanThanToc.SoloPlay.prototype.SetInputFalseUser1(true);
                    ToanThanToc.SoloPlay.prototype.SetInputFalseUser2(true);
                    ToanThanToc.SoloPlay.prototype.btnSettingSoloPlay.visible=true;
                    ToanThanToc.SoloPlay.prototype.isNameClick=null;
                    ToanThanToc.SoloPlay.prototype.ResumeTimer();
                },6);
            }
            else if(item.key=='btnSettingKhoiDongSP')
            {
                log('234234-44');
                ToanThanToc.SoloPlay.prototype.isNameClick='btnSettingKhoiDongSP';
                ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP.frame=1;
                ToanThanToc.SoloPlay.prototype.DeleteSettingSoloPlay();
                setTimeout(function(){
                    ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP.frame=0;
                    ToanThanToc.SoloPlay.prototype.DeleteAnimationAnimal();
                    ToanThanToc.SoloPlay.prototype.DeletePopUpSettingSPL();
                    ToanThanToc.SoloPlay.prototype.btnSettingSoloPlay.visible=true;
                    ToanThanToc.SoloPlay.prototype.ResetTimer();
                    ToanThanToc.SoloPlay.prototype.DeleteQuestion();
                    ToanThanToc.SoloPlay.prototype.CreateAminationCountDown();
                },6);
            }
        }
    },

    ActionClickSoundSP : function(item){
        if(ToanThanToc.SoloPlay.prototype.isNameClick==null)
        {
            if (ToanThanToc.SoloPlay.prototype.tweenOpenSoundSP &&  ToanThanToc.SoloPlay.prototype.tweenOpenSoundSP.isRunning)
            {
                return false;
            }
            if (ToanThanToc.SoloPlay.prototype.tweenCloseSoundSP &&  ToanThanToc.SoloPlay.prototype.tweenCloseSoundSP.isRunning)
            {
                return false;
            }
            ToanThanToc.SoloPlay.prototype.isNameClick='SoundMSP';
            if( SetMusic.touch)
                ToanThanToc.music_popupMainAction.play();
            log('  ActionClickSoundSP '+item.key);
            if (ToanThanToc.music_music.isPlaying){
                ToanThanToc.SoloPlay.prototype.btnSoundSP.frame = 1;
                SetMusic.music = false;
                SetMusic.touch = false;
                ToanThanToc.music_music.pause();
                ToanThanToc.SoloPlay.prototype.isNameClick=null;
            }
            else{
                ToanThanToc.SoloPlay.prototype.btnSoundSP.frame = 0 ;
                SetMusic.music = true;
                SetMusic.touch = true;
                ToanThanToc.music_music.resume();
                ToanThanToc.SoloPlay.prototype.isNameClick=null;
            }
        }
    },

    ActionErrorChangeAmi1 : function(){
        ToanThanToc.SoloPlay.prototype.animalImage1.loadTexture(ToanThanToc.SoloPlay.prototype.animalNum1+ 'Wrong', 0);
        var a =  ToanThanToc.SoloPlay.prototype.animalImage1.animations.add('walk');
        a.onComplete.add(ToanThanToc.SoloPlay.prototype.AnimationErrorStopped1, ToanThanToc.game);
        a.play(10, false);

    },

    ActionErrorChangeAmi2 : function(){
        ToanThanToc.SoloPlay.prototype.animalImage2.loadTexture(ToanThanToc.SoloPlay.prototype.animalNum2+ 'Wrong', 0);
        var a = ToanThanToc.SoloPlay.prototype.animalImage2.animations.add('walk');
        a.onComplete.add(ToanThanToc.SoloPlay.prototype.AnimationErrorStopped2, ToanThanToc.game);
        a.play(10, false);
    },

    AnimationErrorStopped1 : function(item){
        ToanThanToc.SoloPlay.prototype.animalImage1.loadTexture(ToanThanToc.SoloPlay.prototype.animalNum1+ 'Right', 0);
        ToanThanToc.SoloPlay.prototype.animalImage1.animations.add('walk');
        ToanThanToc.SoloPlay.prototype.animalImage1.animations.play('walk', 3, true);
    },

    AnimationErrorStopped2 : function(item){
        ToanThanToc.SoloPlay.prototype.animalImage2.loadTexture(ToanThanToc.SoloPlay.prototype.animalNum2+ 'Right', 0);
        ToanThanToc.SoloPlay.prototype.animalImage2.animations.add('walk');
        ToanThanToc.SoloPlay.prototype.animalImage2.animations.play('walk', 3, true);

    },

    ActionLeftOk :function(item){
        if(item.name==ToanThanToc.answer)
        {
            if(SetMusic.touch)
                ToanThanToc.music_popupMainAction.play();
            ToanThanToc.SoloPlay.prototype.topQuestionT.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionT1.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionT2.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionT3.frame=1;
            ToanThanToc.SoloPlay.prototype.traLoiDung='tren';
            ToanThanToc.scoreT.destroy();
            ToanThanToc.scoreTam1++;
            ToanThanToc.SoloPlay.prototype.AddThemDiemOTren();
            ToanThanToc.SoloPlay.prototype.InputOffOption();
            ToanThanToc.SoloPlay.prototype.hieuUngQT = ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.topQuestionT)
                .to( { x: -80 },ToanThanToc.timePlayDelay, Phaser.Easing.Cubic.Out, true);
            ToanThanToc.SoloPlay.prototype.GoRightBottom();
        }
        else
        {
            if(SetMusic.touch)
                ToanThanToc.music_wrong.play();
            ToanThanToc.SoloPlay.prototype.ActionErrorChangeAmi1();
            ToanThanToc.SoloPlay.prototype.topOptionT1.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionT2.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionT3.frame=1;
            setTimeout(function(){
                ToanThanToc.SoloPlay.prototype.SetInputFalseUser1(true);
                ToanThanToc.SoloPlay.prototype.topQuestionT.frame=0;
                ToanThanToc.SoloPlay.prototype.topOptionT1.frame=0;
                ToanThanToc.SoloPlay.prototype.topOptionT2.frame=0;
                ToanThanToc.SoloPlay.prototype.topOptionT3.frame=0;
            },ToanThanToc.timeDelay);
            /// tru diem
            ToanThanToc.scoreT.destroy();
            if(ToanThanToc.scoreTam1!=0)ToanThanToc.scoreTam1--;
            ToanThanToc.SoloPlay.prototype.AddThemDiemOTren();
        }
    },

    ActionRightOk :function(item){
        if(item.name==ToanThanToc.answer)
        {
            if(SetMusic.touch)
                ToanThanToc.music_popupMainAction.play();
            ToanThanToc.SoloPlay.prototype.topQuestionB.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionB1.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionB2.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionB3.frame=1;
            ToanThanToc.SoloPlay.prototype.traLoiDung='duoi';
            ToanThanToc.scoreB.destroy();
            ToanThanToc.scoreTam2++;
            ToanThanToc.SoloPlay.prototype.AddThemDiemODuoi();
            ToanThanToc.SoloPlay.prototype.InputOffOption();
            ToanThanToc.SoloPlay.prototype.RightBottomTween=ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.topQuestionT)
                .to( { x: -80 },ToanThanToc.timePlayDelay, Phaser.Easing.Cubic.None, true);
            ToanThanToc.SoloPlay.prototype.GoRightBottom();
        }
        else
        {
            if(SetMusic.touch)
                ToanThanToc.music_wrong.play();
            ToanThanToc.SoloPlay.prototype.ActionErrorChangeAmi2();
            ToanThanToc.SoloPlay.prototype.topOptionB1.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionB2.frame=1;
            ToanThanToc.SoloPlay.prototype.topOptionB3.frame=1;
            setTimeout(function(){
                ToanThanToc.SoloPlay.prototype.SetInputFalseUser2(true);
                ToanThanToc.SoloPlay.prototype.topQuestionB.frame=0;
                ToanThanToc.SoloPlay.prototype.topOptionB1.frame=0;
                ToanThanToc.SoloPlay.prototype.topOptionB2.frame=0;
                ToanThanToc.SoloPlay.prototype.topOptionB3.frame=0;
            },ToanThanToc.timeDelay);
            /// tru diem
            ToanThanToc.scoreB.destroy();
            if(ToanThanToc.scoreTam2!=0)ToanThanToc.scoreTam2--;
            ToanThanToc.SoloPlay.prototype.AddThemDiemODuoi();
        }
    },

    traLoiDung:null,
    traLoiSaiT:null,
    traLoiSaiB:null,

    ActionClickOption : function(item){
        var ty = ToanThanToc.SoloPlay.prototype;
        if(ty.tweenTQ!=null&&!ty.tweenTQ.isRunning&&ty.tweenBQ!=null&&!ty.tweenBQ.isRunning)
        {
            if(ToanThanToc.SoloPlay.prototype.traLoiDung!=null)
            {
                log('con dau xanh');
                ToanThanToc.SoloPlay.prototype.traLoiDung=null;
                return false;
            }
            else
            {
                log(item.key);
                if(item.key.split('B').length==2)
                {
                    try{
                        ToanThanToc.SoloPlay.prototype.SetInputFalseUser2(false);
                    }
                    catch (e)
                    {

                    }
                    if(item.name!=ToanThanToc.answer)
                        ToanThanToc.SoloPlay.prototype.topQuestionB.frame=1;
                }
                else
                {
                    try{
                        ToanThanToc.SoloPlay.prototype.SetInputFalseUser1(false);
                    }
                    catch (e)
                    {

                    }
                    if(item.name!=ToanThanToc.answer)
                        ToanThanToc.SoloPlay.prototype.topQuestionT.frame=1;
                }

                if(ToanThanToc.SoloPlay.prototype.traLoiSaiT==null){
                    if(item.key=='topOptionT1'){
                        ToanThanToc.SoloPlay.prototype.traLoiSaiT=item.key;
                        ToanThanToc.SoloPlay.prototype.topOptionT1.frame=1;
                        ToanThanToc.SoloPlay.prototype.ActionLeftOk(ToanThanToc.SoloPlay.prototype.topOptionT1);
                    }
                    else if(item.key=='topOptionT2'){
                        ToanThanToc.SoloPlay.prototype.traLoiSaiT=item.key;
                        ToanThanToc.SoloPlay.prototype.topOptionT2.frame=1;
                        ToanThanToc.SoloPlay.prototype.ActionLeftOk(ToanThanToc.SoloPlay.prototype.topOptionT2);
                    }
                    else if(item.key=='topOptionT3'){
                        ToanThanToc.SoloPlay.prototype.traLoiSaiT=item.key;
                        ToanThanToc.SoloPlay.prototype.topOptionT3.frame=1;
                        ToanThanToc.SoloPlay.prototype.ActionLeftOk(ToanThanToc.SoloPlay.prototype.topOptionT3);
                    }
                }

                if(ToanThanToc.SoloPlay.prototype.traLoiSaiB==null){
                    if(item.key=='topOptionB1'){
                        ToanThanToc.SoloPlay.prototype.traLoiSaiB=item.key;
                        ToanThanToc.SoloPlay.prototype.topOptionB1.frame=1;
                        ToanThanToc.SoloPlay.prototype.ActionRightOk( ToanThanToc.SoloPlay.prototype.topOptionB1);
                    }
                    else if(item.key=='topOptionB2'){
                        ToanThanToc.SoloPlay.prototype.traLoiSaiB=item.key;
                        ToanThanToc.SoloPlay.prototype.topOptionB2.frame=1;
                        ToanThanToc.SoloPlay.prototype.ActionRightOk(ToanThanToc.SoloPlay.prototype.topOptionB2);
                    }
                    else if(item.key=='topOptionB3'){
                        ToanThanToc.SoloPlay.prototype.traLoiSaiB=item.key;
                        ToanThanToc.SoloPlay.prototype.topOptionB3.frame=1;
                        ToanThanToc.SoloPlay.prototype.ActionRightOk(ToanThanToc.SoloPlay.prototype.topOptionB3);
                    }
                }
            }
        }
    },

    RightBottomTween:null,
    tweenTQ:null,
    tweenBQ:null,

    GoRightBottom : function(){
        ToanThanToc.SoloPlay.prototype.RightBottomTween = ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.topQuestionB)
        .to( { x:880 }, ToanThanToc.timePlayDelay,  Phaser.Easing.Linear.None, true);
        ToanThanToc.SoloPlay.prototype.RightBottomTween.onComplete.add(ToanThanToc.SoloPlay.prototype.CreateNewQuestion,ToanThanToc.game);
    },

    InputOffOption : function () {
        ToanThanToc.SoloPlay.prototype.topOptionT1.inputEnabled=false;
        ToanThanToc.SoloPlay.prototype.topOptionT2.inputEnabled=false;
        ToanThanToc.SoloPlay.prototype.topOptionT3.inputEnabled=false;
        ToanThanToc.SoloPlay.prototype.topOptionB1.inputEnabled=false;
        ToanThanToc.SoloPlay.prototype.topOptionB2.inputEnabled=false;
        ToanThanToc.SoloPlay.prototype.topOptionB3.inputEnabled=false;
    },

    CloseWindow : function() {
        ToanThanToc.SoloPlay.prototype.bgPPSL.destroy();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.SoloPlay.prototype.tweenClose1 = ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.bgPopupSound).to( { width : 0, height : 0,x:ToanThanToc.game.world.centerX,y:ToanThanToc.game.world.centerY }, 5, Phaser.Easing.Sinusoidal.In, true);
        ToanThanToc.SoloPlay.prototype.tweenClose1.onComplete.add(ToanThanToc.SoloPlay.prototype.OnCompleteTweenClose);
    },

    OnCompleteTweenClose : function(){
        ToanThanToc.SoloPlay.prototype.bgPopupSound.destroy();
/*        ToanThanToc.SoloPlay.prototype.btnClose.destroy();
        ToanThanToc.SoloPlay.prototype.btnOffSound.destroy();
        ToanThanToc.SoloPlay.prototype.btnOnSound.destroy();*/
        ToanThanToc.popupShow = false;
        ToanThanToc.SoloPlay.prototype.CreateAminationCountDown();
        ToanThanToc.SoloPlay.prototype.isNameClick=null;

    },

    SetInputFalseUser1:function(value){
        ToanThanToc.SoloPlay.prototype.topOptionT1.inputEnabled = value;
        ToanThanToc.SoloPlay.prototype.topOptionT2.inputEnabled = value;
        ToanThanToc.SoloPlay.prototype.topOptionT3.inputEnabled = value;
    },

    SetInputFalseUser2:function(value){
//        if()
        ToanThanToc.SoloPlay.prototype.topOptionB1.inputEnabled = value;
        ToanThanToc.SoloPlay.prototype.topOptionB2.inputEnabled = value;
        ToanThanToc.SoloPlay.prototype.topOptionB3.inputEnabled = value;
    },

    DeleteSettingSoloPlay:function(){
        var yy = ToanThanToc.SoloPlay.prototype;
        yy.tweenCloseTuyChon=ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.bgPopupSLP).to( { width : 0, height : 0,x:ToanThanToc.game.world.centerX,y:ToanThanToc.game.world.centerY }, 5, Phaser.Easing.Elastic.In, true);
        yy.tweenCloseTuyChon=ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.btnSettingTuyChonSP).to( { width : 0, height : 0,x:ToanThanToc.game.world.centerX,y:ToanThanToc.game.world.centerY }, 5, Phaser.Easing.Elastic.In, true);
        yy.tweenCloseTiepTuc=ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.btnSettingTiepTucSP).to( { width : 0, height : 0,x:ToanThanToc.game.world.centerX,y:ToanThanToc.game.world.centerY }, 5, Phaser.Easing.Elastic.In, true);
        yy.tweenCloseKhoiDong=ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.btnSettingKhoiDongSP).to( { width : 0, height : 0,x:ToanThanToc.game.world.centerX,y:ToanThanToc.game.world.centerY }, 5, Phaser.Easing.Elastic.In, true);
        ToanThanToc.SoloPlay.prototype.tweenCloseSoundSP=ToanThanToc.game.add.tween(ToanThanToc.SoloPlay.prototype.btnSoundSP).to( { width : 0, height : 0,x:ToanThanToc.game.world.centerX,y:ToanThanToc.game.world.centerY }, 5, Phaser.Easing.Elastic.In, true);
    },

    DeleteAnimationAnimal:function(){
        var T2= ToanThanToc.SoloPlay.prototype;
        T2.animalImage1.animations.destroy();
        T2.animalImage1.destroy();
        T2.animalImage2.animations.destroy();
        T2.animalImage2.destroy();
        ToanThanToc.SoloPlay.prototype.topQuestionT.destroy();
        ToanThanToc.SoloPlay.prototype.topQuestionB.destroy();
    },

    DeleteQuestion:function(){
        ToanThanToc.SoloPlay.prototype.topQuestionT.destroy();
        ToanThanToc.SoloPlay.prototype.topQuestionB.destroy();
    },

    DeleteTween:function(){
        ToanThanToc.SoloPlay.prototype.SetInputFalseUser1(true);
        ToanThanToc.SoloPlay.prototype.SetInputFalseUser2(true);
        var ty = ToanThanToc.SoloPlay.prototype;
        if(ty.tweenTQ!=null&&!ty.tweenTQ.isRunning&&ty.tweenBQ!=null&&!ty.tweenBQ.isRunning&&ty.RightBottomTween!=null&&!ty.RightBottomTween.isRunning)
        {
            delete (ty.tweenTQ);
            delete (ty.tweenBQ);
            delete (ty.RightBottomTween);
        }
    }
};
