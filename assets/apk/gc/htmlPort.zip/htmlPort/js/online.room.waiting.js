/* HO SY DAI
 *  daish@nahi.vn
 *  Create: 05/12/2014
 *  Project: Game Center
 *  Detail.js
 * */
"use strict";

ToanThanToc.OnlineRoomWaiting = function (_game) {

};
ToanThanToc.OnlineRoomWaiting.prototype = {

//    xRoom: 90,
//    yRoom: 110,
    arrayButton: [],
    exit: null,
    background: null,
    listPlay: undefined,
    listOnline: undefined,
    titleLabel: null,
    psw: null,
    roomId: '',
    arrayMyView: [],
    countDownImage: null,
    countAnimate: undefined,
    dataWaitingRoom: null,
    backgroundRoomInfo: null,
    bot:null,
    bgnull:null,
    flagplay:null,
    animation:null,
    p: null,
    flagOnClick:1,
    timer:null,
    create: function(){
        var parent = ToanThanToc.OnlineRoomWaiting.prototype;
        parent.background = ToanThanToc.game.add.image(0, 0, 'bg_play');
        parent.background.inputEnabled=true;
        if(this.dataWaitingRoom.status=='LOCKED')
        {
            ToanThanToc.game.stage.destroy();
            ToanThanToc.game.state.start("OnlineUserView");
            ToanThanToc.nameSpace = 'userView';
        }else if(this.dataWaitingRoom != null){
            ToanThanToc.OnlineRoomWaiting.prototype.watchRoom(this.dataWaitingRoom);
        }
    },

    preload: function(){
        if(ToanThanToc.game.cache.checkImageKey('countdown_waiting')){
            return;
        }
        ToanThanToc.game.load.spritesheet('countdown_waiting', 'assets/online/share/countdown_waiting.png', 137, 136);
        ToanThanToc.game.load.spritesheet('numbercountdown','assets/online/number-countdown/number.png',79,92);
        if(ToanThanToc.dataAvatar.length>0)
        {
            for( var i=0;i<ToanThanToc.dataAvatar.length;i++)
            {
                if(ToanThanToc.dataAvatar[i][0]!=""&&ToanThanToc.game.cache.checkImageKey(ToanThanToc.dataAvatar[i][1]) == false)
                {
                    ToanThanToc.game.load.spritesheet(ToanThanToc.dataAvatar[i][1],ToanThanToc.dataAvatar[i][0]);
                }
            }
        }
    },

    watchRoom: function(item){
        /* If it is show the popup */
        if(ToanThanToc.OnlineRoomWaiting.prototype.p == null){
            this.createViewOnlineWaitingRoom(item);
        }
    },
    createViewOnlineWaitingRoom: function(item){

        var that = ToanThanToc.OnlineRoomWaiting.prototype;
        that.roomId = item.id;
        var objectPlayer = {};
        var arrayResult = item.players;
        var arrayTeam = {};
        if (arrayResult != null && arrayResult.length > 0) {
            for (var index = 0; index < arrayResult.length; index++) {
                objectPlayer[arrayResult[index].id] = arrayResult[index];
                var teamIndex = arrayResult[index].team;
                if (arrayTeam[teamIndex] == undefined) {
                    arrayTeam[teamIndex] = [arrayResult[index].id];
                } else {
                    arrayTeam[teamIndex].push(arrayResult[index].id);
                }
            }
        }
        while (Object.keys(arrayTeam).length < item.teamLimit) {
            var key = 1;
            while (arrayTeam[key] != undefined) {
                key++;
            }
            arrayTeam[key] = [];
        }
        for (var index in arrayTeam) {
            while (arrayTeam[index].length < item.memberPerTeam) {
                arrayTeam[index].push(0);
            }
        }

        if (that.listPlay != null)
            that.listPlay.destroyList();
        if (that.listOnline != null)
            that.listOnline.destroyList();

        if (Object.keys(arrayTeam).length > 0 ){
            that.drawTeamList(arrayTeam, item, objectPlayer);
        }
        that.drawOnlineList(item.viewers);

        that.titleLabel = ToanThanToc.game.add.text(80, 850, 'Danh sách đang xem ('
        + item.viewers.length + ')',{font:'bold 32px Segoe UI'});
        var grd = that.titleLabel.context.createLinearGradient(0, 0, 0, that.titleLabel.height);

        //  Add in 2 color stops
        grd.addColorStop(0, '#ffffff');
        grd.addColorStop(1, '#e4f040');

        //  And apply to the Text
        that.titleLabel.fill = grd;
        that.titleLabel.setShadow(0, 3, 'rgba(0,0,0,0.5)', 0);
        that.drawRoomInfo(item);
        that.exit = ToanThanToc.game.add.button(160.5, 1095, 'btn_exit', that.actionOnClickExit, ToanThanToc.game, 1, 0, 0);
        that.exit.events.onInputDown.add(function () {
            shareFunction.actionPlayAudio('touch');
        },this);
    },
    drawTeamList: function(arrayRoom, room, objectPlayers){
        var that = ToanThanToc.OnlineRoomWaiting.prototype;
        var arrayData = {};
        if(Object.keys(arrayRoom).length > 0){
           log(arrayRoom);
            var arrayTemp = 0;
            for(var i in arrayRoom){
                for(var j = 0; j < Object.keys(arrayRoom[i]).length; j++){

                    var idUser = undefined;
                    if(objectPlayers[arrayRoom[i][j]] != undefined){
                        idUser = objectPlayers[arrayRoom[i][j]].id;

                    }
                    arrayTemp = [
                        {
                            xBuffer: 34,
                            yBuffer: 0,
                            name: i,
                            property: { stroke: '#553727', font: "bold 32px Segoe UI", fill: "#ffffff"},
                            anchor: 0,
                            shadow: '0|0|0|0',
                            type: 'image',
                            isShow: 1
                        },
                        {
                            xBuffer: 30,
                            yBuffer: 85,
                            name: 'list_line',
                            property: {},
                            type: 'image',
                            isShow: 1
                        }
                    ];
                    if(arrayRoom[i][j] == 0){
                        arrayTemp.push(
                            {
                                xBuffer: 130,
                                yBuffer: -5,
                                name: 'isnull',
                                property: {},
                                type: 'image',
                                isShow:1
                            },
                            { // button join room.
                                xBuffer: 582,
                                yBuffer: -5,
                                name: 'btn_status',
                                property: {type: 'status', frame: [1, 1, 1], team: i,
                                    roomId: room.id, id: "status_" + i},
                                type: 'button',
                                isShow: 1
                            }
                        );
                    }else{
                        var name=(objectPlayers[arrayRoom[i][j]].fullname).split('@');
                        arrayTemp.push(
                            { // button join room.
                                xBuffer: 582,
                                yBuffer: -5,
                                name: 'btn_status',
                                property: {id: arrayRoom[i][j], roomId: room.id, type: 'status',
                                    frame: (objectPlayers[arrayRoom[i][j]].id == ToanThanToc.myId
                                        ? [3, 3, 3]:[2, 2, 2]), room: i},
                                type: 'button',
                                isShow: 1
                            },
                            {
                                xBuffer: 140,
                                yBuffer: -10,
                                name: objectPlayers[arrayRoom[i][j]]
                                    .avatar_url == '' ? 'avatar_default' : objectPlayers[arrayRoom[i][j]].id,
                                width:80,
                                height:80,
                                property: {},
                                type: 'avatar',
                                isShow: 1
                            },
                            {

                                xBuffer: 330,
                                yBuffer: 35,
                                name: name[0] == '' ? '[Không có tên]' : name[0],
                                property: { stroke: '#553727', font: "bold 32px Segoe UI", fill: "#ffffff"},
                                shadow: '0|0|0|0',
                                anchor: 0.5,
                                type: 'text',
                                isShow: 1
                            },
                            {
                                xBuffer: 460,
                                yBuffer: 35,
                                name: objectPlayers[arrayRoom[i][j]].level,
                                strokeThickness: 5,
                                fontSize: 30,
                                fontWeight: 'bold',
                                anchor: 0.5,
                                shadow: '0|0|0|0',
                                property: {font: "bold 32px Segoe UI", fill: "#fff"},
                                type: 'text',
                                isShow: 1
                            }
                        );
                        if(objectPlayers[arrayRoom[i][j]].id != ToanThanToc.myId) {
                            arrayTemp.push(
                                {
                                    xBuffer: 500,
                                    yBuffer: 13,
                                    name: 'btn_eye',
                                    fontSize: 30,
                                    property: {id: 'eye_' + arrayRoom[i][j],
                                        type: 'eye', frame: [0, 0, 1]},
                                    type: 'button',
                                    isShow: 1
                                }
                            );
                        }
                    }
                    arrayData[Object.keys(arrayData).length] = arrayTemp;
                }
            }
            that.arrayButton = [];
            that.listPlay = new ListScroll(arrayData, 50, 360, 700, 450, 113,
                'waitingRoom', that, that.arrayButton, 'bg_play');
            that.listPlay.makeList();
            that.updateUserView();
        }
    },
    drawOnlineList: function(arrayRoom){

        var that = ToanThanToc.OnlineRoomWaiting.prototype;

        if(arrayRoom != null && arrayRoom.length > 0){
            var text = "";
            var arrayData = {};
            for(var index = 0; index < arrayRoom.length; index ++) {
                text += arrayRoom[index].fullname + ", ";
                if(text.length > 40){
                    var arrayTemp = [
                        {
                            xBuffer: 10,
                            yBuffer: -5,
                            name: text,
                            property: {fill: "#ffffff",font:'bold 30px Segoe UI'},
                            anchor: 0,
                            shadow: '0|0|0|0',
                            type: 'textlist',
                            isShow: 1
                        }
                    ];
                    arrayData[Object.keys(arrayData).length] = arrayTemp;
                    text = "";
                }
            }
            if(text != "") {
                arrayData[Object.keys(arrayData).length] = [
                    {
                        xBuffer: 10,
                        yBuffer: -5,
                        name: text,
                        property: {fill: "#ffffff",font:'bold 30px Segoe UI'},
                        anchor: 0,
                        shadow: '0|0|0|0',
                        type: 'textlist',
                        isShow: 1
                    }
                ];
            }
            that.listOnline = new ListScroll(arrayData, 85, 890, 700, 100,40, 'waitingRoom',
                that, that.arrayButton, 'bg_play');
            that.listOnline.makeList();
            that.updateUserView();
        }
    },
    drawRoomInfo: function(arrayRoom){
        var that = ToanThanToc.OnlineRoomWaiting.prototype;

        if(arrayRoom.free==true)
        {
            log(arrayRoom.free);
            that.backgroundRoomInfo = ToanThanToc.game.add.sprite(90, 65, 'item_room2');
        }
        else {

            that.backgroundRoomInfo = ToanThanToc.game.add.sprite(90, 65, 'item_room1');
        }
            text = ToanThanToc.game.add.text(180, 228, arrayRoom.teamLimit,
                {font: "bold 35px Segoe UI", fill: "#ffffff", align: "left"});
            var addition = ToanThanToc.game.add.sprite(555,230, 'btn_addition');
            addition.frame=(arrayRoom.operator.charAt(0)=='1')?0:1;
            var subtraction = ToanThanToc.game.add.sprite(590,230, 'btn_subtraction');
            subtraction.frame=(arrayRoom.operator.charAt(1)=='1')?0:1;
            var multiplication = ToanThanToc.game.add.sprite(625,230, 'btn_multiplication');
            multiplication.frame=(arrayRoom.operator.charAt(2)=='1')?0:1;
            var division = ToanThanToc.game.add.sprite(520,230, 'btn_division');
            division.frame=(arrayRoom.operator.charAt(3)=='1')?0:1;

        var name = arrayRoom.name;
        if(name.length > 10){
            name = name.substr(0, 7) + '...';
        }
        var name=ToanThanToc.game.add.text(250, 90,name,
            {fill:'#ffffff',font:'bold 35px Segoe UI', align: "center"});
        name.anchor.set(0.5,0);
        //Time

        var text = ToanThanToc.game.add.text(178, 166, arrayRoom.timeLimit + "s",
            {font: "bold 35px Segoe UI", fill: "#ffffff", align: "left"});
        //Star
        text = ToanThanToc.game.add.text(345,  166, arrayRoom.starPerMember.toString(),
            {font: "bold 35px Segoe UI", fill: "#ffffff", align: "left"});
        //Level
        text = ToanThanToc.game.add.text(520, 166,(arrayRoom.mode== 'EASY')?'Khá':(arrayRoom.mode == 'MEDIUM')?'Giỏi':'Xuất sắc',{font: "bold 35px Segoe UI", fill: "#ffffff"});
        //Team

        //Doi khang tu do or not
            text = ToanThanToc.game.add.text(345,  230, arrayRoom.memberPerTeam*arrayRoom.teamLimit,
                {font: "bold 35px Segoe UI", fill: "#ffffff", align: "left"});
    },
    update: function() {
        if(ToanThanToc.OnlineRoomWaiting.prototype.listPlay != null){
            ToanThanToc.OnlineRoomWaiting.prototype.listPlay.update();
        }
        if(ToanThanToc.OnlineRoomWaiting.prototype.listOnline != null){
            ToanThanToc.OnlineRoomWaiting.prototype.listOnline.update();
        }
    },

    /**
     * Action click the button on scroll view.
     * @param e
     */
    onClick: function(e){

        shareFunction.actionPlayAudio('touch');
            if(this.type == 'eye'){
                ToanThanToc.OnlineRoomWaiting.prototype.actionClickEye(this);
            }
            if(this.type == 'status'){
                {
                    if(e.frame!=3) {

                        if (ToanThanToc.OnlineRoomWaiting.prototype.flagOnClick == 1) {
                            ToanThanToc.OnlineRoomWaiting.prototype.actionOnClickStatus(this);
                            ToanThanToc.OnlineRoomWaiting.prototype.flagOnClick = 0;
                            //set delay 4s
                            ToanThanToc.OnlineRoomWaiting.prototype.timer = ToanThanToc.game.time.create(false);
                            ToanThanToc.OnlineRoomWaiting.prototype.timer.loop(4000, ToanThanToc.OnlineRoomWaiting.prototype.fixFlag, ToanThanToc.OnlineRoomWaiting.prototype);
                            ToanThanToc.OnlineRoomWaiting.prototype.timer.start();
                        }
                        else if (ToanThanToc.OnlineRoomWaiting.prototype.flagOnClick == 0) {
                            log('không spam nha...');
                        }
                    }else
                    {
                        ToanThanToc.OnlineRoomWaiting.prototype.actionOnClickStatus(this);
//                    ToanThanToc.OnlineRoomWaiting.prototype.flagOnClick = 1;
                    }
                }
        }
    },
    fixFlag:function(){
        ToanThanToc.OnlineRoomWaiting.prototype.flagOnClick=1;
        ToanThanToc.OnlineRoomWaiting.prototype.timer.stop();
        log(ToanThanToc.OnlineRoomWaiting.prototype.flagOnClick);
    },
    actionClickEye: function(e){
        var parent = ToanThanToc.OnlineRoomWaiting.prototype;
        var a_id = e.id.split('_');
        var id = a_id[1];
        if(a_id[0] == 'eye') {
            if (parent.arrayMyView.indexOf(id) == -1) {
                parent.arrayMyView.push(id);
            } else {
                parent.arrayMyView.splice(parent.arrayMyView.indexOf(id), 1);
            }
            parent.updateUserView();
        }
    },
    actionOnClickStatus: function(e){
        var parent = ToanThanToc.OnlineRoomWaiting.prototype;
        if(ToanThanToc.data != null){
            parent.psw = ToanThanToc.data.password;
        }

        if(parseInt(e.frame[0]) == 1){
            Socket.execute(function(socketJoin){
                socketJoin.post(domainAPI + urlJoinRoom, {token: xAuthToken, roomid: e.roomId,
                    password: parent.psw, team: e.team}, function(data){
                    if(data.stateCode == 200) {
//                    ToanThanToc.nameSpace = 'detailRoom';
                    }else{
                        log('error join room data '+data.result+' status code'+data.stateCode);
                    }
                });
            });
        }else if(parseInt(e.frame[0]) == 3){
            Socket.execute(function(socketJoin){
                socketJoin.post(domainAPI + urlUnJoinRoom, {token: xAuthToken, roomid: e.roomId,
                    password: parent.psw}, function(data){
                    if(data.stateCode == 200) {
//                    ToanThanToc.nameSpace = 'detailRoom';
                    }else{
                        log('error UnJoin room data '+data.result+' status code' +data.stateCode);
                    }
                });
            });
        }


    },
    actionOnClickExit: function() {
        ToanThanToc.OnlineRoomWaiting.prototype.p = new Popup(ToanThanToc.OnlineRoomWaiting.prototype.clickExitPopup);
        ToanThanToc.OnlineRoomWaiting.prototype.p.setMain(ToanThanToc.game,'Exit','','popup','popupCancel',[{x:-273,y:7}],'popupOK',[{x:46,y:7}]);
        ToanThanToc.OnlineRoomWaiting.prototype.p.setText([{x:0,y:-70}],['Bạn có chắc chắn muốn rời phòng?'],[{fill:'#ffffff',font:'29px Segoe UI',align:'center'}]);
        ToanThanToc.OnlineRoomWaiting.prototype.p.setEvent(ToanThanToc.OnlineRoomWaiting.prototype.actionExit);
        ToanThanToc.OnlineRoomWaiting.prototype.p.createPopup(350,350);
//        ToanThanToc.OnlineRoomWaiting.prototype.p.openWindow();
    },

    clickExitPopup: function(){
        console.log('destroy popup');
        ToanThanToc.OnlineRoomWaiting.prototype.p = null;
    },

    actionExit: function(){
        var that = ToanThanToc.OnlineRoomWaiting.prototype;
        Socket.execute(function(socketRoomExit){
            socketRoomExit.post(domainAPI + urlLeaveRoom, {token: xAuthToken, roomid: ToanThanToc.data.id}, function(data){
                if(data.stateCode == 200) {
                    if(data.result == true) {
                        that.background.destroy();
                        that.exit.kill();
                        if(that.listOnline){
                            that.listOnline.destroyList();
                        }
                        if(that.listPlay){
                            that.listPlay.destroyList();
                        }
                        if(that.titleLabel){
                            that.titleLabel.destroy();
                        }
                    }else{
                        console.log('Exit not allow: ' + JSON.stringify(data));
                    }
                }else{
                    console.log('Click Exit Error: ' + JSON.stringify(data));
                }

                /* -----------control temporary------------ */

                /* destroy popup. */
                ToanThanToc.OnlineRoomWaiting.prototype.p = null;
                /* Call back choose room. */
                ToanThanToc.game.stage.destroy();
                ToanThanToc.nameSpace = 'chooseRoom';
                ToanThanToc.game.state.start("OnlineRoomChoose");

            });
        });
    },
    updateUserView: function(){
        var parent = ToanThanToc.OnlineRoomWaiting.prototype;
        if(parent.arrayButton != undefined || Object.keys(parent.arrayButton).length > 0) {
            for (var index in parent.arrayButton) {
                var a_id = index.split('|');
                a_id = a_id[1];
                a_id = a_id.split('_');
                var id = a_id[1];
                if (a_id[0] == 'eye') {
                    if(parent.arrayMyView != null){
                        if (parent.arrayMyView.indexOf(id) != -1) {
                            parent.arrayButton[index].setFrames(1, 1, 0);
                        } else {
                            parent.arrayButton[index].setFrames(0, 0, 1);

                        }
                    }
                }
            }
        }
    },


    createNumberCountDown: function(item)
    {
        if(item==true)
        {
            this.flagplay=1;
        }else{
            this.flagplay=0;
        }
        this.bgnull = ToanThanToc.game.add.sprite(0,0,'bgcountdown');
        this.bgnull .width=800;
        this.bgnull .height=1230;
        this.bgnull .inputEnabled=true;
        this.bot = ToanThanToc.game.add.sprite(340,550,'numbercountdown');
        this.bot.scale.setTo(2,2);
        this.animation = this.bot.animations.add('walk');

        this.animation.onComplete.add(this.animationStop,ToanThanToc.game);

        this.animation.play(1,false);

    },
    animationStop:function(){
        ToanThanToc.game.stage.destroy();
        if(ToanThanToc.OnlineRoomWaiting.prototype.flagplay==1)
        {
            ToanThanToc.game.state.start("OnlinePlayingRoom");
            ToanThanToc.nameSpace = 'roomPlaying';
        }else if(ToanThanToc.OnlineRoomWaiting.prototype.flagplay==0)
        {
            ToanThanToc.game.state.start("OnlineUserView");
            ToanThanToc.nameSpace = 'userView';
        }else{
            log('ko lay duoc loai phong');
        }
    },
    destroy: function(){

        ToanThanToc.OnlineRoomWaiting.prototype.backgroundRoomInfo.destroy();
        ToanThanToc.OnlineRoomWaiting.prototype.arrayButton = null;
        ToanThanToc.OnlineRoomWaiting.prototype.exit.destroy();
        ToanThanToc.OnlineRoomWaiting.prototype.background.destroy();
        ToanThanToc.OnlineRoomWaiting.prototype.listPlay.destroyList();
        ToanThanToc.OnlineRoomWaiting.prototype.listOnline.destroyList();
        ToanThanToc.OnlineRoomWaiting.prototype.titleLabel.destroy();
        ToanThanToc.OnlineRoomWaiting.prototype.psw = null;
        ToanThanToc.OnlineRoomWaiting.prototype.roomId = '';
        //ToanThanToc.OnlineRoomWaiting.prototype.arrayMyView = null;
        ToanThanToc.OnlineRoomWaiting.prototype.p = null;
    }


};

