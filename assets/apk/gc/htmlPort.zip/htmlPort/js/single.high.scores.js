/**
 * Created by thanhpt From NAHI on 1/29/2015.
 * @Author: tpt2213
 */

"use strict";
ToanThanToc.HighScoresSingle = function (game) {
};

ToanThanToc.HighScoresSingle.prototype = {
    arrayButtonHighScoreSG:{},
    listHighScoreSG: undefined,
    bt_action:null,
    btnMenuSoloBackTT:null,
    preload: function () {
        ToanThanToc.popupShow=0;
        ToanThanToc.HighScoresSingle.prototype.isNameClick=null;
        ToanThanToc.MenuSingle.prototype.isNameClick=null;
        if( ToanThanToc.game.cache.checkImageKey('bghighScoresSG')&&
            ToanThanToc.game.cache.checkImageKey('btnChallengeSG')&&
            ToanThanToc.game.cache.checkImageKey('btnConfirmSG')&&
            ToanThanToc.game.cache.checkImageKey('exitHighScoreSG')&&

            ToanThanToc.game.cache.checkImageKey('highScoreEasySG')&&
            ToanThanToc.game.cache.checkImageKey('highScoreHardSG')&&
            ToanThanToc.game.cache.checkImageKey('highScoreMediumSG')
            ) return false;
        log('-------------------Preload high.scores.single-------------------------');
        this.load.spritesheet('bghighScoresSG', 'assets/single/background/bg-high-scores.png', 799,1231);
        this.load.spritesheet('btnChallengeSG', 'assets/single/high-score/btn-challenge.png', 361,120);
        this.load.spritesheet('btnConfirmSG', 'assets/single/high-score/btn-confirm.png', 479,98);
        this.load.spritesheet('exitHighScoreSG', 'assets/single/high-score/exit.png', 67,71);

        this.load.spritesheet('highScoreEasySG', 'assets/single/high-score/highscore-easy.png', 604,270);
        this.load.spritesheet('highScoreHardSG', 'assets/single/high-score/highscore-hard.png', 604,270);
        this.load.spritesheet('highScoreMediumSG', 'assets/single/high-score/highscore-medium.png', 604,270);
        this.load.spritesheet('mathsSG', 'assets/single/high-score/maths.png', 140,39);

        this.load.spritesheet('popupDelHScore', 'assets/single/popup/popup-cancle-score.png', 548,343);
        this.load.spritesheet('btnOkPPC', 'assets/single/create-challenge/popup/btn-ok.png', 137,74);
        this.load.spritesheet('btnDeletePPC', 'assets/single/create-challenge/popup/btn-delete.png', 110,74);
    },

    create: function () {
        /*
         btn_addition
         btn_subtraction
         btn_multiplication
         btn_division*/
        var that = ToanThanToc.HighScoresSingle.prototype;
        that.bg_action = ToanThanToc.game.add.sprite(0, 0, 'bghighScoresSG');
        that.CreateListHighScores();
        that.bt_action = ToanThanToc.game.add.button(
                ToanThanToc.game.world.centerX-479/2, 1060, 'btnConfirmSG',this.ActionClickHighScores,ToanThanToc.game,0,0,1);
        that.btnMenuSoloBackTT = ToanThanToc.game.add.button(17,17,'btnBackTT',this.ActionClickHighScores,ToanThanToc.game,0,0,1);
        that.isNameClick=null;
    },

    update:function(){

        if(ToanThanToc.HighScoresSingle.prototype.listHighScoreSG != undefined && ToanThanToc.nameSpace =='HighScoresSingle'){
            ToanThanToc.HighScoresSingle.prototype.listHighScoreSG.update();
        }
    },

    render: function () {
        /*ToanThanToc.game.debug.text("Time until event: " + ToanThanToc.game.time.events.duration, 32, 32);*/
        /*render() ;*/
    },

    CreatePopupDelHighScore:function(){
        var ttt = ToanThanToc.HighScoresSingle.prototype;
        ToanThanToc.Menu.prototype.BacgroundForPopup();
        ttt.bgPPConfirm =  ToanThanToc.game.add.sprite(0,0, 'bgPopupOk');
        ttt.bgPPConfirm.inputEnabled=true;
        ttt.bgPPConfirm.events.onInputDown.add(ttt.ClickOutDelHighScore);

        ttt.bgPPxacnhanDHSC=ToanThanToc.game.add.sprite(ToanThanToc.game.world.centerX-548/2,ToanThanToc.game.world.centerY-343/2,'popupDelHScore');
        ttt.btnConfirmDHSC=ToanThanToc.game.add.button(290,200,'btnOkPPC',this.ActionClickHighScores,ToanThanToc.game,0,0,1);
        ttt.btnDeleteDHSC=ToanThanToc.game.add.button(120,200,'btnDeletePPC',this.ActionClickHighScores,ToanThanToc.game,0,0,1);

        ttt.bgPPxacnhanDHSC.addChild( ttt.btnConfirmDHSC);
        ttt.bgPPxacnhanDHSC.addChild( ttt.btnDeleteDHSC);
        ttt.isNameClick = null;
    },

    CreateListHighScores:function(){
        var that = ToanThanToc.HighScoresSingle.prototype;
        if( that.listHighScoreSG != null){
            that.listHighScoreSG.destroyList();
        }
        var array_result = ToanThanToc.MyScores;
        var arrayHighScoreSG = {};
        if(array_result.length > 0){
            var arrayTemp = [];
            for (var index = 0; index < array_result.length; index++) {
               /* create array high scrore */
                arrayTemp = [
                    {  /*background.*/
                        xBuffer: 0,
                        yBuffer: 0,
                        name: (array_result[index].mode == 'EASY' ? 'highScoreEasySG' :(
                               array_result[index].mode == 'MEDIUM' ? 'highScoreMediumSG' :'highScoreHardSG')
                        ),
                        property: {},
                        type: 'image',
                        isShow: 1
                    },
                    {  /*text Time  Play*/
                        xBuffer: 320,
                        yBuffer: 70,
                        name: ToanThanToc.SoloPlay.prototype.ShowTimeTo(array_result[index].time/1000),
                        strokeThickness: 5,
                        anchor: 0,
                        shadow: '0|0|0|0',
                        property: {font: "bold 50px Segoe UI", fill: "#fff", align: "center"},
                        type: 'text',
                        isShow: 1
                    },
                    {    /*button del high score*/
                        xBuffer: 10,
                        yBuffer: 15,
                        name: 'exitHighScoreSG',
                        property: {type: 'delHighScoresSG', id: "highSG_" + array_result[index].id, frame: [0, 0, 1]},
                        type: 'button',
                        isShow: 1
                    },
                    {    /*button chalenge*/
                        xBuffer: 220,
                        yBuffer: 130,
                        name: 'btnChallengeSG',
                        property: {type: 'ChallengehighScoresSG', id: "highSG_" + array_result[index].id, frame: [0, 0, 1]},
                        type: 'button',
                        isShow: 1
                    }
                ];
                arrayTemp.push(
                    { // operation +
                        xBuffer: 40,
                        yBuffer: 210,
                        property: {},
                        name: 'btn_division',
                        frame:(array_result[index].operator.charAt(3) == '1') ?
                            '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                        type: 'image',
                        isShow: 1
                    },
                    { // operation -
                        xBuffer: 80,
                        yBuffer: 210,
                        property: {},
                        name: 'btn_addition',
                        frame:(array_result[index].operator.charAt(0) == '1') ?
                            '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                        type: 'image',
                        isShow: 1
                    },
                    { // operation *
                        xBuffer: 120,
                        yBuffer: 210,
                        property: {},
                        name: 'btn_subtraction',
                        frame:(array_result[index].operator.charAt(1) == '1') ?
                            '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                        type: 'image',
                        isShow: 1
                    },
                    { // operation /
                        xBuffer: 160,
                        yBuffer: 210,
                        property: {},
                        name: 'btn_multiplication',
                        frame:(array_result[index].operator.charAt(2) == '1') ?
                            '0,0,0,34,35' : '1,34,0,33,35',//index,x,y,w,h
                        type: 'image',
                        isShow: 1
                    }

                );
                arrayHighScoreSG[Object.keys(arrayHighScoreSG).length] = arrayTemp;
            }
        }
        that.listHighScoreSG =
            new ListScroll(arrayHighScoreSG, 88.5, 310, 610, 700, 265, 'HighScoresSingle',
                that, that.arrayButtonHighScoreSG, 'bghighScoresSG');
        that.listHighScoreSG.makeList();

        if(that.bt_action!=null) that.bt_action.bringToTop();
        if(that.btnMenuSoloBackTT!=null) that.btnMenuSoloBackTT.bringToTop();
        that.isNameClick=null;
    },
    idScore:null,
    onClick: function(){
        shareFunction.actionPlayAudio('touch');
        var self = ToanThanToc.HighScoresSingle.prototype;
        if(ToanThanToc.HighScoresSingle.prototype.isNameClick==null){
            if(this.type == 'delHighScoresSG'){
                ToanThanToc.HighScoresSingle.prototype.isNameClick='delHighScoresSG';
                for(var i = 0; i < Object.keys(self.arrayButtonHighScoreSG).length; i++) {
                    var key = i + '|' + this.id;
                    var id = this.id.split('_');
                    id = id[1]; log('--------------------id---------------'+id);
                    if (self.arrayButtonHighScoreSG[key] != undefined) {
                        /* Xoa diem cao */
                        self.idScore=id;
                        self.isNameClick='delHighScoresSG';
                        self.CreatePopupDelHighScore();
                        return false;
                    }
                }
            }
            else
            {/*ChallengehighScoresSG*/
                ToanThanToc.HighScoresSingle.prototype.isNameClick='ChallengehighScoresSG';
                for(var i = 0; i < Object.keys(self.arrayButtonHighScoreSG).length; i++) {
                    var key = i + '|' + this.id;
                    var id = this.id.split('_');
                    id = id[1];
                    if (self.arrayButtonHighScoreSG[key] != undefined) {
                        self.isNameClick='ChallengehighScoresSG';
                        SetCssBody('url(assets/single/background/bg.png) no-repeat center center fixed');
                        self.Myid=id;
                        self.Myindex=i;
                        self.DeletePageHighScores();
                        ToanThanToc.game.stage.destroy();
                        ToanThanToc.game.state.start('SingleCreateChallenges');
                        self.isNameClick=null;
                        return false;
                    }
                }
            }
        }

    },

    ActionClickHighScores:function(item){
        var ttt = ToanThanToc.HighScoresSingle.prototype;
        shareFunction.actionPlayAudio('touch');
        if(ttt.isNameClick==null)
        {
            log(item.key);
            if(item.key=='btnConfirmSG'){
                ttt.isNameClick='btnConfirmSG';
                GetListMyChall(function(data){
                    if(data=='erro') return false;
                    GetListYourChall(function(data){
                        if(data=='erro') {ttt.isNameClick=null; return false;}
                        else
                        {
                            ttt.DeletePageHighScores();
                            SetCssBody('url(assets/single/background/bgok.png) no-repeat center center fixed');
                            ToanThanToc.game.stage.destroy();
                            ToanThanToc.game.state.start('SingleListChallenges');
                            ttt.isNameClick=null;
                        }
                    });
                });
            }
            else if(item.key=='btnBackTT'){
                ttt.isNameClick='btnBackTT';
                ttt.DeletePageHighScores();
                SetCssBody('url(assets/solo/background/background-solo.png) no-repeat center center fixed');
                ToanThanToc.game.stage.destroy();
                ToanThanToc.game.state.start('MenuSingle');
                ttt.isNameClick=null;
            }
            else if(item.key=='btnDeletePPC'){
                ttt.isNameClick='btnDeletePPC';
                ttt.ClickOutDelHighScore();
            }
            else if(item.key=='btnOkPPC'){
                ttt.isNameClick='btnOkPPC';
                DelMyScores(function(data){
                 if(data=='erro') return false;
                     GetMyHighScoresSG(function(data){
                         if(data=='erro')  return false;
                             ttt.listHighScoreSG.destroyList();
                             ttt.CreateListHighScores();
                     });
                 },ttt.idScore);
                ttt.ClickOutDelHighScore();
            }
        }
    },

    ClickOutDelHighScore:function(){
        ToanThanToc.Menu.prototype.HideBgPopupBottom();
        ToanThanToc.Menu.prototype.HideBgPopupTop();
        var ttt =ToanThanToc.HighScoresSingle.prototype;
        ttt.bgPPConfirm.destroy();
        setTimeout(function(){
            ttt.bgPPxacnhanDHSC.destroy();
            ttt.isNameClick =null;
        },50);
    },
    DeletePageHighScores:function(){
        var ttt = ToanThanToc.HighScoresSingle.prototype;
        setTimeout(function(){
            ttt.bg_action.destroy();
            ttt.bt_action.destroy();
            ttt.btnMenuSoloBackTT.destroy();
            ttt.listHighScoreSG.destroyList();
        },80);
    }
};

function DelMyScores(callback,id) {
    ToanThanToc.db.setAtuthToken(ToanThanToc.MyToken);
    var  postDelMyScores = ToanThanToc.db.query({api: '/math/removescore/', data:{scoreid:id},
            headers : {'x-auth-token': ToanThanToc.MyToken}}
    );
    postDelMyScores.success(function(data){
        callback(data);
    });
    postDelMyScores.error(function(data){
        callback('erro');
    });
}

function GetMyHighScoresSG(callback){
    var postMyScores = ToanThanToc.db.query({api: '/math/myscore/', data:{},
            headers : {'x-auth-token': ToanThanToc.MyToken}}
    );
    postMyScores.success(function(data){
        ToanThanToc.MyScores=data;
        callback(ToanThanToc.MyScores);
    });
    postMyScores.error(function(data){
        /*popup internet co van de */
        callback('erro');
        //ToanThanToc.SinglePlay.prototype.CreatePopupEndGame();
    });
}

function GetListMyChall(callback){
    var postMyScores = ToanThanToc.db.query({api: '/math/mychallenges/', data:{},
            headers : {'x-auth-token': ToanThanToc.MyToken}}
    );
    postMyScores.success(function(data){
        ToanThanToc.YourChall=data;
        callback(ToanThanToc.YourChall);
    });
    postMyScores.error(function(data){
        /*popup internet co van de */
        callback('erro');
    });
}

function GetListYourChall(callback)
{
    var postMyScores = ToanThanToc.db.query({api: '/math/suggestchallenges/', data:{},
            headers : {'x-auth-token': ToanThanToc.MyToken}}
    );
    postMyScores.success(function(data){
        ToanThanToc.PlayerChall=data;
        callback(ToanThanToc.PlayerChall);
    });
    postMyScores.error(function(data){
        callback('erro');
    });
}