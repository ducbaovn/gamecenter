/**
 * @Created by thanhpt from Nahi on 20/12/2014
 * @author tpt2213
 */

//-------------------------------------
"use strict";
//-------------------------------------
var arrAllObjectLoading = {};
//var url_avatar = 'assets/plays/';
/* -------------------------------- URL PATH DEFAULT -------------------------------- */

/** Domain service */
var domainAPI = 'http://103.19.220.139'; // NAHI service
//var domainAPI = 'http://172.30.0.202:1337'; // Mr.Tin service
/** Default url */
var urlDefault = '/math/room/';
var urlCreateRoom = urlDefault+'create'; // Create room.
var urlJoinRoom = urlDefault+'join'; // Join room.
var urlUnJoinRoom = urlDefault+'unjoin'; // Un join room.
var urlAutoJoinRoom = urlDefault+'autojoin'; // Auto join room.
var urlWatchRoom = urlDefault+'watch'; // Watch room.
var urlLeaveRoom = urlDefault+'leave'; // Leave room.
var urlNewScore = urlDefault+'score'; // Get new score.
var urlMissScore = urlDefault+'misscore'; // Get new score.
var urlFreeRoom = urlDefault+'list'; // List free room.
var urlNahiRoom = urlDefault+'nahi'; // List NAHI room.


var PERCENTSTART = 10; // 10% star


//var socket;
var xAuthToken = null; // nahi2@nahi.vn pass:123456789

var timePlay = 30;

/* Variable for room waiting. */
var idRoom = '',
    passRoom = '';
//    urlRedirectRoom = '';




/* -------------------------------- URL PATH DEFAULT END -------------------------------- */
var namespace;
//var arrAllObjectLoading = {};

var ToanThanToc;

if(!ToanThanToc) ToanThanToc = {};

if(!ToanThanToc.BASE_PATH)
{
    var base_path = location.href.substr(0, location.href.lastIndexOf("/") + 1);
    ToanThanToc.BASE_PATH   = base_path;
}

ToanThanToc.myId = '';
ToanThanToc.db = null;
ToanThanToc.device = null;

ToanThanToc.isLoadAvatar = false;
ToanThanToc.id = null;
ToanThanToc.socket = null;
//-------------------------------------


ToanThanToc.dataAvatar=[];

ToanThanToc.PixelsPerSecond = 40;
ToanThanToc.Error = {};
ToanThanToc.domainAPI = "http://103.19.220.139";
ToanThanToc.db = null;
ToanThanToc.develop = true;

ToanThanToc.SCREEN_WIDTH  =  800;
ToanThanToc.SCREEN_HEIGHT = 1230;

ToanThanToc.MIN_WIDTH = 400;
ToanThanToc.MIN_HEIGHT = 616;
ToanThanToc.PANEL_HEIGHT  = ToanThanToc.PANEL_ROWS    * ToanThanToc.TILE_SIZE;
ToanThanToc.FULL_HEIGHT   = 1232;

ToanThanToc.STATES = {};

ToanThanToc.heighPerFect = 0;
ToanThanToc.widthPerFect = 0;

/* Set  music*/
ToanThanToc.music_lose='lose';
ToanThanToc.music_music='music';
ToanThanToc.music_popupMainAction='popup-main-action';
ToanThanToc.music_popupQuit='popup-quit';
ToanThanToc.music_touch='touch';
ToanThanToc.music_win='win';
ToanThanToc.music_wrong='wrong';

/* video intro */
ToanThanToc.video = null;

/* hieu ung chung */
ToanThanToc.vantoc_Quadratic=800;
ToanThanToc.vantoc_Linear=300;
ToanThanToc.cuongDoAmThanh=100;

/*  timer video intro */
ToanThanToc.timer_Background=null;

/* popup menu */
ToanThanToc.popupShow = false;
ToanThanToc.menu_bgPopup=null;
ToanThanToc.menu_btnClose=null;
ToanThanToc.menu_btnXacNhan=null;
ToanThanToc.menu_chkNhacNen=null;
ToanThanToc.menu_chkNhacHieuUng=null;

/*  menu option Solo */
ToanThanToc.isLevelSolo=null;
ToanThanToc.plusSolo=false;
ToanThanToc.minusSolo=false;
ToanThanToc.multiSolo=false;
ToanThanToc.divisionSolo=false;

/* play solo */
ToanThanToc.numQuestion=11;

ToanThanToc.answer = null;
ToanThanToc.scoreT = 0;
ToanThanToc.scoreB = 0;
ToanThanToc.scoreTam1 = -1;
ToanThanToc.scoreTam2 = -1;
ToanThanToc.countNumQuestion=0;
ToanThanToc.timeDelay=1100;
ToanThanToc.timePlayDelay=150;
ToanThanToc.timeMoneyEinStein=60;//-160

ToanThanToc.isEndSolo=false;
ToanThanToc.soloPlayTime=20;
ToanThanToc.soloPlayScore=0;

ToanThanToc.timePlaySingle=0;
/* waitting */
ToanThanToc.waiting = null;
ToanThanToc.bgwaiting = null;
ToanThanToc.game       = null;

/*  variable for API  */
ToanThanToc.configMath='';
ToanThanToc.infoUserMath='';
ToanThanToc.MyScores='';
ToanThanToc.PlayerChall='';
ToanThanToc.YourChall='';
ToanThanToc.challengeid='';
ToanThanToc.moneyStarPerOne=0;
ToanThanToc.MyToken=null;
ToanThanToc.isOnlineOK=null;
ToanThanToc.energyConf=10;
/* Data create room. */
/// popup
ToanThanToc.popupC = null;
ToanThanToc.dataCreateRoom = null;
ToanThanToc.dataAutoJoin = null;
ToanThanToc.dataWatchRoom = null;


ToanThanToc.dataQuestionTemp =
{
    "owner":"54a1353cbe716a8f058350aa","mathroom":"54afac050cfff4277235a19d",
    "startTime":"2015-01-09T10:24:04.053Z","endTime":"2015-01-09T10:24:04.053Z","status":"PLAYING",
    "name":"test9","mode":"EASY","minLevel":1,"timeLimit":30,"teamLimit":2,"memberPerTeam":1,"starPerMember":1,"playboards":[{"name":"1","scoreUpdatedAt":"2015-01-09T10:23:14.054Z",
        "score":0,"players":[{"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn","nickname":"nahi1@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z",
            "level":1,"team":1,"score":2},{"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn","nickname":"nahi1@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z",
            "level":1,"team":2,"score":15},{"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn","nickname":"nahi1@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z",
            "level":1,"team":3,"score":0}]},{"name":"2","scoreUpdatedAt":"2015-01-09T10:23:14.054Z","score":2,"players":[{"id":"54a39ea647004cbb54f3c746","fullname":"nahi2@nahi.vn",
        "nickname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":2,"score":3},{"id":"54a39ea647004cbb54f3c746","fullname":"nahi2@nahi.vn",
        "nickname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":1,"score":6},{"id":"54a39ea647004cbb54f3c746","fullname":"nahi2@nahi.vn",
        "nickname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":3,"score":10}]}],"createdAt":"2015-01-09T10:23:14.056Z",
    "updatedAt":"2015-01-09T10:23:14.056Z","id":"54afac120cfff4277235a19f","terms":[{"operator":"/","aValue":9,"bValue":1,"result":9,"result_1":6,"result_2":4},{"operator":"+",
        "aValue":5,"bValue":8,"result":13,"result_1":18,"result_2":15},{"operator":"-","aValue":8,"bValue":2,"result":6,"result_1":4,"result_2":3},{"operator":"+","aValue":3,
        "bValue":1,"result":4,"result_1":3,"result_2":8},{"operator":"+","aValue":6,"bValue":0,"result":6,"result_1":7,"result_2":2},{"operator":"*","aValue":0,"bValue":5,"result":0,
        "result_1":2,"result_2":-3},{"operator":"*","aValue":4,"bValue":6,"result":24,"result_1":19,"result_2":23},{"operator":"-","aValue":2,"bValue":0,"result":2,"result_1":0,"result_2":7},
        {"operator":"+","aValue":1,"bValue":8,"result":9,"result_1":11,"result_2":13},{"operator":"*","aValue":6,"bValue":9,"result":54,"result_1":52,"result_2":56},{"operator":"+","aValue":6,
            "bValue":5,"result":11,"result_1":14,"result_2":15},{"operator":"-","aValue":7,"bValue":8,"result":-1,"result_1":-6,"result_2":-5},{"operator":"+","aValue":7,"bValue":8,"result":15,
            "result_1":14,"result_2":16},{"operator":"*","aValue":5,"bValue":4,"result":20,"result_1":23,"result_2":18},{"operator":"-","aValue":6,"bValue":6,"result":0,"result_1":1,"result_2":-3},
        {"operator":"-","aValue":7,"bValue":1,"result":6,"result_1":7,"result_2":10},{"operator":"+","aValue":5,"bValue":6,"result":11,"result_1":7,"result_2":15},{"operator":"*","aValue":5,"bValue":7,
            "result":35,"result_1":32,"result_2":30},{"operator":"+","aValue":0,"bValue":3,"result":3,"result_1":4,"result_2":2},{"operator":"-","aValue":0,"bValue":4,"result":-4,"result_1":-5,"result_2":-7},
        {"operator":"/","aValue":3,"bValue":3,"result":1,"result_1":0,"result_2":4},{"operator":"*","aValue":6,"bValue":6,"result":36,"result_1":33,"result_2":37},{"operator":":","aValue":5,"bValue":1,"result":5,
            "result_1":0,"result_2":8},{"operator":"/","aValue":4,"bValue":2,"result":2,"result_1":0,"result_2":-3},{"operator":"-","aValue":1,"bValue":0,"result":1,"result_1":4,"result_2":-3},{"operator":"/",
            "aValue":8,"bValue":4,"result":2,"result_1":3,"result_2":7},{"operator":"*","aValue":5,"bValue":9,"result":45,"result_1":46,"result_2":47},{"operator":"-","aValue":0,"bValue":2,"result":-2,"result_1":-5,
            "result_2":-6},{"operator":"-","aValue":9,"bValue":7,"result":2,"result_1":-2,"result_2":7},{"operator":"-","aValue":0,"bValue":4,"result":-4,"result_1":-5,"result_2":-2},{"operator":"+","aValue":6,"bValue":7,
            "result":13,"result_1":15,"result_2":18},{"operator":"/","aValue":2,"bValue":1,"result":2,"result_1":-2,"result_2":6},{"operator":"-","aValue":8,"bValue":2,"result":6,"result_1":8,"result_2":2},{"operator":"+",
            "aValue":6,"bValue":3,"result":9,"result_1":13,"result_2":12},{"operator":"/","aValue":7,"bValue":1,"result":7,"result_1":5,"result_2":2},{"operator":"*","aValue":3,"bValue":3,"result":9,"result_1":5,"result_2":6},
        {"operator":"*","aValue":1,"bValue":8,"result":8,"result_1":10,"result_2":3},{"operator":"*","aValue":0,"bValue":3,"result":0,"result_1":-3,"result_2":1},{"operator":"+","aValue":1,"bValue":9,"result":10,"result_1":7,
            "result_2":15},{"operator":"*","aValue":4,"bValue":1,"result":4,"result_1":0,"result_2":3},{"operator":"/","aValue":7,"bValue":1,"result":7,"result_1":10,"result_2":8},{"operator":"+","aValue":5,"bValue":6,
            "result":11,"result_1":16,"result_2":15},{"operator":"*","aValue":7,"bValue":0,"result":0,"result_1":1,"result_2":-2},{"operator":"/","aValue":1,"bValue":1,"result":1,"result_1":2,"result_2":-1},{"operator":"+",
            "aValue":8,"bValue":7,"result":15,"result_1":16,"result_2":18}]
};

ToanThanToc.dataWatchRoom =
{"owner":"54a1353cbe716a8f058350aa","status":"OPENED","name":"test4","mode":"MEDIUM","operator":"1100",
    "minLevel":1,"timeLimit":30,"teamLimit":2,"memberPerTeam":1,"starPerMember":1,"free":false,
    "hasPassword":true,"players":[],"viewers":[{"id":"54a39ea647004cbb54f3c746","nickname":"nahi2@nahi.vn",
    "fullname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","onlineStatus":"OFFLINE"},
    {"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn","nickname":"nahi1@nahi.vn","avatar_url":"",
        "gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":1},
    {"id":"54a39ea647004cbb54f3c746","fullname":"nahi2@nahi.vn","nickname":"nahi2@nahi.vn","avatar_url":"",
        "gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z","level":1,"team":2},{"id":"54a39ea647004cbb54f3c746","nickname":"nahi2@nahi.vn",
        "fullname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","onlineStatus":"OFFLINE"},{"id":"54a39ea647004cbb54f3c746","nickname":"nahi2@nahi.vn",
        "fullname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","onlineStatus":"OFFLINE"},{"id":"54a39ea647004cbb54f3c746","nickname":"nahi2@nahi.vn",
        "fullname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","onlineStatus":"OFFLINE"}],"nahiRoom":false,
    "id":"54af57a1802b0044662bbcfd"};

var dataNewScoreTemp =
{"owner":"54a1353cbe716a8f058350aa","mathroom":"54af86a6ea7def3269c93e51",
    "startTime":"2015-01-09T07:44:45.282Z","endTime":"2015-01-09T07:44:45.282Z",
    "status":"PLAYING","name":"test8","playboards":[{"name":"1","scoreUpdatedAt":"2015-01-09T07:43:55.283Z",
    "score":0,"players":[{"id":"54a1353cbe716a8f058350aa","fullname":"nahi1@nahi.vn",
        "nickname":"nahi1@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z",
        "level":1,"team":1,"score":0}]},{"name":"2","scoreUpdatedAt":"2015-01-09T07:44:40.913Z",
    "score":4,"players":[{"id":"54a39ea647004cbb54f3c746","fullname":"nahi2@nahi.vn",
        "nickname":"nahi2@nahi.vn","avatar_url":"","gender":"FEMALE","dob":"2013-12-02T17:00:00.000Z",
        "level":1,"team":2,"score":4}]}],"id":"54af86bbea7def3269c93e53"};

