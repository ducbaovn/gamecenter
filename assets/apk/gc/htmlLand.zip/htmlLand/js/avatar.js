jQuery(document).ready(function ($) {
    $(".view0").show();

    //load data
    var myGem = $.cookie("myGem");
    var myStar = $.cookie("myStar");

    if(myGem && myGem.length > 0){
        $(".gem").text(myGem);
    } else {
        $(".gem").text("9999");
    }
    if(myStar && myStar.length > 0){
        $(".sao").text(myStar);
    } else {
        $(".sao").text("900000");
    }

    var Avatar = {
        listAvatar: function(store){
            var searchList = (store == "my")? Avatar.myAvatars() : Avatar.storeAvatars();

            var htmlRow = "";
            var html = '<div class="avatar-area">';
            var col = 0;
            for(var i = 0; i< searchList.length; i++){
                htmlRow += '<div class="avatar" id="'+ searchList[i]['id'] +'" price="'+ searchList[i]['price'] +'" unit="'+ searchList[i]['unit'] +'">';
                htmlRow += '<div class="icon"><img src="images/data/'+ searchList[i]['url'] +'" width="100%" height="100%"></div>';
                if(store != "my") {
                    if(searchList[i]['unit'] == "gem") {
                        htmlRow += '<img class="price-gem" src="images/avatar/99.png">';
                    }else if(searchList[i]['unit'] == "star") {
                        htmlRow += '<img class="price-star" src="images/avatar/sao100000.png">';
                    }
                }
                htmlRow += '</div>';
                if((i+1) % 4 == 0 || i == searchList.length-1) {
                    html += '<div class="row">';
                    html += htmlRow;
                    html += '</div>';
                    htmlRow = "";
                }
            }
            html += '</div>';
            $(".avatar-area").fadeOut(200, function(){
                $(".avatar-area").replaceWith(html);

                $(".avatar-area").ready(function(){
                    $(".avatar-area").mCustomScrollbar({
                        axis:"yx",
                        scrollButtons:{enable:true},
                        theme:"3d",
                        scrollbarPosition:"outside"
                    });
                });

                $(".avatar").click(function(){
                    var avatarId = $(this).attr("id");
                    var i = Avatar.find(avatarId);

                    var url = avatarIcons[i]['url'];
                    var unit = avatarIcons[i]['unit'];
                    var price = avatarIcons[i]['price'];

                    $("#viewer").fadeOut(200, function(){
                        $(this).attr("src", "images/data/" + url).fadeIn();
                    });

                    $("#viewer").attr("aid", avatarId);
                    $("#viewer").attr("url", url);
                    $("#viewer").attr("unit", unit);
                    $("#viewer").attr("price", price);

                    if(unit == "my"){
                        $(".btn-mua").hide();
                        $(".btn-dung").show();
                        $(".btn-dung").attr("disabled", false);
                    } else {
                        $(".btn-mua").show();
                        $(".btn-dung").hide();
                        $(".btn-mua").attr("disabled", false);
                    }
                });
            });
        },
        sort: function(){
            avatarIcons.sort(function(a,b){return a['id'] - b['id']});
        },
        find: function(id){
            for(var i = 0; i< avatarIcons.length; i++){
                if(avatarIcons[i]['id'] == id) return i;
            }
            return false;
        },
        storeAvatars: function(){
            var ar = [];
            for(var i=0; i< avatarIcons.length; i++){
                if(Avatar.checkInOrder(avatarIcons[i]['id']) || (avatarIcons[i]['unit'] == "my")){
                    continue;
                }
                var obj = {
                    'id' : avatarIcons[i]['id'],
                    'price': avatarIcons[i]['price'],
                    'unit': avatarIcons[i]['unit'],
                    'url': avatarIcons[i]['url']
                };
                ar.push(obj);
            }
            return ar;
        },
        myAvatars: function(){
            var ar = [];
            for(var i=0; i< avatarIcons.length; i++){
                if(Avatar.checkInOrder(avatarIcons[i]['id']) || (avatarIcons[i]['unit'] == "my")){
                    var obj = {
                        'id' : avatarIcons[i]['id'],
                        'price': avatarIcons[i]['price'],
                        'unit': avatarIcons[i]['unit'],
                        'url': avatarIcons[i]['url']
                    };
                    ar.push(obj);
                }
            }
            return ar;
        },
        getOrder: function(){
            var orderAvatar = $.cookie("orderAvatar");
            if(!orderAvatar || orderAvatar.length < 2) return "";
//            orderAvatar = orderAvatar.substring(0, orderAvatar.length -1);
//            orderAvatar = orderAvatar.split("~");
//            orderAvatar.sort();
            return orderAvatar;
        },
        setOrder: function(id){
            var orderAvatar = $.cookie("orderAvatar") || "";
            orderAvatar += id + "~";
            $.cookie("orderAvatar", orderAvatar);
        },
        checkInOrder: function(id){
            var order = Avatar.getOrder();
            var searchID = id + "~";
            if(order.indexOf(searchID) >= 0) return true;
            return false;
        }
    };

    $("#viewer").attr("src", "images/data/" + $.cookie("myAvatar"));
    Avatar.listAvatar(Avatar.storeAvatars());

    $(".btn-kho").click(function(){
        Avatar.listAvatar("store");
    });

    $(".btn-co").click(function(){
        Avatar.listAvatar("my");
    });

    $(".btn-dung").click(function(){
        $('#use-avatar').bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('#use-avatar').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });
    $(".btn-mua").click(function(){
        $('#buy-avatar').bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('#buy-avatar').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });

    $("#btn-use-avatar").click(function(){
        var url = $("#viewer").attr("url");
        var unit = $("#viewer").attr("unit");
        if(!url || !unit) return;

        $.cookie("myAvatar", url);
        $(".btn-dung").attr("disabled", true);
        $(".btn-cancel").trigger("click");
    });

    var errorMessage  = $(".p-error").html();
    $("#btn-buy-avatar").click(function(){
        var aid = $("#viewer").attr("aid");
        var url = $("#viewer").attr("url");
        var unit = $("#viewer").attr("unit");
        var price = parseInt($("#viewer").attr("price"), 10);
        var myGem = parseInt($(".gem").text(), 10);
        var myStar = parseInt($(".sao").text(), 10);
        var password = $(".popup-password").val();

        if(!url || !unit) return;

        //check password
        if(password != "123456") {
            $(".p-error").html("Mật khẩu không đúng, vui lòng nhập lại!");
            return;
        }else {
            $(".p-error").html(errorMessage);
            $(".popup-password").val("");
        }

        Avatar.setOrder(aid);
        Avatar.listAvatar("store");
        Avatar.listAvatar("my");

        if(unit == "gem"){
            $.cookie("myGem", myGem - price);
            $(".gem").text(myGem - price);
        } else {
            $.cookie("myStar", myStar - price);
            $(".sao").text(myStar - price);
        }
        $.cookie("myAvatar", url);
        $(".btn-mua").attr("disabled", true);
        $(".btn-cancel").trigger("click");
    });
});