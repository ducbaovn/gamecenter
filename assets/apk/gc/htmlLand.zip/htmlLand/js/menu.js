jQuery(document).ready(function ($) {
    $(".view0").show();

    $(".btn-sound,.btn-rung,.btn-alert").click(function(){
        var isPause = this.src.indexOf('tat.png') != -1;
        this.src    = isPause  ? this.src.replace('tat.png', 'bat.png') : this.src.replace('bat.png','tat.png');
    });

    $(".btn-change-name").click(function(){
        var newName = $(".new-name").val();
        if(!newName || newName.length < 3 || newName.length >10){
            $(".error").text("Tên không hợp lệ hoặc đã người có sử dụng.");
        }else {

            if(newName == "123456") {
                $("#recharge").bPopup({
                    speed: 650,
                    closeClass: "btn-cancel"
                });
                $("#recharge").css({
                    '-webkit-transform' : 'scale('+zoom+')',
                    '-moz-transform' : 'scale('+zoom+')',
                    '-ms-transform' : 'scale('+zoom+')',
                    '-o-transform' : 'scale('+zoom+')',
                    'transform' : 'scale('+zoom+')'
                });
                return;
            }

            $(".error").text("");
            $("#p-new-name").text(newName);

            $('#change-name').bPopup({
                speed: 650,
                closeClass: "btn-cancel"
            });
            $('#change-name').css({
                '-webkit-transform' : 'scale('+zoom+')',
                '-moz-transform' : 'scale('+zoom+')',
                '-ms-transform' : 'scale('+zoom+')',
                '-o-transform' : 'scale('+zoom+')',
                'transform' : 'scale('+zoom+')'
            });
        }
    });

    $("#btn-ok").click(function(){
        var myGem = $.cookie("myGem");
        myGem = parseInt(myGem, 10);
        myGem -= 50;

        $.cookie("myGem", myGem);
        $.cookie("myUser", $(".new-name").val());

        //close
        $(".btn-cancel").trigger("click");
    });

    $("#doi-nap").click(function(){
        window.location.href = 'pay.html';
    });

    $(".btn-change-password").click(function(){
        var currentPassword = $(".current-password").val();
        var newPassword = $(".new-password").val();
        var confirmPassword = $(".password-confirm").val();

        if(!currentPassword || !newPassword || !confirmPassword){
            $(".error").text("Vui lòng nhập đầy đủ thông tin.");
        }else if(currentPassword != "123456"){
            $(".error").text("Mật khẩu cũ chưa đúng.");
        } else if(newPassword != confirmPassword){
            $(".error").text("Mật khẩu xác nhận chưa đúng.");
        }else {
            $(".error").text("Đổi mật khẩu thành công.");
            setTimeout(function(){window.location.href = 'landing.html';}, 2000);
        }
    });

    $(".create").click(function(){
        var nick = $(".nick").val();
        var email = $(".email").val();
        var password1 = $(".password1").val();
        var password2 = $(".password2").val();
        var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

        if(!nick || !email || !password1 || !password2) {
            $(".error-sync").text("Nhập đầy đủ thông tin.");return;
        } else if(nick.length < 3 || nick.length > 10) {
            $(".error-sync").text("Tên không hợp lệ.");return;
        } else if(!reg.test(email)) {
            $(".error-sync").text("Email không hợp lệ.");return;
        } else if(password1 != password2) {
            $(".error-sync").text("Mật khẩu xác nhận không đúng.");return;
        } else {
            $(".error-sync").text("Đồng bộ tài khoản thành công.");return;
        }
    });
});