jQuery(document).ready(function ($) {
    $(".message0").show();

    $(".news-area").mCustomScrollbar({
        axis:"yx",
        scrollButtons:{enable:true},
        theme:"3d",
        scrollbarPosition:"outside"
    });

    $(".btn-del").click(function(){
        $('.popup-confirm-order').bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('.popup-confirm-order').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });

    $(".btn-ok").click(function(){
        $(".news-area").fadeOut();

        //close
        $(".btn-cancel").trigger("click");
    });

    var timeOut;
    $(".row").click(function(){
        var timeClose = 6000;
        var dIndex = $(this).attr("d-index");
        $(this).attr("d-index", dIndex.replace("99", ""));

        $(".news-content").remove();
        $(this).children().last().attr("class", "viewed").text("Đã xem");
        $(this).after('<div class="news-content">Nhân dịp trung sắp tới hệ thống Game Center tặng các cao thủ nhiều món quà hấp dẫn và nhiều sự kiện để tăng điểm kinh nghiệp lên một cách nhanh chóng. Hay nhanh chân trong dịp trung thu này nhé!</div>');
        $(".news-content").ready(function(){
            $(".news-content").fadeIn();
        });

        //sort news list after time variable
        if(timeOut) clearTimeout(timeOut);
        timeOut = setTimeout(function(){
            $(".news-content").fadeOut(1000, function(){
                var myList = $('#newsContainer');
                var listItems = myList.children('.row').get();
                listItems.sort(function(a, b) {
                    return parseInt($(b).attr("d-index"), 10) - parseInt($(a).attr("d-index"), 10);
                })
                $.each(listItems, function(idx, itm) { myList.append(itm); });
            });
        }, timeClose);
    });
});