jQuery(document).ready(function ($) {
    $(".view0").show();

    $(".h0-nick").text($.cookie("myUser"));
    $(".level").text($.cookie("myRank"));
    var avatarUrl = $(".h0-avata").attr('src');
    avatarUrl = avatarUrl.replace("home/avatar.png", "data/" + $.cookie("myAvatar"));
    $(".h0-avata").attr('src', avatarUrl);

});