jQuery(document).ready(function ($) {
    $(".view0").show();



    var options = {
        $DragOrientation: 3,
        $ArrowNavigatorOptions: {
            $Class: $JssorArrowNavigator$,
            $ChanceToShow: 2,
            $AutoCenter: 0,
            $Steps: 1
        }
    };

    var jssor_slider1 = new $JssorSlider$("slider1_container", options);
    var jssor_slider2 = new $JssorSlider$("slider2_container", options);
    var jssor_slider3 = new $JssorSlider$("slider3_container", options);
    var jssor_slider4 = new $JssorSlider$("slider4_container", options);
    var jssor_slider5 = new $JssorSlider$("slider5_container", options);

    $("img[type='button']").click(function(){
        $("img[type='button']").each(function(i, e){
            $(e).attr("src", $(e).attr("src").replace("on.", "off."));
            $("#"+$(e).attr("container")).fadeOut();
        });

        $(this).attr("src", $(this).attr("src").replace("off.", "on."));
        $("#"+$(this).attr("container")).fadeIn();
    });
});