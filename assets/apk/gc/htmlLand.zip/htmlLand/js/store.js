jQuery(document).ready(function ($) {
    $(".store0").show();

    //load data
    var myGem = $.cookie("myGem");
    var myStar = $.cookie("myStar");

    if(myGem && myGem.length > 0){
        $(".s0-gem").text(myGem);
    } else {
        $(".s0-gem").text("9999");
    }
    if(myStar && myStar.length > 0){
        $(".s0-sao").text(myStar);
    } else {
        $(".s0-sao").text("900000");
    }

    var widthDevice = 1280;
    var jssor_slider1 = new $JssorSlider$("slider1_container");
    var jssor_slider2 = new $JssorSlider$("slider2_container");

    function ScaleSlider() {
        var bodyWidth = document.body.clientWidth;
        if (bodyWidth)
        {
            jssor_slider1.$SetScaleWidth(Math.min(bodyWidth, widthDevice));
            jssor_slider2.$SetScaleWidth(Math.min(bodyWidth, widthDevice));
        }
        else
            window.setTimeout(ScaleSlider, 30);
    }
    if (!navigator.userAgent.match(/(iPhone|iPod|iPad|BlackBerry|IEMobile)/)) {
        //$(window).bind('resize', ScaleSlider);
    }

    $(".s0-ingame,.s0-ingame-act").click(function(){
        $(".s0-ingame-act").show();
        $(".s0-ingame").hide();
        $(".s0-outgame").show();
        $(".s0-outgame-act").hide();

        $("#slider1_container").hide();
        $("#slider2_container").show();
    });
    $(".s0-outgame").click(function(){
        $(".s0-ingame-act").hide();
        $(".s0-ingame").show();
        $(".s0-outgame").hide();
        $(".s0-outgame-act").show();

        $("#slider1_container").show();
        $("#slider2_container").hide();
    });

    $(".slides2").find("img").click(function(){
        $("#slider1_container").show();
        $("#slider2_container").hide();
    });

    var confirmOrder = function (){
        $('.popup-confirm-order').bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('.popup-confirm-order').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    };
    $(".s0-vp-gem").click(function(){
        $(".p-item").html("VẬT PHẨM TÀI TRỢ");
        $(".p-money").html("99");
        $(".p-gem").show();
        $(".p-star").hide();
        confirmOrder();
    });

    $(".s0-vp-sao").click(function(){
        $(".p-item").html("VẬT PHẨM TÀI TRỢ");
        $(".p-money").html("100000");
        $(".p-gem").hide();
        $(".p-star").show();
        confirmOrder();
    });

    var errorMessage  = $(".p-error").html();

    $(".btn-ok").click(function(){
        var password = $(".popup-password").val();

        //check password
        if(password != "123456") {
            $(".p-error").html("Mật khẩu không đúng, vui lòng nhập lại!");
            return;
        }else {
            $(".p-error").html(errorMessage);
            $(".popup-password").val("");
        }

        //buy store item
        if($(".p-star").is(':hidden')){
            var gem = parseInt($(".s0-gem").html(), 10);
            gem -= 99;
            $(".s0-gem").html(gem);
            $.cookie("myGem", gem);
        } else {
            var sao = parseInt($(".s0-sao").html(), 10);
            sao -= 10000;
            $(".s0-sao").html(sao);
            $.cookie("myStar", sao);
        }

        //close
        $(".btn-cancel").trigger("click");
    });
});