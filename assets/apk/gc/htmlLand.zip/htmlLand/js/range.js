jQuery(document).ready(function ($) {
    $(".range0").show();

    Users.sort(function(a,b){return b['total'] - a['total']});

    var User = {
        level: 80,
        totalRang: 0,
        getLevel:function(total){
            for(var j=1; j< 100; j++){
                if(total < (343 + j*10)){
                    return this.level += j;
                }
            }
            return this.level;
        },
        getTotalRang:function(arr){
            return arr['quick'] + arr['exactly'] +arr['logic'] +arr['natural'] +arr['social'] +arr['language'];
        },
        listRang: function(){
            var sortRank = $.cookie("sortRank");
            var myUser = "Paragon";//$.cookie("myUser");
            var aRank = User.findUser(myUser);

            sortRank = (sortRank) ? sortRank : "ALL";
            aRank = (sortRank == "ALL") ? 0 : aRank;

            var html = '<div class="rangScroll">';
            for(var i = aRank; i< Users.length; i++){
                var fr = "";
                switch (i) {
                    case 0 : fr = "rank-first"; break;
                    case 1 : fr = "rank-second"; break;
                    case 2 : fr = "rank-third"; break;
                }
                html += '<div class="row"><div class="item-avatar"><img src="images/data/'+ Users[i]['avatar'] +'" width="60"></div>';
                html += '<div class="item-info"><div class="item-level">Lv <span>'+ Users[i]['level'] +'</span></div>';
                html += '<div class="item-name">'+ Users[i]['name'] +'</div></div>';
                html += '<div class="item-quick">'+ Users[i]['quick'] +'</div>';
                html += '<div class="item-exactly">'+ Users[i]['exactly'] +'</div>';
                html += '<div class="item-logic">'+ Users[i]['logic'] +'</div>';
                html += '<div class="item-natural">'+ Users[i]['natural'] +'</div>';
                html += '<div class="item-social">'+ Users[i]['social'] +'</div>';
                html += '<div class="item-language">'+ Users[i]['language'] +'</div>';
                html += '<div class="item-rank '+fr+'">'+(i + 1)+'</div></div>';
            }
            html += '</div>';
            $(".rangScroll").fadeOut(200, function(){
                $(".rangScroll").replaceWith(html);

                $(".rangScroll").ready(function(){
                    $(".rangScroll").mCustomScrollbar({
                        axis:"yx",
                        scrollButtons:{enable:true},
                        theme:"3d",
                        scrollbarPosition:"outside"
                    });
                });
            });
        },
        sortRank: function(field){
            Users.sort(function(a,b){return b[field] - a[field]});
        },
        findUser: function(user){
            for(var i = 0; i< Users.length; i++){
                if(Users[i]['name'] == user) return i;
            }
            return 0;
        }
    };

    $.cookie("sortRank", "ALL");
    User.listRang();

    $(".quick").click(function(){
        $(".bar").css("color", "white");$(".quick").css("color", "#ff0e85");
        User.sortRank('quick');
        User.listRang();
    });
    $(".exactly").click(function(){
        $(".bar").css("color", "white");$(".exactly").css("color", "#ff0e85");
        User.sortRank('exactly');
        User.listRang();
    });
    $(".logic").click(function(){
        $(".bar").css("color", "white");$(".logic").css("color", "#ff0e85");
        User.sortRank('logic');
        User.listRang();
    });
    $(".natural").click(function(){
        $(".bar").css("color", "white");$(".natural").css("color", "#ff0e85");
        User.sortRank('natural');
        User.listRang();
    });
    $(".social").click(function(){
        $(".bar").css("color", "white");$(".social").css("color", "#ff0e85");
        User.sortRank('social');
        User.listRang();
    });
    $(".language").click(function(){
        $(".bar").css("color", "white");$(".language").css("color", "#ff0e85");
        User.sortRank('language');
        User.listRang();
    });
    $(".btn-all").click(function(){
        $(".bar").css("color", "white");
        User.sortRank('total');

        $.cookie("sortRank", "ALL");

        User.listRang();
    });
    $(".btn-my-rang").click(function(){
        $(".bar").css("color", "white");
        User.sortRank('total');

        $.cookie("sortRank", "MY");

        User.listRang();
    });



});