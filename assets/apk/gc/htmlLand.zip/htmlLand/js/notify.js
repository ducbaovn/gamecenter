jQuery(document).ready(function ($) {
    $(".view0").show();

    $(".notify-area").mCustomScrollbar({
        axis:"y",
        scrollButtons:{enable:true},
        theme:"3d",
        scrollbarPosition:"outside"
    });

    //Show timing
    var TimeSystem = function(){
        var t = new Date();
        var h = t.getHours();
        var m = t.getMinutes();
        var s = t.getSeconds();
        var dy = t.getDate();
        var mo = t.getMonth();
        var yr = t.getFullYear();

        var b = (h>=12)?"PM":"AM";

        h = (h>12)?(h-12):h; h = (h<10)?("0"+h):h;
        m = (m<10)?("0" + m):m;
        s = (s<10)?("0" + s):s;

        var hour = h + ":" + m + ":" + s + " " + b;
        var date = dy + " tháng " + mo + " năm " + yr;

        $(".hour").text(hour);
        $(".date").text(date);
        setTimeout(TimeSystem, 1000);
    }; TimeSystem();
});