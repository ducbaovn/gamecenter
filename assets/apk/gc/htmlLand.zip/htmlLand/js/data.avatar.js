var avatarIcons = [{
    'id' : 1,
    'price': 99,
    'unit': "gem",
    'url' : "AngryBirdsSeasons-02.jpg"
},{
    'id' : 2,
    'price': 99,
    'unit': "gem",
    'url': "Angry-Birds-Space105.png"
},{
    'id' : 3,
    'price': 99,
    'unit': "gem",
    'url': "Kingdoms-Live-1.jpg"
},{
    'id' : 4,
    'price': 99,
    'unit': "gem",
    'url': "bat-chu-21.png"
},{
    'id' : 5,
    'price': 99,
    'unit': "gem",
    'url': "Blitz-Brigade1.png"
},{
    'id' : 6,
    'price': 100000,
    'unit': "star",
    'url': "candy-soda1.png"
},{
    'id' : 7,
    'price': 100000,
    'unit': "star",
    'url': "CarX1.png"
},{
    'id' : 8,
    'price': 100000,
    'unit': "star",
    'url': "CSI1.png"
},{
    'id' : 9,
    'price': 100000,
    'unit': "star",
    'url': "Elves-Realm105.png"
},{
    'id' : 10,
    'price': 100000,
    'unit': "star",
    'url': "Empire1.png"
},{
    'id' : 11,
    'price': 100000,
    'unit': "star",
    'url': "Forest-Runner105.png"
},{
    'id' : 12,
    'price': 100000,
    'unit': "star",
    'url': "Ice-Age-Adventures1.png"
},{
    'id' : 13,
    'price': 100000,
    'unit': "star",
    'url': "Iron-Knights1.png"
},{
    'id' : 14,
    'price': 0,
    'unit': "star",
    'url': "JewelsSaga105.png"
},{
    'id' : 15,
    'price': 0,
    'unit': "my",
    'url': "AvatarHD105.png"
},{
    'id' : 16,
    'price': 0,
    'unit': "my",
    'url': "Kritika1.png"
},{
    'id' : 17,
    'price': 0,
    'unit': "my",
    'url': "Mega-Jump1.png"
},{
    'id' : 18,
    'price': 0,
    'unit': "my",
    'url': "Pyramid-Solitaire-Saga1.png"
},{
    'id' : 19,
    'price': 0,
    'unit': "my",
    'url': "RealFootball105.png"
},{
    'id' : 20,
    'price': 0,
    'unit': "my",
    'url': "Temple-Run-2-1.png"
},{
    'id' : 21,
    'price': 0,
    'unit': "my",
    'url': "Tyrant-Unleashed1.png"
}
];