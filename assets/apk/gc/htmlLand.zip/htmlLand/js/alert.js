jQuery(document).ready(function ($) {
    $(".view0").show();

    //press accept challenge
    $(".accept").click(function(){
        $('#challenge').bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('#challenge').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });

    var errorMessage  = $(".p-error").html();
    $("#btn-challenge").click(function(){
        var password = $("#password").val();

        //check password
        if(password != "123456") {
            $(".p-error").html("Mật khẩu không đúng, vui lòng nhập lại!");
            return;
        }else {
            $(".p-error").html(errorMessage);
            $(".popup-password").val("");
        }

        var myGem = $.cookie("myGem");
        $.cookie("challenge", "");
        $.cookie("myGem", parseInt(myGem, 10) - 10);
        $(".accept,.alert-item").fadeOut(200);

        $(".btn-cancel").trigger("click");
    });

    //Show timing
    var TimeSystem = function(){
        var t = new Date();
        var h = t.getHours();
        var m = t.getMinutes();
        var s = t.getSeconds();
        var dy = t.getDate();
        var mo = t.getMonth();
        var yr = t.getFullYear();

        var b = (h>=12)?"PM":"AM";

        h = (h>12)?(h-12):h; h = (h<10)?("0"+h):h;
        m = (m<10)?("0" + m):m;
        s = (s<10)?("0" + s):s;

        var hour = h + ":" + m + ":" + s + " " + b;
        var date = dy + " tháng " + mo + " năm " + yr;

        $(".hour").text(hour);
        $(".date").text(date);
        setTimeout(TimeSystem, 1000);
    }; TimeSystem();
});