jQuery(document).ready(function ($) {
    $(".view0").show();

    $(".friend-area").mCustomScrollbar({
        axis:"yx",
        scrollButtons:{enable:true},
        theme:"3d",
        scrollbarPosition:"outside"
    });

    // default for search text
    $(".search-text").css("color", "#cecece");
    $(".search-text").val('Gõ tên đăng nhập');
    $(".search-text").blur(function(){
        if($(".search-text").val() == '') {
            $(".search-text").val('Gõ tên đăng nhập');
            $(".search-text").css("color", "#cecece");
            $(".friend-area").fadeOut(200);
        }
    });
    $(".search-text").focus(function(){
        if($(".search-text").val() == 'Gõ tên đăng nhập') {
            $(".search-text").val('');
            $(".search-text").css("color", "black");
        }
    });

    Users.sort(function(a,b){return b['total'] - a['total']});

    var User = {
        level: 80,
        totalRang: 0,
        getLevel:function(total){
            for(var j=1; j< 100; j++){
                if(total < (343 + j*10)){
                    return this.level += j;
                }
            }
            return this.level;
        },
        getTotalRang:function(arr){
            return arr['quick'] + arr['exactly'] +arr['logic'] +arr['natural'] +arr['social'] +arr['language'];
        },
        listSearch: function(){
            var key = $(".search-text").val();
            if($.trim(key) == '') {$(".friend-area").fadeOut(200); return;}
            var searchUser = this.findUserWithName(key);

            var html = '<div class="friend-area">';
            for(var i = 0; i< searchUser.length; i++){
                html += '<div class="row" id="'+ searchUser[i]['name'] +'">';
                html += '<div class="avatar"><img src="images/data/'+ searchUser[i]['avatar'] +'" width="60"></div>';
                html += '<div class="username">'+ searchUser[i]['name'] +'</div>';
                html += '<div class="level">Lv '+ searchUser[i]['level'] +'</div>';
                html += '<div class="rank">Rank: '+ searchUser[i]['rank'] +'</div>';
                html += '<a href="javascript:void(0);"><img uname="'+ searchUser[i]['name'] +'" class="btn-request" src="images/friend/btn-request.png"></a>';
                html += '</div>';
            }
            html += '</div>';
            $(".friend-area").fadeOut(200, function(){
                $(".friend-area").replaceWith(html);

                $(".friend-area").ready(function(){
                    $(".friend-area").mCustomScrollbar({
                        axis:"yx",
                        scrollButtons:{enable:true},
                        theme:"3d",
                        scrollbarPosition:"outside"
                    });
                });

                $(".btn-request").click(function(){
                    var userId = $(this).attr("uname");
                    $("#friend-invite").text(userId);

                    $('.popup-confirm-order').bPopup({
                        speed: 650,
                        closeClass: "btn-cancel"
                    });
                    $('.popup-confirm-order').css({
                        '-webkit-transform' : 'scale('+zoom+')',
                        '-moz-transform' : 'scale('+zoom+')',
                        '-ms-transform' : 'scale('+zoom+')',
                        '-o-transform' : 'scale('+zoom+')',
                        'transform' : 'scale('+zoom+')'
                    });
                });
            });
        },
        listWaiting: function(){
            var key = "r";
            var searchUser = this.findUserWithName(key);

            var html = '<div class="friend-accept">';
            for(var i = 0; i< searchUser.length; i++){
                html += '<div class="row2" id="r2'+ searchUser[i]['name'] +'">';
                html += '<div class="avatar"><img src="images/data/'+ searchUser[i]['avatar'] +'" width="60"></div>';
                if(searchUser[i]['online']) {
                    html += '<img class="online" src="images/friend/online.png">';
                }else {
                    html += '<img class="online" src="images/friend/offline.png">';
                }
                html += '<div class="username">'+ searchUser[i]['name'] +'</div>';
                html += '<div class="level">Lv '+ searchUser[i]['level'] +'</div>';
                html += '<div class="rank">Rank: '+ searchUser[i]['rank'] +'</div>';
                html += '<a href="javascript:void(0);"><img uname="'+ searchUser[i]['name'] +'" class="btn-no" src="images/friend/btn-no.png"></a>';
                html += '<a href="javascript:void(0);"><img uname="'+ searchUser[i]['name'] +'" class="row-ok" src="images/friend/btn-ok.png"></a>';
                html += '</div>';
            }
            html += '</div>';
            $(".friend-accept").fadeOut(200, function(){
                $(".friend-accept").replaceWith(html);

                $(".friend-accept").ready(function(){
                    $(".friend-accept").mCustomScrollbar({
                        axis:"yx",
                        scrollButtons:{enable:true},
                        theme:"3d",
                        scrollbarPosition:"outside"
                    });
                });

                $(".btn-no").click(function(){
                    var userId = $(this).attr("uname");
                    $("#r2" + userId).fadeOut(200);
                });
                $(".row-ok").click(function(){
                    var userId = $(this).attr("uname");
                    $("#r2" + userId).fadeOut(200);
                });
            });
        },
        listFriend: function(){
            var key = "a";
            var searchUser = this.findUserWithName(key);

            var html = '<div class="friend-list">';
            for(var i = 0; i< searchUser.length; i++){
                html += '<div class="row3" id="r3'+ searchUser[i]['name'] +'">';
                html += '<div class="avatar"><img src="images/data/'+ searchUser[i]['avatar'] +'" width="60"></div>';
                if(searchUser[i]['online']) {
                    html += '<img class="online" src="images/friend/online.png">';
                }else {
                    html += '<img class="online" src="images/friend/offline.png">';
                }
                html += '<div class="username">'+ searchUser[i]['name'] +'</div>';
                html += '<div class="level">Lv '+ searchUser[i]['level'] +'</div>';
                html += '<div class="rank">Rank: '+ searchUser[i]['rank'] +'</div>';
                html += '<a href="javascript:void(0);"><img uname="'+ searchUser[i]['name'] +'" class="btn-xoa" src="images/friend/btn-xoa.png"></a>';
                html += '</div>';
            }
            html += '</div>';
            $(".friend-list").fadeOut(200, function(){
                $(".friend-list").replaceWith(html);

                $(".friend-list").ready(function(){
                    $(".friend-list").mCustomScrollbar({
                        axis:"yx",
                        scrollButtons:{enable:true},
                        theme:"3d",
                        scrollbarPosition:"outside"
                    });
                });

                $(".btn-xoa").click(function(){
                    var userId = $(this).attr("uname");
                    $("#friend-remove").text(userId);

                    $('#remove-friend').bPopup({
                        speed: 650,
                        closeClass: "btn-cancel"
                    });
                    $('#remove-friend').css({
                        '-webkit-transform' : 'scale('+zoom+')',
                        '-moz-transform' : 'scale('+zoom+')',
                        '-ms-transform' : 'scale('+zoom+')',
                        '-o-transform' : 'scale('+zoom+')',
                        'transform' : 'scale('+zoom+')'
                    });
                });
            });
        },
        listLock: function(){
            var key = "k";
            var searchUser = this.findUserWithName(key);

            var html = '<div class="friend-lock">';
            for(var i = 0; i< searchUser.length; i++){
                html += '<div class="row3" id="r4'+ searchUser[i]['name'] +'">';
                html += '<div class="avatar"><img src="images/data/'+ searchUser[i]['avatar'] +'" width="60"></div>';
                if(searchUser[i]['online']) {
                    html += '<img class="online" src="images/friend/online.png">';
                }else {
                    html += '<img class="online" src="images/friend/offline.png">';
                }
                html += '<div class="username">'+ searchUser[i]['name'] +'</div>';
                html += '<div class="level">Lv '+ searchUser[i]['level'] +'</div>';
                html += '<div class="rank">Rank: '+ searchUser[i]['rank'] +'</div>';
                html += '<a href="javascript:void(0);"><img uname="'+ searchUser[i]['name'] +'" class="btn-xoa" src="images/friend/btn-go-chan.png"></a>';
                html += '</div>';
            }
            html += '</div>';
            $(".friend-lock").fadeOut(200, function(){
                $(".friend-lock").replaceWith(html);

                $(".friend-lock").ready(function(){
                    $(".friend-lock").mCustomScrollbar({
                        axis:"yx",
                        scrollButtons:{enable:true},
                        theme:"3d",
                        scrollbarPosition:"outside"
                    });
                });

                $(".btn-xoa").click(function(){
                    var userId = $(this).attr("uname");
                    $("#r4" + userId).fadeOut(200);
                });
            });
        },
        sortRank: function(field){
            Users.sort(function(a,b){return b[field] - a[field]});
        },
        findUser: function(user){
            for(var i = 0; i< Users.length; i++){
                if(Users[i]['name'] == user) return i;
            }
            return 0;
        },
        findUserWithName: function(text){
            var ar = [];
            text = text.toLowerCase();
            for(var i = 0; i < Users.length; i++) {
                if((Users[i]['name'].toLowerCase().search(text) > -1) && (Users[i]['name'] != $.cookie("myUser"))){
                    var obj = {"avatar": Users[i]['avatar'], "name" : Users[i]['name'], "online" : Users[i]['online'], "level" : Users[i]['level'], "rank" : (i + 1)};
                    ar.push(obj)
                }
            }
            return ar;
        }
    };

    $(".btn-them").hide();

    $(".btn-tim").click(function(){
        User.sortRank();
        User.listSearch();
    });

    $(".search-text").keyup(function(){
        User.sortRank();
        User.listSearch();
    });

    $(".btn-ok").click(function(){
        var friendInvite = $("#friend-invite").text();
        $("#" + friendInvite).delay(650).fadeOut(200);
        //close
        $(".btn-cancel").trigger("click");
    });
    $("#btn-ok-remove").click(function(){
        var friendRemove = $("#friend-remove").text();
        $("#r3" + friendRemove).delay(650).fadeOut(200);
        //close
        $(".btn-cancel").trigger("click");
    });

    $(".btn-them").click(function(){
        $("[class^='view']").fadeOut();
        $(".view0").fadeIn();

        $(".btn-them").hide();
        $(".btn-ban,.btn-chan,.btn-cho").show();
        $(".directory").text("");
    });

    $(".btn-cho").click(function(){
        $("[class^='view']").fadeOut();
        $(".view1").fadeIn();

        $(".btn-cho").hide();
        $(".btn-ban,.btn-chan,.btn-them").show();
        User.listWaiting();
        $(".directory").text("DANH SÁCH CHỜ");
    });

    $(".btn-ban").click(function(){
        $("[class^='view']").fadeOut();
        $(".view2").fadeIn();

        $(".btn-ban").hide();
        $(".btn-cho,.btn-chan,.btn-them").show();
        User.listFriend();
        $(".directory").text("DANH SÁCH BẠN");
    });

    $(".btn-chan").click(function(){
        $("[class^='view']").fadeOut();
        $(".view3").fadeIn();

        $(".btn-chan").hide();
        $(".btn-cho,.btn-ban,.btn-them").show();
        User.listLock();
        $(".directory").text("DANH SÁCH CHẶN");
    });
});