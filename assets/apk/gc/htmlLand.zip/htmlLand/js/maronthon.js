jQuery(document).ready(function ($) {
    $(".view0").show();

    //load data
    var myGem = $.cookie("myGem");
    var myStar = $.cookie("myStar");
    var myRuby = $.cookie("myRuby");


    if(myGem && myGem.length > 0){
        $(".gem").text(myGem);
    } else {
        myGem = 9999;
        $(".gem").text("9999");
    }
    if(myStar && myStar.length > 0){
        $(".star").text(myStar);
    } else {
        myStar = 900000;
        $(".star").text("900000");
    }
    if(myRuby && myRuby.length > 0){
        $(".ruby").text(myRuby);
    } else {
        myRuby = 1090000;
        $(".ruby").text("1090000");
    }

    //press accept or ignore invitation
    $(".accept,.ignore").click(function(){
        $(".invitation,.accept,.ignore").fadeOut();
    });

    //press challenge
    $(".challenge").click(function(){
        $('#challenge').bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('#challenge').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });

    $("#btn-challenge").click(function(){
        $.cookie("challenge", "DucChanh đạt điểm thượng thừa trong game Maronthon");
        $(".challenge").attr("disabled", true);
        $(".btn-cancel").trigger("click");
    });

    $(".form-ruby").keyup(function(){
        var rb = parseInt($(this).val(), 10);
        if(rb > myRuby) {
            rb  = myRuby;
            $(this).val(myRuby);
        }
        var star = Math.floor(rb / 10);
        if(star > 0) {
            $(".to-star").val(star);
        }else {
            $(".to-star").val("");
        }
    });
    $(".form-gem").keyup(function(){
        var g = parseInt($(this).val(), 10);
        if(g > myGem) {
            g  = myGem;
            $(this).val(myGem);
        }
        if(g > 0) {
            $(".to-ruby").val(g * 1000);
        }else {
            $(".to-ruby").val("");
        }
    });

    $(".recharge1").click(function(){
        var formRuby = parseInt($(".form-ruby").val(), 10);
        var toStar = parseInt($(".to-star").val(), 10);

        if($(".to-star").val() == "" || formRuby < 10 || toStar <1) {
            $(".error").show().text("Vui lòng nhập lại số Ruby.");
            $(".error").delay(3000).fadeOut(1000);
            return;
        }

        $("#fom-ruby").text(toStar * 10);
        $("#to-star").text(toStar);

        $("#ruby-to-star").bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('#ruby-to-star').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });

    $(".recharge2").click(function(){
        var formGem = parseInt($(".form-gem").val(), 10);
        var toRuby = parseInt($(".to-ruby").val(), 10);

        if($(".to-ruby").val() == "" || formGem < 1 || toRuby < 1000) {
            $(".error").show().text("Vui lòng nhập lại số Gem.");
            $(".error").delay(3000).fadeOut(1000);
            return;
        }

        $("#fom-gem").text(formGem);
        $("#to-ruby").text(toRuby);

        $("#gem-to-ruby").bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $("#gem-to-ruby").css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });

    //When press ok on popup
    var errorMessage  = $(".p-error").html();
    $("#btn-to-star").click(function(){
        var myRuby = parseInt($(".ruby").text(), 10);
        var myStar = parseInt($(".star").text(), 10);
        var password = $("#password1").val();
        var formRuby = parseInt($("#fom-ruby").text(), 10);
        var toStar = parseInt($("#to-star").text(), 10);

        if(!formRuby || !toStar) return;

        //check password
        if(password != "123456") {
            $(".p-error").html("Mật khẩu không đúng, vui lòng nhập lại!");
            return;
        }else {
            $(".p-error").html(errorMessage);
            $(".popup-password").val("");
        }

        myRuby -= formRuby;
        myStar += toStar;

        $.cookie("myRuby", myRuby);
        $(".ruby").text(myRuby);
        $.cookie("myStar", myStar);
        $(".star").text(myStar);

        $(".form-ruby").val("");
        $(".to-star").val("");

        $(".btn-cancel").trigger("click");
    });

    $("#btn-to-ruby").click(function(){
        var myGem = parseInt($(".gem").text(), 10);
        var myRuby = parseInt($(".ruby").text(), 10);
        var password = $("#password2").val();

        var formGem = parseInt($("#fom-gem").text(), 10);
        var toRuby = parseInt($("#to-ruby").text(), 10);

        if(!formGem || !toRuby) return;

        //check password
        if(password != "123456") {
            $(".p-error").html("Mật khẩu không đúng, vui lòng nhập lại!");
            return;
        }else {
            $(".p-error").html(errorMessage);
            $(".popup-password").val("");
        }

        myGem -= formGem;
        myRuby += toRuby;

        $.cookie("myGem", myGem);
        $(".gem").text(myGem);
        $.cookie("myRuby", myRuby);
        $(".ruby").text(myRuby);

        $(".form-gem").val("");
        $(".to-ruby").val("");

        $(".btn-cancel").trigger("click");
    });
});