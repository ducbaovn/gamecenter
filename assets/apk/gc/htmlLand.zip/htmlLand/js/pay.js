jQuery(document).ready(function ($) {
    $(".pay0").show();

    //load data
    var myGem = $.cookie("myGem");
    var myStar = $.cookie("myStar");

    if(myGem && myGem.length > 0){
        $(".nGem1").text(myGem);
    } else {
        $(".nGem1").text("9999");
    }
    if(myStar && myStar.length > 0){
        $(".nStar1").text(myStar);
    } else {
        $(".nStar1").text("900000");
    }

    var widthDevice = 1280;
    var jssor_slider1 = new $JssorSlider$("slider1_container");

    function ScaleSlider() {
        var bodyWidth = document.body.clientWidth;
        if (bodyWidth)
        {
            jssor_slider1.$SetScaleWidth(Math.min(bodyWidth, widthDevice));
        }
        else
            window.setTimeout(ScaleSlider, 30);
    }
    if (!navigator.userAgent.match(/(iPhone|iPod|iPad|BlackBerry|IEMobile)/)) {
        //$(window).bind('resize', ScaleSlider);
    }

    var gem = 0;
    var changeGem = 1000;

    $(".p-gem,.p-star").show();
    $(".so-gem").keyup(function(){
        gem = $(".so-gem").val();
        var gemStore = $(".nGem1").text();

        gem = parseInt(gem);
        gemStore = parseInt(gemStore);

        if(gem > gemStore){
            $(".so-gem").val(gemStore);
            gem = gemStore;
        }

        if(gem > 0){
            $(".so-star").text(gem * changeGem);
        }else {
            $(".so-star").text("");
        }
    });

    $(".btn-doi").click(function(){
        var soStar = $(".so-star").val();
        if(gem < 1 || soStar=="")
        {
            $(".error").show();
            $(".error").delay(3000).fadeOut(1000);
            return;
        }

        $(".gemToChange").text(gem);
        $(".starToChange").text(gem * changeGem);

        $('.popup-confirm-order').bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('.popup-confirm-order').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });

    var errorMessage  = $(".p-error").html();

    $(".btn-ok").click(function(){
        var password = $(".pw1").val();

        //check password
        if(password != "123456") {
            $(".p-error").html("Mật khẩu không đúng, vui lòng nhập lại!");
            return;
        }else {
            $(".p-error").html(errorMessage);
            $(".pw1").val("");
        }

        //change Gem to Star
        var gemStore = $(".nGem1").text();
        var starStore = $(".nStar1").text();
        gemStore = parseInt(gemStore);
        starStore = parseInt(starStore);

        $(".nGem1").text(gemStore - gem);
        $(".nStar1").text(starStore +(gem * changeGem));
        $(".so-gem").val("");
        $(".so-star").text("");

        $.cookie("myGem", gemStore - gem);
        $.cookie("myStar", starStore +(gem * changeGem));

        //close
        $(".btn-cancel").trigger("click");
    });

    //for pay with card
    $(".mobifone,.viettel,.vinaphone").click(function(){
        $(".pay0").fadeOut();
        $(".pay1").fadeIn();
        $(".nGem2").text($(".nGem1").text());
        $(".nStar2").text($(".nStar1").text());

        var currentItem = $(this).attr('class');
        $("[class^='is-']").hide();
        switch (currentItem){
            case "slides-item mobifone" : $(".is-mobifone").show(); break;
            case "slides-item viettel" : $(".is-viettel").show(); break;
            case "vinaphone" : $(".is-vinaphone").show(); break;
        }
    });

    $(".btn-nap").click(function(){
        var soThe = $(".so-the").val();
        var soSerie = $(".so-serie").val();

        if(soThe.length < 6 || soSerie.length < 6) {
            $(".show-error").text("Số thẻ hoặc số seri không đúng!");
            return;
        } else {
            $(".show-error").text("");
        }

        //show popup
        $('.popup-confirm-card').bPopup({
            speed: 650,
            closeClass: "btn-cancel"
        });
        $('.popup-confirm-card').css({
            '-webkit-transform' : 'scale('+zoom+')',
            '-moz-transform' : 'scale('+zoom+')',
            '-ms-transform' : 'scale('+zoom+')',
            '-o-transform' : 'scale('+zoom+')',
            'transform' : 'scale('+zoom+')'
        });
    });

    $(".btn-ok-card").click(function(){
        var cardPrice = 100;
        var password = $(".pw2").val();

        //check password
        if(password != "123456") {
            $(".p-error").html("Mật khẩu không đúng, vui lòng nhập lại!");
            return;
        }else {
            $(".p-error").html(errorMessage);
            $(".pw2").val("");
        }

        //change Gem to Star
        var gemStore = $(".nGem2").text();
        gemStore = parseInt(gemStore);

        $(".nGem2").text(gemStore + cardPrice);
        $.cookie("myGem", gemStore + cardPrice);

        //close
        $(".btn-cancel").trigger("click");
    });
});