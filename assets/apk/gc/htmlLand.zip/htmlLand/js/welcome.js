jQuery(document).ready(function () {
    $(".welcome0").show();

    $(".use-now,.wc2-use-now").click(function(){
        $("[class^='welcome']").hide();
        $(".welcome1").fadeIn();
    });

    $(".wc1-taikhoan,.use-account,.wc2-login").click(function(){
        $("[class^='welcome']").hide();
        $(".welcome3").fadeIn();
    });

    $(".wc3-forgot").click(function(){
        $("[class^='welcome']").hide();
        $(".welcome2").fadeIn();
    });
});