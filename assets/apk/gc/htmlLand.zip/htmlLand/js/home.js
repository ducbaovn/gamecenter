jQuery(document).ready(function ($) {
    $(".home0").show();

    var widthDevice = 1280;
    var jssor_slider0 = new $JssorSlider$("slider0_container");
    var jssor_slider1 = new $JssorSlider$("slider1_container");
    var jssor_slider2 = new $JssorSlider$("slider2_container");

    function ScaleSlider() {
        var bodyWidth = document.body.clientWidth;
        if (bodyWidth)
        {
            jssor_slider0.$SetScaleWidth(Math.min(bodyWidth, widthDevice));
            jssor_slider1.$SetScaleWidth(Math.min(bodyWidth, widthDevice));
            jssor_slider2.$SetScaleWidth(Math.min(bodyWidth, widthDevice));
        }
        else
            window.setTimeout(ScaleSlider, 30);
    }
    if (!navigator.userAgent.match(/(iPhone|iPod|iPad|BlackBerry|IEMobile)/)) {
        //$(window).bind('resize', ScaleSlider);
    }

    $(".h0-game-relax").click(function(){
        $("#slider0_container").fadeIn();
        $("#slider1_container").fadeOut();
    });
    $(".h0-game-study").click(function(){
        $("#slider0_container").fadeOut();
        $("#slider1_container").fadeIn();
    });

    //load data
    var myGem = $.cookie("myGem");
    var myStar = $.cookie("myStar");
    var myUser = $.cookie("myUser");
    var myRank = $.cookie("myRank");
    var myAvatar = $.cookie("myAvatar");
    var challenge = $.cookie("challenge");

    if(!myUser) $.cookie("myUser", "Paragon");
    if(!myRank) $.cookie("myRank", "11");
    if(!myAvatar) $.cookie("myAvatar", "AvatarHD105.png");

    if(myGem && myGem.length > 0){
        $(".so-gem").text(myGem);
    } else {
        myGem = 9999;
        $(".so-gem").text("9999");
    }
    if(myStar && myStar.length > 0){
        $(".so-star").text(myStar);
    } else {
        myStar = 90000;
        $(".so-star").text("90000");
    }
    if(challenge) $(".h0-alert").show();

    $(".h0-nick").text($.cookie("myUser"));
    $(".level").text($.cookie("myRank"));
    var avatarUrl = $(".h0-avata").attr('src');
    avatarUrl = avatarUrl.replace("home/avatar.png", "data/" + $.cookie("myAvatar"));
    $(".h0-avata").attr('src', avatarUrl);

    //Check challenge mode
    $(".h0-alert,.h0-challenge").click(function(){
        if(!challenge) return;

        window.location.href = 'alert.html';
    });
});

/*======================================= CHAT ===============================================*/

(function($){
    $(window).load(function(){
        var timeOut;
        var timeWaiting = 3000;
        var showChat = $.cookie("showChat");
        var Chat = {
            send: function(){
                var me = $.cookie("myUser");
                var html = '<div class="row"><div class="name">'+ me +':</div><div class="message">'+ $(".chat-text").val() +'</div></div>';

                if($("#scroll2").css("display") == "block") {
                    $("#scroll2").append(html);
                } else {
                    $("#scroll1").append(html);
                }

                $(".chat-text").val("").focus();

                $(".chat-area").mCustomScrollbar('update');
                $(".chat-area").mCustomScrollbar("scrollTo","bottom");

                if(timeOut) clearTimeout(timeOut);
                timeOut = setTimeout(function(){
                    Chat.answer();
                }, timeWaiting);
            },
            answer:function(){
                var dict = ["Chào bạn nhé.",
                    "Chúc ngày mới vui vẻ nhé bạn.",
                    "Hôm qua cu Tèo nó chơi game với mình mà bị thua te tua @@@@",
                    "Có ai biết anh LongBlue quê ở đâu không vậy?",
                    "Xin lỗi bạn 2 phút nhé mình có việc bận tí ^-^",
                    "Cái gì thế?",
                    "Oh, cái đó mình đâu cần phải làm đâu nhỉ?",
                    "Cho nó biết tay đi bạn ơi.",
                    "Mình gét nhất là thái độ ngông nghênh của cu Tèo khi nó ăn được con BOSS, mà thực ra con BOSS đó mình đánh nó hết 70% máu rồi. Nó từ đâu bay vô trọc trọc vài cái rồi kêu nó hạ gục BOSS mới ghê chứ!",
                    "Uh, cho nó một vài ruby để mua đố ấy mà, chứ có giàu có gì đâu!"
                ];

                var text = dict[Math.floor(Math.random() * dict.length)];
                var appendContainer = "#scroll1";
                var name = $.cookie("chatFriend");
                name = (name)?name:"KenLie";

                if($("#scroll2").css("display") == "block") {
                    appendContainer = "#scroll2";
                    name = Users[Math.floor(Math.random() * Users.length)]['name'];
                }

                var html = '<div class="row" style="z-index: 1002;"><a href="javascript: void(0);" class="select-name" fname="'+ name +'"><div class="name-answer">'+ name +':</div></a><div class="message">'+ text +'</div></div>';
                $(appendContainer).append(html);

                $(".select-name").ready(function(){
                    $(".select-name").click(function(){
                        $(".chat-mat").attr("fm", $(this).attr("fname"));
                        $(".click-user").fadeIn();
                    });
                });


                $(".chat-area").mCustomScrollbar('update');
                $(".chat-area").mCustomScrollbar("scrollTo","bottom");
            },
            listSearch: function(){
                var key = $(".tim-ban").val();
                if($.trim(key) == '') {$(".friend-area").fadeOut(200); return;}
                var searchUser = Chat.findUserWithName(key);

                var html = '<div class="friend-area" style="display: block;">';
                for(var i = 0; i< searchUser.length; i++){
                    html += '<div class="row">';
                    html += '<a class="select-user" fid="'+ searchUser[i]['name'] +'" href="javascript: void(0);"><div class="username">'+ searchUser[i]['name'] +'</div></a>';
                    html += '</div>';
                }
                html += '</div>';
                $(".friend-area").fadeOut(20, function(){
                    $(".friend-area").replaceWith(html);

                    $(".friend-area").ready(function(){
                        $(".friend-area").mCustomScrollbar({
                            axis:"y",
                            scrollButtons:{enable:true},
                            theme:"3d",
                            scrollbarPosition:"outside"
                        });
                        $(".select-user").click(function(){
                            var fid = $(this).attr("fid");
                            $.cookie("chatFriend", fid);
                            $(".friend-area").hide();
                            $(".tim-ban").val("");
                            $("#scroll1").html("");
                        });
                    });
                });
            },
            sortRank: function(field){
                Users.sort(function(a,b){return b[field] - a[field]});
            },
            findUserWithName: function(text){
                var ar = [];
                text = text.toLowerCase();
                for(var i = 0; i < Users.length; i++) {
                    if((Users[i]['name'].toLowerCase().search(text) > -1) && (Users[i]['name'] != $.cookie("myUser"))){
                        var obj = {"avatar": Users[i]['avatar'], "name" : Users[i]['name'], "online" : Users[i]['online'], "level" : Users[i]['level'], "rank" : (i + 1)};
                        ar.push(obj)
                    }
                }
                return ar;
            }
        };

        $(".tim-ban").keyup(function(){
            Chat.sortRank();
            Chat.listSearch();
        });
        $(".tim-ban").focus(function(){
            $(".friend-area").show();
        });

        $(".chat-area").mCustomScrollbar({
            scrollButtons:{
                enable:true
            }
        });

        $(".gui").click(function(){
            Chat.send();
        });
        $(".chat-text").keypress(function(event) {
            var keycode = (event.keyCode ? event.keyCode : event.which);
            if(keycode == '13') {
                Chat.send();
            }
        });

        if(showChat && showChat.length > 3) {
            $("#chat-container").fadeIn();
        }
        $(".close").click(function(){
            $("#chat-container").fadeOut();
            $.cookie("showChat", "");
        });
        $(".h0-chat").click(function(){
            $("#chat-container").fadeIn();
            $(".chat-text").focus();
        });

        $(".world").click(function(){
            if(timeOut) clearTimeout(timeOut);
            $("#scroll2").fadeIn();
            $("#scroll1").fadeOut();
            $(this).attr("src", $(this).attr("src").replace("off.", "on."));
            $(".private").attr("src", $(".private").attr("src").replace("on.", "off."));
            $(".chat-text").val("").focus();
            $(".tim-ban").hide();
        });
        $(".private").click(function(){
            if(timeOut) clearTimeout(timeOut);
            $("#scroll1").fadeIn();
            $("#scroll2").fadeOut();
            $(this).attr("src", $(this).attr("src").replace("off.", "on."));
            $(".world").attr("src", $(".world").attr("src").replace("on.", "off."));
            $(".chat-text").val("").focus();
            $(".tim-ban").show();
        });

        /*======================== POPUP CHAT =============================*/
        $(".chat-mat").click(function(){
            var fid = $(this).attr("fm");
            $.cookie("chatFriend", fid);
            $(".private").trigger("click");
            $(".click-user").fadeOut();
        });
        $(".cham-dong,.them-ban,.chan").click(function(){
            $(".click-user").fadeOut();
        });
    });
})(jQuery);