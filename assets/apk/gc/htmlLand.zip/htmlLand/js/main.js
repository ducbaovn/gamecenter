var widthDefault = 1280;
var heightDefault = 752;
var widthDevice = window.innerWidth;
var heightDevice = window.innerHeight;
var scaleWidth = widthDevice / widthDefault;
var scaleHeight = heightDevice / heightDefault;
//var zoom = 1;// for development
var zoom = (scaleHeight > scaleWidth) ? scaleWidth : scaleHeight;
var leftContainer = parseInt((widthDevice - widthDefault) / 2 * zoom);

jQuery(document).ready(function ($) {
    $("#loading").hide();

    //$("#loading").show().html("leftContainer: " + leftContainer +"; zoom: " + zoom + "; widthDevice: " + widthDevice + "; heightDevice: " + heightDevice);

    $('#container').css({
        '-webkit-transform' : 'scale('+zoom+')',
        '-moz-transform' : 'scale('+zoom+')',
        '-ms-transform' : 'scale('+zoom+')',
        '-o-transform' : 'scale('+zoom+')',
        'transform' : 'scale('+zoom+')'
    });

    if(zoom != 1) $("#container").css("left", leftContainer + "px");
});